#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
arvan_ip_rotator.py — Rotate an ArvanCloud server's public IPv4 when it is
blocked from inside Iran, using a strict make-before-break workflow.

Single file, Python 3.8+ standard library only. No third-party dependencies.

High-level workflow (make-before-break):
    1. RECORD   current public IP + the port/NIC that carries it.
    2. ALLOCATE a new public IPv4 (new port/NIC) from ArvanCloud.
    3. VERIFY   the new IP is present on the interface AND reachable from Iran
                (check-host.net multi-node consensus) AND the global internet
                is up (control nodes) so we never chase a false "blocked".
    4. SWITCH   default egress / routing to the new IP (with an auto-revert
                watchdog), then re-verify connectivity.
    5. DNS      point the gt / px / sb.honeyhost.click A records at the NEW IP
                (Cloudflare API token by default) and verify that authoritative
                + public resolvers return it.
    6. DRAIN    wait out the DNS TTL (plus a safety margin).
    7. RELEASE  only then detach/release the OLD public IP.

Any failure halts the workflow, raises an alert, and NEVER releases the old IP
unless every make-before-break gate has passed. State is persisted so the tool
is idempotent and restartable (systemd Restart=always friendly).

See the README for setup, required API permissions, dry-run, and recovery.

!!! Nothing here has been run against the real ArvanCloud or Cloudflare APIs (no
    key/token was provided). Run `preflight`, then `rotate --dry-run`, then
    `rotate --trial` before trusting it in production. Unconfirmed items are
    listed in ASSUMPTIONS.md.
"""

from __future__ import annotations

import argparse
import contextlib
import copy
import datetime as _dt
import errno
import fcntl
import ipaddress
import json
import os
import random
import re
import shlex
import signal
import socket
import ssl
import struct
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request
import uuid as _uuid
from typing import Any, Callable, Dict, List, Optional, Tuple

__version__ = "1.1.0"

# =============================================================================
# CONFIG
# -----------------------------------------------------------------------------
# Every key below can be overridden by an environment variable named
# ROTATOR_<KEY> whose value is parsed as JSON first and falls back to a raw
# string. Example:  ROTATOR_CHECK_INTERVAL_SEC=600  ROTATOR_DNS_NAMES='["@"]'
# Secrets are read from their own env vars / files (see API_KEY_ENV and
# CLOUDFLARE_API_TOKEN_ENV), never from this file.
# =============================================================================
CONFIG: Dict[str, Any] = {
    # ---- Identity / credentials ------------------------------------------
    # The API key is NEVER placed in this file. It is read (in order) from:
    #   1. the file named by $CREDENTIALS_DIRECTORY/arvan_api_key (systemd)
    #   2. API_KEY_FILE (if set)
    #   3. the environment variable named by API_KEY_ENV
    "API_KEY_ENV": "ARVAN_API_KEY",
    "API_KEY_FILE": "",               # optional path to a file holding the key
    "API_KEY_PREFIX": "Apikey ",      # Authorization header prefix

    # ---- ArvanCloud API endpoints ----------------------------------------
    "ARVAN_API_BASE": "https://napi.arvancloud.ir/ecc/v1",
    "CDN_API_BASE": "https://napi.arvancloud.ir/cdn/4.0",
    "IDENTITY_URL": "https://dejban.arvancloud.ir/v1/me",

    # ---- Which server to operate on --------------------------------------
    "REGION": "ir-thr-ba1",           # ArvanCloud region API code
    "SERVER_ID": "",                  # empty -> discover via cloud metadata
    "EXPECTED_SERVER_NAME": "",       # optional sanity cross-check
    "METADATA_URL": "http://169.254.169.254/openstack/latest/meta_data.json",
    "ADOPT_CURRENT_IP": "",           # force which existing public IP is "current"
    "IP_TYPE": "ipv4",

    # ---- Iran-reachability probing (check-host.net) ----------------------
    "CHECKHOST_BASE": "https://check-host.net",
    "CHECK_TYPE": "tcp",              # tcp | ping | http
    "CHECK_PORT": 443,                # for tcp/http
    "CHECK_HTTP_PATH": "/",           # for http checks
    "PROBE_NODES": [],                # [] -> auto-select Iranian nodes
    "PROBE_NODES_FALLBACK": [
        "ir1.node.check-host.net", "ir2.node.check-host.net",
        "ir3.node.check-host.net", "ir4.node.check-host.net",
        "ir5.node.check-host.net", "ir6.node.check-host.net",
        "ir7.node.check-host.net",
    ],
    "PROBE_COUNTRY": "ir",
    "PROBE_MAX_NODES": 10,
    "MIN_CONCLUSIVE_NODES": 3,        # need >=N nodes with a clear verdict
    "FAIL_RATIO_THRESHOLD": 0.5,      # blocked if fail_ratio > this
    "CONSECUTIVE_FAILED_CYCLES": 2,   # need N bad cycles in a row to rotate
    "CHECK_INTERVAL_SEC": 300,        # daemon poll interval

    # ---- Control probing (avoid false positives) -------------------------
    # If Iran looks blocked, confirm the host is actually up from elsewhere.
    "CONTROL_NODES": [],              # [] -> auto-select a few non-IR nodes
    "CONTROL_NODES_FALLBACK": [
        "de4.node.check-host.net", "fr2.node.check-host.net",
        "nl1.node.check-host.net",
    ],
    "CONTROL_MIN_SUCCESS": 1,         # need >=N control nodes reachable
    # Probe-side outage guard: at least one IR node must reach this target,
    # else the IR nodes themselves / their uplinks are the problem.
    "IRAN_CONTROL_TARGET": "1.1.1.1:443",

    # ---- check-host.net pacing / rate limits -----------------------------
    "CHECKHOST_MIN_SPACING_SEC": 60,  # min gap between submissions
    "CHECKHOST_RESULT_WAIT_SEC": 30,  # how long to poll for a result
    "CHECKHOST_RESULT_POLL_SEC": 3,
    "CHECKHOST_LIMIT_BACKOFF_SEC": 120,

    # ---- Verification after allocation / switch --------------------------
    "VERIFY_CYCLES": 2,               # independent good cycles required
    "VERIFY_MIN_SUCCESS_RATIO": 0.6,  # per-cycle reachable ratio required
    "VERIFY_CYCLE_SPACING_SEC": 60,

    # ---- Rate limiting of our own changes --------------------------------
    "COOLDOWN_AFTER_CHANGE_SEC": 3600,   # min gap after a completed rotation
    "MAX_CHANGES_PER_HOUR": 1,
    "MAX_CHANGES_PER_DAY": 3,
    "RETRY_BACKOFF_AFTER_FAILED_ATTEMPT_SEC": 900,
    "MAX_PUBLIC_IPS_PER_SERVER": 4,      # Arvan FAQ cap; refuse to exceed

    # ---- Allocation / NIC settling ---------------------------------------
    "NIC_APPEAR_TIMEOUT_SEC": 120,    # wait for new NIC/IP to appear in OS
    "PORT_ACTIVE_TIMEOUT_SEC": 180,   # wait for Arvan port -> ACTIVE
    "ALLOCATION_SETTLE_SEC": 60,      # wait before re-listing after an ambiguous add
    "MAX_ADD_ATTEMPTS": 2,
    "AUTO_DISCARD_FAILED_NEW_IP": False,  # if a just-added IP fails, auto-release it

    # ---- OS network configuration ----------------------------------------
    # how the new IP is placed on the interface and how egress is switched:
    #   iproute2 -> this script configures addr + policy routing (needs root)
    #   hook     -> call OS_CONFIGURE_HOOK and trust it
    #   none     -> assume DHCP/cloud-init already did it (verify only)
    "OS_NETWORK_MODE": "iproute2",
    "OS_CONFIGURE_HOOK": "",          # external script: argv = add|del IP CIDR GW IFACE
    "POLICY_TABLE": 2000,             # routing table id for source policy
    "POLICY_PRIORITY": 20000,         # ip rule priority
    "ROUTE_SWITCH_CONFIRM_TIMEOUT_SEC": 120,  # watchdog auto-revert window
    "REQUIRE_EGRESS_MATCH": True,     # egress IP must equal the new IP
    "EGRESS_ECHO_URLS": [
        "https://api.ipify.org", "https://ifconfig.me/ip",
        "https://icanhazip.com",
    ],
    "SET_RP_FILTER_LOOSE": True,      # sysctl rp_filter=2 for multi-homing
    "PERSIST_NETPLAN": False,         # write a netplan file (generate only)
    "NETPLAN_PATH": "/etc/netplan/90-arvan-ip-rotator.yaml",

    # ---- lifecycle hooks (optional external commands) --------------------
    "POST_SWITCH_HOOK": "",
    "PRE_RELEASE_HOOK": "",
    "POST_RELEASE_HOOK": "",

    # ---- DNS update + verification (honeyhost.click) ---------------------
    "DNS_CHECK_ENABLED": True,
    "DNS_ZONE": "honeyhost.click",
    # A records that follow the server. Each must point at the current IP before a
    # rotation; all of them are moved to the new IP together.
    "DNS_NAMES": ["gt", "px", "sb"],  # relative names or FQDNs ("@" = zone apex)
    "DNS_AUTHORITATIVE_NS": [],       # [] -> auto-discover via NS query
    "DNS_PUBLIC_RESOLVERS": ["1.1.1.1", "8.8.8.8", "9.9.9.9"],
    "DNS_REQUIRE_OLD_ABSENT": False,  # also require OLD IP to be gone
    # Zone audit: list every A (and, if the old port has IPv6, AAAA) record in
    # DNS_ZONE via the DNS provider's API; refuse to rotate if a record points at an
    # address that will be released but is not managed here (an A name missing from
    # DNS_NAMES, or an AAAA on the old port's IPv6) - releasing the old IP would
    # silently break it. Skipped with a warning only in DNS_UPDATE_MODE=verify_only
    # when the records cannot be read.
    "DNS_AUDIT_ZONE": True,
    "DNS_GATE_TIMEOUT_SEC": 900,      # max wait for DNS to show new IP
    "DNS_GATE_POLL_SEC": 20,
    # how DNS gets the new IP:
    #   cloudflare_api -> we PATCH the A records via the Cloudflare API, then verify
    #   arvan_api      -> we PUT the A records via the ArvanCloud CDN API, then verify
    #   verify_only    -> you update the records yourself; we only verify
    "DNS_UPDATE_MODE": "cloudflare_api",
    # TTL written together with the new IP: 0 = keep each record's current TTL.
    # cloudflare_api: 1 (= automatic, 300 s) or 60..86400; arvan_api: 120, 180, 300, ...
    "DNS_RECORD_TTL": 0,
    "DNS_DRAIN_MIN_SEC": 120,         # floor for TTL drain
    "DNS_DRAIN_EXTRA_SEC": 300,       # safety margin added to TTL drain
    "DNS_VERIFY_FROM_IRAN": False,    # informational check-host dns probe

    # ---- Cloudflare DNS (DNS_UPDATE_MODE=cloudflare_api) -----------------
    # The API token is NEVER placed in this file. It is read (in order) from:
    #   1. the file $CREDENTIALS_DIRECTORY/cloudflare_api_token (systemd)
    #   2. CLOUDFLARE_API_TOKEN_FILE (if set; must not be group/world readable)
    #   3. the environment variable named by CLOUDFLARE_API_TOKEN_ENV
    # Token permissions: Zone > DNS > Edit, plus Zone > Zone > Read (not needed if
    # CLOUDFLARE_ZONE_ID is set); Zone Resources: Include > Specific zone > DNS_ZONE.
    "CLOUDFLARE_API_BASE": "https://api.cloudflare.com/client/v4",
    "CLOUDFLARE_API_TOKEN_ENV": "CLOUDFLARE_API_TOKEN",
    "CLOUDFLARE_API_TOKEN_FILE": "",  # optional path to a file holding the token
    "CLOUDFLARE_ZONE_ID": "",         # optional 32-hex zone id; "" -> look up DNS_ZONE
    # Proxied (orange-cloud) records answer with Cloudflare edge IPs, so public DNS
    # cannot show the new origin IP. False -> refuse to rotate while a managed record
    # is proxied. True -> update it too and verify it by reading it back from the API.
    "CLOUDFLARE_ALLOW_PROXIED": False,

    # ---- Alerting --------------------------------------------------------
    "ALERT_WEBHOOK_URL_ENV": "ROTATOR_ALERT_WEBHOOK_URL",
    "ALERT_TELEGRAM_TOKEN_ENV": "ROTATOR_ALERT_TG_TOKEN",
    "ALERT_TELEGRAM_CHAT_ENV": "ROTATOR_ALERT_TG_CHAT",
    "ALERT_COMMAND": "",              # argv[1] gets a JSON alert payload
    "ALERT_REMIND_EVERY_SEC": 3600,   # re-alert cadence while halted
    "ALERT_MIN_LEVEL": "warning",     # info | warning | error | critical

    # ---- State / logs ----------------------------------------------------
    "STATE_DIR": "/var/lib/arvan-ip-rotator",
    "LOG_DIR": "/var/log/arvan-ip-rotator",
    "LOG_MAX_BYTES": 10 * 1024 * 1024,
    "LOG_BACKUPS": 5,
    "LOG_STDOUT": True,
    "LOG_LEVEL": "info",

    # ---- HTTP client -----------------------------------------------------
    "HTTP_TIMEOUT_SEC": 30,
    "HTTP_RETRIES": 3,                # for idempotent requests only
    "HTTP_RETRY_BACKOFF_SEC": 2.0,
    "HTTP_USER_AGENT": "arvan-ip-rotator/%s" % __version__,
}

# Keys whose values must never be written to logs / state verbatim.
_SECRET_HINTS = ("key", "token", "secret", "password", "apikey", "authorization")


# =============================================================================
# Small utilities
# =============================================================================
def utcnow() -> _dt.datetime:
    return _dt.datetime.now(tz=_dt.timezone.utc)


def iso(ts: Optional[_dt.datetime] = None) -> str:
    return (ts or utcnow()).strftime("%Y-%m-%dT%H:%M:%SZ")


def is_secret_key(name: str) -> bool:
    low = name.lower()
    return any(h in low for h in _SECRET_HINTS)


def redact(obj: Any) -> Any:
    """Recursively redact anything that looks secret before logging."""
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if isinstance(k, str) and is_secret_key(k):
                out[k] = "***REDACTED***"
            else:
                out[k] = redact(v)
        return out
    if isinstance(obj, (list, tuple)):
        return [redact(v) for v in obj]
    if isinstance(obj, str):
        # scrub "Apikey <uuid>" style tokens if they ever slip through
        return re.sub(r"(?i)(apikey|bearer)\s+[A-Za-z0-9\-\._~\+/=]+",
                      r"\1 ***REDACTED***", obj)
    return obj


def load_config() -> Dict[str, Any]:
    """Return CONFIG overlaid with ROTATOR_<KEY> environment overrides."""
    cfg = copy.deepcopy(CONFIG)
    for key in list(cfg.keys()):
        env_name = "ROTATOR_" + key
        if env_name in os.environ:
            raw = os.environ[env_name]
            try:
                val = json.loads(raw)
            except (ValueError, TypeError):
                val = raw
            if isinstance(CONFIG[key], str) and not isinstance(val, str):
                val = raw          # e.g. ROTATOR_EXPECTED_SERVER_NAME=123 stays a string
            cfg[key] = val
    return cfg


class RotatorError(Exception):
    """Base class for controlled, explained failures."""


class HaltError(RotatorError):
    """Fatal: persist state, alert, and stop touching infrastructure."""


class TransientError(RotatorError):
    """Recoverable: keep current phase and retry later."""


class InconclusiveError(TransientError):
    """We could not determine reachability; do nothing destructive."""


class LockHeldError(RotatorError):
    """Another instance (daemon or operator command) holds the state lock."""


# =============================================================================
# Structured event log  (JSONL, size-rotated, secrets redacted)
# =============================================================================
class EventLog:
    def __init__(self, cfg: Dict[str, Any]):
        self.cfg = cfg
        self.dir = cfg["LOG_DIR"]
        self.max_bytes = int(cfg["LOG_MAX_BYTES"])
        self.backups = int(cfg["LOG_BACKUPS"])
        self.to_stdout = bool(cfg["LOG_STDOUT"])
        levels = {"debug": 10, "info": 20, "warning": 30, "error": 40, "critical": 50}
        self.min_level = levels.get(str(cfg["LOG_LEVEL"]).lower(), 20)
        self._levels = levels
        self._lock = threading.Lock()
        with contextlib.suppress(OSError):
            os.makedirs(self.dir, exist_ok=True)

    def _rotate_if_needed(self, path: str) -> None:
        with contextlib.suppress(OSError):
            if os.path.exists(path) and os.path.getsize(path) >= self.max_bytes:
                for i in range(self.backups - 1, 0, -1):
                    src, dst = "%s.%d" % (path, i), "%s.%d" % (path, i + 1)
                    if os.path.exists(src):
                        os.replace(src, dst)
                os.replace(path, path + ".1")

    def _write(self, fname: str, record: Dict[str, Any]) -> None:
        path = os.path.join(self.dir, fname)
        line = json.dumps(redact(record), ensure_ascii=False, sort_keys=True)
        with self._lock:
            self._rotate_if_needed(path)
            try:
                with open(path, "a", encoding="utf-8") as fh:
                    fh.write(line + "\n")
            except OSError:
                pass  # never let logging crash the rotator

    def event(self, level: str, event: str, **fields: Any) -> None:
        if self._levels.get(level, 20) < self.min_level:
            return
        rec = {"ts": iso(), "level": level, "event": event}
        rec.update(fields)
        self._write("events.jsonl", rec)
        if self.to_stdout:
            tag = {"debug": "·", "info": "•", "warning": "!",
                   "error": "✗", "critical": "✗✗"}.get(level, "•")
            extra = " ".join(
                "%s=%s" % (k, json.dumps(redact(v), ensure_ascii=False))
                for k, v in fields.items() if k != "traceback")
            sys.stdout.write("%s %s %-26s %s\n" % (iso(), tag, event, extra))
            sys.stdout.flush()

    def check(self, record: Dict[str, Any]) -> None:
        """Append a reachability-check record to checks.jsonl."""
        rec = {"ts": iso()}
        rec.update(record)
        self._write("checks.jsonl", rec)

    def debug(self, e, **f): self.event("debug", e, **f)
    def info(self, e, **f): self.event("info", e, **f)
    def warning(self, e, **f): self.event("warning", e, **f)
    def error(self, e, **f): self.event("error", e, **f)
    def critical(self, e, **f): self.event("critical", e, **f)


# =============================================================================
# Clock (injectable for tests) + cooperative stop handling
# =============================================================================
STOP_EVENT = threading.Event()


class StopRequested(BaseException):
    """Raised from sleeps when SIGTERM/SIGINT arrived. State is already safe.
    BaseException so generic `except Exception` blocks never swallow it."""


class Clock:
    def time(self) -> float:
        return time.time()

    def sleep(self, seconds: float) -> None:
        if seconds <= 0:
            if STOP_EVENT.is_set():
                raise StopRequested()
            return
        if STOP_EVENT.wait(seconds):
            raise StopRequested()


# =============================================================================
# Persistent state  (atomic writes, lock, backup, refuse-on-corruption)
# =============================================================================
PHASES = [
    "PRE_ALLOCATE",   # write-ahead: about to call add-public-ip
    "ALLOCATED",      # Arvan returned/has a new public port
    "OS_CONFIGURED",  # new IP present on a local interface (+ policy routing)
    "VERIFIED",       # new IP reachable from Iran (consensus) + globally
    "SWITCHING",      # write-ahead: about to move default egress
    "SWITCHED",       # egress via new IP confirmed
    "DNS_UPDATED",    # DNS update requested (or verify-only no-op)
    "DNS_VERIFIED",   # authoritative + public resolvers show new IP
    "DRAINING",       # waiting out TTL before releasing the old IP
    "RELEASING",      # write-ahead: about to detach the OLD port
    "DONE",
]


def phase_index(phase: str) -> int:
    return PHASES.index(phase) if phase in PHASES else -1


class StateStore:
    SCHEMA = 1

    def __init__(self, state_dir: str, log: EventLog, readonly: bool = False):
        self.dir = state_dir
        self.path = os.path.join(state_dir, "state.json")
        self.bak = self.path + ".bak"
        self.lock_path = os.path.join(state_dir, "lock")
        self.log = log
        self.readonly = readonly
        self._lock_fh = None

    @staticmethod
    def default_state() -> Dict[str, Any]:
        return {
            "schema": StateStore.SCHEMA,
            "server_id": None,
            "region": None,
            "current": None,          # {"ip","port_id","mac","table"}
            "rotation": None,         # in-flight rotation record
            "halt": None,             # {"reason","at","phase","rotation_id","last_alert_at"}
            "detector": {"consecutive_bad": 0, "last_verdict": None,
                         "last_check_at": None, "last_inconclusive_alert_at": None},
            "allocations": [],        # epoch timestamps of add-public-ip attempts
            "last_change_at": None,   # epoch of last completed rotation
            "last_failed_attempt_at": None,
            "history": [],            # completed/aborted rotations (bounded)
            "untracked_public_ips": [],
            "checkhost_last_submit": 0,
            "warned": {},             # de-dup for one-off warnings
        }

    def ensure_dir(self) -> None:
        if self.readonly:
            return
        os.makedirs(self.dir, mode=0o700, exist_ok=True)

    def acquire_lock(self) -> None:
        if self.readonly:
            return
        self.ensure_dir()
        fh = open(self.lock_path, "a+")
        try:
            fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            fh.close()
            if exc.errno in (errno.EAGAIN, errno.EACCES, errno.EWOULDBLOCK):
                raise LockHeldError(
                    "another arvan_ip_rotator instance holds %s; stop it first "
                    "(e.g. systemctl stop arvan-ip-rotator) or use read-only "
                    "commands (status)" % self.lock_path)
            raise
        fh.seek(0)
        fh.truncate()
        fh.write("%d\n" % os.getpid())
        fh.flush()
        self._lock_fh = fh

    def release_lock(self) -> None:
        if self._lock_fh is not None:
            with contextlib.suppress(OSError):
                fcntl.flock(self._lock_fh.fileno(), fcntl.LOCK_UN)
                self._lock_fh.close()
            self._lock_fh = None

    def _parse(self, path: str) -> Dict[str, Any]:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        if not isinstance(data, dict) or data.get("schema") != self.SCHEMA:
            raise ValueError("unexpected schema in %s" % path)
        merged = self.default_state()
        merged.update(data)
        return merged

    def load(self) -> Dict[str, Any]:
        if not os.path.exists(self.path):
            if os.path.exists(self.bak):
                try:
                    st = self._parse(self.bak)
                    self.log.warning("state_recovered_from_backup", path=self.bak)
                    return st
                except (OSError, ValueError) as exc:
                    raise HaltError("state file missing and backup unreadable (%s); "
                                    "refusing to guess. Inspect %s" % (exc, self.dir))
            return self.default_state()
        try:
            return self._parse(self.path)
        except PermissionError:
            raise RotatorError("cannot read %s: permission denied (run as root)" % self.path)
        except (OSError, ValueError) as exc:
            try:
                st = self._parse(self.bak)
                self.log.error("state_corrupt_using_backup", error=str(exc), path=self.path)
                return st
            except (OSError, ValueError):
                raise HaltError(
                    "state file %s is corrupt (%s) and no valid backup exists. "
                    "Refusing to reset automatically because an in-flight rotation "
                    "may exist. Inspect the file and the ArvanCloud panel, then move "
                    "it aside manually." % (self.path, exc))

    def save(self, state: Dict[str, Any]) -> None:
        if self.readonly:
            return
        self.ensure_dir()
        state["schema"] = self.SCHEMA
        state["updated_at"] = iso()
        payload = json.dumps(state, indent=2, sort_keys=True, ensure_ascii=False)
        fd, tmp = tempfile.mkstemp(dir=self.dir, prefix=".state.", suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                fh.write(payload)
                fh.flush()
                os.fsync(fh.fileno())
            os.chmod(tmp, 0o600)
            if os.path.exists(self.path):
                bak_tmp = self.bak + ".tmp"
                with contextlib.suppress(FileNotFoundError):
                    os.unlink(bak_tmp)
                try:
                    os.link(self.path, bak_tmp)
                except OSError:
                    with open(self.path, "rb") as src, open(bak_tmp, "wb") as dst:
                        dst.write(src.read())
                os.replace(bak_tmp, self.bak)
            os.replace(tmp, self.path)
            dfd = os.open(self.dir, os.O_DIRECTORY)
            try:
                os.fsync(dfd)
            finally:
                os.close(dfd)
        finally:
            with contextlib.suppress(FileNotFoundError):
                os.unlink(tmp)


# =============================================================================
# HTTP client (stdlib).  Retries ONLY idempotent requests.
# =============================================================================
class HttpResponse:
    def __init__(self, status: int, headers: Dict[str, str], body: bytes, url: str):
        self.status = status
        self.headers = headers
        self.body = body
        self.url = url
        self._json: Any = None
        self._json_done = False

    @property
    def text(self) -> str:
        return self.body.decode("utf-8", "replace")

    @property
    def json(self) -> Any:
        if not self._json_done:
            self._json_done = True
            try:
                self._json = json.loads(self.body.decode("utf-8")) if self.body else None
            except (ValueError, UnicodeDecodeError):
                self._json = None
        return self._json


class AmbiguousRequestError(TransientError):
    """A non-idempotent request failed in a way where it MAY have been applied."""


class Http:
    def __init__(self, cfg: Dict[str, Any], log: EventLog, clock: Clock,
                 read_only: bool = False):
        self.cfg = cfg
        self.log = log
        self.clock = clock
        self.read_only = read_only
        self.timeout = float(cfg["HTTP_TIMEOUT_SEC"])
        self.retries = int(cfg["HTTP_RETRIES"])
        self.backoff = float(cfg["HTTP_RETRY_BACKOFF_SEC"])
        self.ua = cfg["HTTP_USER_AGENT"]
        ctx = ssl.create_default_context()
        self._opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx))
        self._opener_noproxy = urllib.request.build_opener(
            urllib.request.ProxyHandler({}), urllib.request.HTTPSHandler(context=ctx))
        self._sunset_warned: set = set()
        self.mutations: List[str] = []   # audit of mutating calls (tests/dry-run proof)

    def request(self, method: str, url: str, headers: Optional[Dict[str, str]] = None,
                json_body: Any = None, idempotent: Optional[bool] = None,
                timeout: Optional[float] = None, retries: Optional[int] = None,
                no_proxy: bool = False) -> HttpResponse:
        method = method.upper()
        mutating = method not in ("GET", "HEAD", "OPTIONS")
        if mutating and self.read_only:
            raise RotatorError("SAFETY: refusing %s %s in read-only/dry-run mode" % (method, url))
        if idempotent is None:
            idempotent = not mutating
        hdrs = {"User-Agent": self.ua, "Accept": "application/json"}
        if headers:
            hdrs.update(headers)
        data = None
        if json_body is not None:
            data = json.dumps(json_body).encode("utf-8")
            hdrs.setdefault("Content-Type", "application/json")
        attempts = 1 + (int(self.retries if retries is None else retries) if idempotent else 0)
        to = float(timeout or self.timeout)
        if mutating:
            self.mutations.append("%s %s" % (method, url))
        last_exc: Optional[BaseException] = None
        for attempt in range(attempts):
            try:
                req = urllib.request.Request(url, data=data, method=method, headers=hdrs)
                opener = self._opener_noproxy if no_proxy else self._opener
                with opener.open(req, timeout=to) as resp:
                    status = resp.status
                    rheaders = {k.lower(): v for k, v in resp.headers.items()}
                    body = resp.read()
            except urllib.error.HTTPError as exc:
                status = exc.code
                rheaders = {k.lower(): v for k, v in (exc.headers or {}).items()}
                try:
                    body = exc.read()
                except Exception:  # pragma: no cover
                    body = b""
            except (urllib.error.URLError, socket.timeout, ConnectionError,
                    ssl.SSLError, OSError) as exc:
                last_exc = exc
                if attempt < attempts - 1:
                    self.clock.sleep(self.backoff * (2 ** attempt))
                    continue
                if mutating and not idempotent:
                    raise AmbiguousRequestError(
                        "%s %s failed at network level (%s); it MAY have been applied"
                        % (method, _short_url(url), exc))
                raise TransientError("%s %s network error: %s" % (method, _short_url(url), exc))
            self._check_sunset(url, rheaders)
            if (status >= 500 or status == 429) and attempt < attempts - 1:
                wait = self.backoff * (2 ** attempt)
                ra = rheaders.get("retry-after")
                if ra and ra.isdigit():
                    wait = max(wait, min(float(ra), 120.0))
                self.clock.sleep(wait)
                continue
            return HttpResponse(status, rheaders, body, url)
        raise TransientError("request failed: %s" % last_exc)  # pragma: no cover

    def _check_sunset(self, url: str, headers: Dict[str, str]) -> None:
        for h in ("sunset", "deprecation"):
            if h in headers:
                key = (h, urllib.parse.urlsplit(url).path.split("/regions/")[0])
                if key not in self._sunset_warned:
                    self._sunset_warned.add(key)
                    self.log.warning("api_deprecation_header", header=h, value=headers[h],
                                     url=_short_url(url))


def _short_url(url: str) -> str:
    parts = urllib.parse.urlsplit(url)
    return "%s://%s%s" % (parts.scheme, parts.netloc, parts.path)


def fetch_text_bound(url: str, source_ip: Optional[str], timeout: float = 10.0,
                     ua: str = "arvan-ip-rotator") -> str:
    """HTTPS/HTTP GET bound to a source IP, bypassing proxies (egress probes)."""
    import http.client
    parts = urllib.parse.urlsplit(url)
    port = parts.port or (443 if parts.scheme == "https" else 80)
    src = (source_ip or "0.0.0.0", 0)    # 0.0.0.0 forces IPv4 on dual-stack hosts
    if parts.scheme == "https":
        conn = http.client.HTTPSConnection(parts.hostname, port, timeout=timeout,
                                           source_address=src,
                                           context=ssl.create_default_context())
    else:
        conn = http.client.HTTPConnection(parts.hostname, port, timeout=timeout,
                                          source_address=src)
    try:
        conn.request("GET", parts.path or "/", headers={"User-Agent": ua, "Accept": "text/plain"})
        resp = conn.getresponse()
        body = resp.read(4096).decode("utf-8", "replace").strip()
        if resp.status != 200:
            raise OSError("HTTP %d from %s" % (resp.status, url))
        return body
    finally:
        conn.close()


# =============================================================================
# ArvanCloud API (IaaS v1 + CDN DNS + identity)
# =============================================================================
class ApiError(RotatorError):
    def __init__(self, method: str, url: str, status: int, message: str,
                 request_id: Optional[str] = None, kind: Optional[str] = None,
                 provider: str = "ArvanCloud", id_label: str = "X-AR-Request-Id"):
        self.method, self.url, self.status = method, url, status
        self.message, self.request_id, self.provider = message, request_id, provider
        if kind is None:
            kind = {401: "unauthenticated", 403: "forbidden", 404: "not_found",
                    420: "quota_exceeded", 429: "rate_limited"}.get(status)
        if kind is None:
            kind = "server_error" if status >= 500 else "client_error"
        self.kind = kind
        super().__init__("%s %s -> HTTP %d (%s): %s%s" % (
            method, _short_url(url), status, kind, message,
            (" [%s=%s]" % (id_label, request_id)) if request_id else ""))

    @property
    def transient(self) -> bool:
        return self.kind in ("rate_limited", "server_error")


def _api_message(resp: HttpResponse) -> str:
    j = resp.json
    if isinstance(j, dict):
        for k in ("message", "error", "errors", "detail"):
            if j.get(k):
                v = j[k]
                return v if isinstance(v, str) else json.dumps(v, ensure_ascii=False)[:500]
    return resp.text[:300]


def _is_ipv4(s: Any) -> bool:
    try:
        return isinstance(ipaddress.ip_address(str(s)), ipaddress.IPv4Address)
    except ValueError:
        return False


def _is_public_ipv4(s: Any) -> bool:
    try:
        ip = ipaddress.ip_address(str(s))
        return isinstance(ip, ipaddress.IPv4Address) and ip.is_global
    except ValueError:
        return False


class ArvanAPI:
    def __init__(self, cfg: Dict[str, Any], http: Http, log: EventLog,
                 api_key: Optional[str], server_id: Optional[str]):
        self.cfg = cfg
        self.http = http
        self.log = log
        self.base = cfg["ARVAN_API_BASE"].rstrip("/")
        self.cdn = cfg["CDN_API_BASE"].rstrip("/")
        self.region = cfg["REGION"]
        self.server_id = server_id
        self._key = api_key

    # -- low level ---------------------------------------------------------
    def _headers(self) -> Dict[str, str]:
        if not self._key:
            raise HaltError("no ArvanCloud API key available (set $%s or a credential file)"
                            % self.cfg["API_KEY_ENV"])
        return {"Authorization": self.cfg["API_KEY_PREFIX"] + self._key,
                "Accept": "application/json"}

    def call(self, method: str, url: str, body: Any = None,
             idempotent: Optional[bool] = None, allow_404: bool = False) -> Any:
        resp = self.http.request(method, url, headers=self._headers(), json_body=body,
                                 idempotent=idempotent)
        rid = resp.headers.get("x-ar-request-id")
        if 200 <= resp.status < 300:
            j = resp.json
            self.log.debug("api_ok", method=method, url=_short_url(url), status=resp.status,
                           request_id=rid)
            if isinstance(j, dict) and "data" in j:
                return j["data"]
            return j
        if resp.status == 404 and allow_404:
            return None
        raise ApiError(method, url, resp.status, _api_message(resp), rid)

    def _r(self, path: str) -> str:
        return "%s/regions/%s%s" % (self.base, self.region, path)

    # -- identity ------------------------------------------------------------
    def whoami(self) -> Any:
        return self.call("GET", self.cfg["IDENTITY_URL"])

    # -- servers / ports / networks -------------------------------------------
    def get_server(self) -> Dict[str, Any]:
        return self.call("GET", self._r("/servers/%s" % self.server_id))

    def list_servers(self) -> List[Dict[str, Any]]:
        return self.call("GET", self._r("/servers")) or []

    def list_server_ports(self) -> List[Dict[str, Any]]:
        return self.call("GET", self._r("/servers/%s/ports" % self.server_id)) or []

    def get_port(self, port_id: str) -> Optional[Dict[str, Any]]:
        return self.call("GET", self._r("/ports/%s" % port_id), allow_404=True)

    def get_network(self, network_id: str) -> Optional[Dict[str, Any]]:
        return self.call("GET", self._r("/networks/%s" % network_id), allow_404=True)

    def list_networks(self) -> List[Dict[str, Any]]:
        return self.call("GET", self._r("/networks")) or []

    def get_quotas(self) -> Any:
        return self.call("GET", self._r("/quotas"))

    def add_public_ip(self, security_group_ids: List[str]) -> Dict[str, Any]:
        """NON-idempotent: a single attempt only. Creates a NEW port/NIC."""
        body = {"type": self.cfg["IP_TYPE"], "security_groups": list(security_group_ids)}
        return self.call("POST", self._r("/servers/%s/add-public-ip" % self.server_id),
                         body=body, idempotent=False) or {}

    def add_public_ip_request_preview(self, security_group_ids: List[str]) -> Dict[str, Any]:
        return {"method": "POST",
                "url": self._r("/servers/%s/add-public-ip" % self.server_id),
                "body": {"type": self.cfg["IP_TYPE"],
                         "security_groups": list(security_group_ids)}}

    def detach_port(self, port_id: str) -> Any:
        """Release one public IP by detaching ITS port from the server."""
        return self.call("PATCH", self._r("/networks/%s/detach" % port_id),
                         body={"server_id": self.server_id}, idempotent=False)

    def detach_request_preview(self, port_id: str) -> Dict[str, Any]:
        return {"method": "PATCH", "url": self._r("/networks/%s/detach" % port_id),
                "body": {"server_id": self.server_id}}

    # -- DNS (CDN API) -----------------------------------------------------
    def dns_list_records(self, zone: str, name: Optional[str] = None,
                         rtype: str = "a") -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        page = 1
        while page <= 50:
            q = {"type": rtype, "page": page, "per_page": 100}
            if name:
                q["search"] = name
            url = "%s/domains/%s/dns-records?%s" % (self.cdn, zone, urllib.parse.urlencode(q))
            resp = self.http.request("GET", url, headers=self._headers())
            if not 200 <= resp.status < 300:
                raise ApiError("GET", url, resp.status, _api_message(resp),
                               resp.headers.get("x-ar-request-id"))
            j = resp.json or {}
            batch = j.get("data") or []
            out.extend(batch)
            meta = j.get("meta") or {}
            last = meta.get("last_page") or (meta.get("pagination") or {}).get("total_pages")
            if not batch or not last or page >= int(last):
                break
            page += 1
        return out

    def dns_update_record(self, zone: str, record_id: str, body: Dict[str, Any]) -> Any:
        # PUT replaces the record with the same content each time -> idempotent
        return self.call("PUT", "%s/domains/%s/dns-records/%s" % (self.cdn, zone, record_id),
                         body=body, idempotent=True)

    # -- derived helpers -----------------------------------------------------
    def public_inventory(self, server: Optional[Dict[str, Any]] = None,
                         ports: Optional[List[Dict[str, Any]]] = None) -> List[Dict[str, Any]]:
        """Return [{ip, port_id, mac, network_id, sg_ids, status}] for public IPv4s."""
        server = server if server is not None else self.get_server()
        ports = ports if ports is not None else self.list_server_ports()
        flagged: Dict[str, bool] = {}
        for _net, addrs in (server.get("addresses") or {}).items():
            for a in addrs or []:
                ip = a.get("addr")
                if _is_ipv4(ip):
                    flagged[ip] = bool(a.get("is_public"))
        inv = []
        for p in ports:
            for ip in p.get("ips") or []:
                if not _is_ipv4(ip):
                    continue
                if flagged.get(ip) or (ip not in flagged and _is_public_ipv4(ip)):
                    inv.append({"ip": ip, "port_id": p.get("id"),
                                "ipv6": [x for x in (p.get("ips") or []) if ":" in str(x)],
                                "mac": (p.get("mac_address") or "").lower(),
                                "network_id": p.get("network_id"),
                                "sg_ids": list(p.get("security_group_ids") or []),
                                "status": p.get("status")})
        return inv

    def subnet_for_ip(self, ip: str, network_id: Optional[str]) -> Optional[Dict[str, Any]]:
        """Find {cidr, gateway_ip, subnet_id, mtu, dns} for an IP via networks API."""
        nets: List[Dict[str, Any]] = []
        if network_id:
            n = self.get_network(network_id)
            if n:
                nets.append(n)
        if not nets:
            nets = self.list_networks()
        addr = ipaddress.ip_address(ip)
        for n in nets:
            for s in n.get("subnets") or []:
                try:
                    if addr in ipaddress.ip_network(s.get("cidr"), strict=False):
                        return {"cidr": s.get("cidr"), "gateway": s.get("gateway_ip"),
                                "subnet_id": s.get("id"), "mtu": s.get("mtu"),
                                "dns": s.get("dns_nameservers") or [],
                                "network_id": n.get("id"), "network_name": n.get("name")}
                except (ValueError, TypeError):
                    continue
        return None


# =============================================================================
# Cloudflare API v4 - DNS records only (API token, "Authorization: Bearer")
# =============================================================================
CF_TTL_AUTO_SEC = 300                       # what Cloudflare's 'automatic' TTL (ttl=1) means
_CF_UNAUTHENTICATED = {6003, 6103, 6111, 9106, 10001}   # missing/malformed/invalid token
_CF_FORBIDDEN = {9109, 10000}                           # token not allowed for this resource


def cf_ttl_seconds(ttl: Any) -> int:
    """Seconds a resolver may cache a Cloudflare record (ttl 1 = automatic = 300 s)."""
    try:
        t = int(ttl)
    except (TypeError, ValueError):
        return CF_TTL_AUTO_SEC
    return CF_TTL_AUTO_SEC if t <= 1 else t


class CloudflareAPI:
    """Zone lookup + list / get / PATCH of DNS records. Never creates or deletes records."""

    def __init__(self, cfg: Dict[str, Any], http: Http, log: EventLog, token: Optional[str]):
        self.cfg, self.http, self.log = cfg, http, log
        self.base = str(cfg["CLOUDFLARE_API_BASE"]).rstrip("/")
        self.zone_name = str(cfg["DNS_ZONE"]).rstrip(".").lower()
        self._token = token
        self._zone_id: Optional[str] = str(cfg.get("CLOUDFLARE_ZONE_ID") or "").strip().lower() or None
        self.zone: Dict[str, Any] = {}       # zone object, when it was looked up by name

    @property
    def has_token(self) -> bool:
        return bool(self._token)

    def _headers(self) -> Dict[str, str]:
        if not self._token:
            raise HaltError("no Cloudflare API token available (set $%s, CLOUDFLARE_API_TOKEN_FILE or "
                            "the systemd credential cloudflare_api_token)" % self.cfg["CLOUDFLARE_API_TOKEN_ENV"])
        return {"Authorization": "Bearer " + self._token, "Accept": "application/json"}

    def call(self, method: str, path: str, query: Optional[Dict[str, Any]] = None, body: Any = None,
             idempotent: Optional[bool] = None, allow_404: bool = False) -> Dict[str, Any]:
        url = self.base + path + ("?" + urllib.parse.urlencode(query) if query else "")
        resp = self.http.request(method, url, headers=self._headers(), json_body=body,
                                 idempotent=idempotent)
        ray = resp.headers.get("cf-ray")
        j = resp.json if isinstance(resp.json, dict) else {}
        if 200 <= resp.status < 300 and j.get("success") is True:
            self.log.debug("api_ok", provider="cloudflare", method=method, url=_short_url(url),
                           status=resp.status, cf_ray=ray)
            return j
        if resp.status == 404 and allow_404:
            return {}
        errs = [e for e in (j.get("errors") or []) if isinstance(e, dict)]
        codes = set()
        for e in errs:
            with contextlib.suppress(TypeError, ValueError):
                codes.add(int(e.get("code")))
        kind = None
        if resp.status < 500 and resp.status != 429:
            if codes & _CF_FORBIDDEN:
                kind = "forbidden"
            elif codes & _CF_UNAUTHENTICATED:
                kind = "unauthenticated"
        msg = "; ".join("%s %s" % (e.get("code"), e.get("message")) for e in errs)[:500]
        raise ApiError(method, url, resp.status, msg or resp.text[:300] or "no success flag",
                       ray, kind=kind, provider="Cloudflare", id_label="cf-ray")

    def verify_token(self) -> Dict[str, Any]:
        """{id, status, expires_on?}. Works for user-owned tokens (account tokens: other path)."""
        return self.call("GET", "/user/tokens/verify").get("result") or {}

    def zone_id(self) -> str:
        if self._zone_id:
            return self._zone_id
        j = self.call("GET", "/zones", query={"name": self.zone_name, "per_page": 50})
        zones = [z for z in (j.get("result") or []) if isinstance(z, dict)
                 and str(z.get("name") or "").rstrip(".").lower() == self.zone_name]
        if not zones:
            raise ApiError("GET", self.base + "/zones", 404,
                           "zone %s is not visible to this token (grant Zone > Zone > Read on it, or "
                           "set CLOUDFLARE_ZONE_ID)" % self.zone_name, kind="not_found",
                           provider="Cloudflare")
        z = ([x for x in zones if x.get("status") == "active"] or zones)[0]
        self.zone, self._zone_id = z, str(z.get("id"))
        return self._zone_id

    def zone_problem(self) -> Optional[str]:
        """Why Cloudflare would not be serving the zone's DNS (None = fine or unknown)."""
        z = self.zone
        if z.get("status") and z.get("status") != "active":
            return ("Cloudflare zone %s has status %r (not 'active'): Cloudflare is not answering for it, "
                    "so API changes would not reach clients" % (self.zone_name, z.get("status")))
        if z.get("type") and z.get("type") != "full":
            return ("Cloudflare zone %s is a %r setup: another provider is the authoritative DNS, so API "
                    "changes would not reach clients" % (self.zone_name, z.get("type")))
        return None

    def list_records(self, rtype: Optional[str] = None, name: Optional[str] = None) -> List[Dict[str, Any]]:
        """Every matching record, following pagination (callers re-check type/name)."""
        zid, out, page = self.zone_id(), [], 1
        while True:
            q: Dict[str, Any] = {"page": page, "per_page": 500}
            if rtype:
                q["type"] = rtype
            if name:
                q["name.exact"] = name
            j = self.call("GET", "/zones/%s/dns_records" % zid, query=q)
            batch = [r for r in (j.get("result") or []) if isinstance(r, dict)]
            out.extend(batch)
            try:
                pages = int((j.get("result_info") or {}).get("total_pages") or 1)
            except (TypeError, ValueError):
                pages = 1
            if not batch or page >= pages:
                return out
            if page >= 200:        # an incomplete listing would make the zone audit lie
                raise ApiError("GET", self.base + "/zones/%s/dns_records" % zid, 200,
                               "more than %d pages of DNS records" % page, kind="client_error",
                               provider="Cloudflare")
            page += 1

    def get_record(self, record_id: str) -> Optional[Dict[str, Any]]:
        j = self.call("GET", "/zones/%s/dns_records/%s" % (self.zone_id(), record_id), allow_404=True)
        return j.get("result") if j else None

    @staticmethod
    def patch_body(rec: Dict[str, Any], content: str, ttl: int = 0) -> Dict[str, Any]:
        """Same type/name/proxied as the record; new content; TTL kept unless `ttl` is set
        (proxied records always keep theirs - Cloudflare manages it)."""
        keep = int(rec.get("ttl") or 1)
        return {"type": str(rec.get("type") or "A").upper(), "name": rec.get("name"),
                "content": content, "ttl": keep if (rec.get("proxied") or not ttl) else int(ttl),
                "proxied": bool(rec.get("proxied"))}

    def update_record(self, record_id: str, body: Dict[str, Any]) -> Dict[str, Any]:
        """PATCH writes the same fields every time -> idempotent, safe to retry."""
        j = self.call("PATCH", "/zones/%s/dns_records/%s" % (self.zone_id(), record_id), body=body,
                      idempotent=True)
        return j.get("result") or {}


# =============================================================================
# check-host.net client + Iran reachability consensus
# =============================================================================
class CheckHostLimit(TransientError):
    pass


REACHABLE, BLOCKED, INCONCLUSIVE, DOWN = "REACHABLE", "BLOCKED", "INCONCLUSIVE", "DOWN"


def classify_node_result(ctype: str, value: Any) -> Tuple[str, str]:
    """Map one node's raw check-host result to ('ok'|'fail'|'unknown', detail)."""
    if value is None:
        return "unknown", "pending/no result"
    try:
        if ctype == "tcp":
            if not isinstance(value, list) or not value or value[0] is None:
                return "unknown", "no data"
            first = value[0]
            if isinstance(first, dict) and "error" in first:
                return "fail", str(first.get("error"))
            if isinstance(first, dict) and ("time" in first or "address" in first):
                return "ok", "connected in %ss" % first.get("time")
            return "unknown", "unparsed: %s" % json.dumps(value)[:120]
        if ctype == "ping":
            if not isinstance(value, list) or not value:
                return "unknown", "no data"
            pings = value[0]
            if not isinstance(pings, list) or not pings or pings[0] is None:
                return "unknown", "resolve failure / no data"
            oks = [p for p in pings if isinstance(p, list) and p and p[0] == "OK"]
            if oks:
                return "ok", "%d/%d replies" % (len(oks), len(pings))
            return "fail", "0/%d replies" % len(pings)
        if ctype == "http":
            if not isinstance(value, list) or not value or not isinstance(value[0], list):
                return "unknown", "no data"
            r = value[0]
            success = r[0] if len(r) > 0 else 0
            msg = r[2] if len(r) > 2 else ""
            code = r[3] if len(r) > 3 else None
            if code not in (None, "", 0):
                return "ok", "HTTP %s" % code       # any HTTP status = reachable
            if success == 1:
                return "ok", str(msg)
            return "fail", str(msg)
    except (TypeError, IndexError, KeyError) as exc:
        return "unknown", "parse error: %s" % exc
    return "unknown", "unsupported check type %s" % ctype


class CheckHost:
    PREFERRED_CONTROL_COUNTRIES = ("de", "nl", "fi", "fr", "se", "gb", "pl", "ch", "at", "cz")

    def __init__(self, cfg: Dict[str, Any], http: Http, log: EventLog, clock: Clock,
                 last_submit: float = 0.0,
                 on_submit: Optional[Callable[[float], None]] = None):
        self.cfg = cfg
        self.http = http
        self.log = log
        self.clock = clock
        self.base = cfg["CHECKHOST_BASE"].rstrip("/")
        self.last_submit = float(last_submit or 0)
        self.on_submit = on_submit
        self._nodes: Optional[Dict[str, Any]] = None
        self._nodes_at = 0.0

    def nodes(self) -> Dict[str, Any]:
        if self._nodes is not None and self.clock.time() - self._nodes_at < 6 * 3600:
            return self._nodes
        resp = self.http.request("GET", self.base + "/nodes/hosts", retries=1)
        j = resp.json if resp.status == 200 else None
        if not isinstance(j, dict) or not isinstance(j.get("nodes"), dict):
            raise TransientError("check-host /nodes/hosts unavailable (HTTP %s)" % resp.status)
        self._nodes, self._nodes_at = j["nodes"], self.clock.time()
        return self._nodes

    def probe_nodes(self) -> List[str]:
        if self.cfg["PROBE_NODES"]:
            return list(self.cfg["PROBE_NODES"])
        try:
            cc = str(self.cfg["PROBE_COUNTRY"]).lower()
            found = sorted(n for n, meta in self.nodes().items()
                           if str((meta.get("location") or [""])[0]).lower() == cc)
            if found:
                return found[: int(self.cfg["PROBE_MAX_NODES"])]
        except TransientError as exc:
            self.log.warning("checkhost_nodes_unavailable", error=str(exc))
        return list(self.cfg["PROBE_NODES_FALLBACK"])

    def control_nodes(self) -> List[str]:
        if self.cfg["CONTROL_NODES"]:
            return list(self.cfg["CONTROL_NODES"])
        try:
            nodes = self.nodes()
            picked: List[str] = []
            for cc in self.PREFERRED_CONTROL_COUNTRIES:
                for n in sorted(nodes):
                    if str((nodes[n].get("location") or [""])[0]).lower() == cc:
                        picked.append(n)
                        break
                if len(picked) >= 3:
                    return picked
            if picked:
                return picked
        except TransientError:
            pass
        return list(self.cfg["CONTROL_NODES_FALLBACK"])

    def _pace(self) -> None:
        gap = float(self.cfg["CHECKHOST_MIN_SPACING_SEC"])
        wait = self.last_submit + gap - self.clock.time()
        if wait > 0:
            self.clock.sleep(wait)

    def submit(self, ctype: str, host: str, nodes: List[str]) -> Tuple[str, Dict[str, Any], str]:
        self._pace()
        q = [("host", host)] + [("node", n) for n in nodes]
        url = "%s/check-%s?%s" % (self.base, ctype, urllib.parse.urlencode(q))
        self.last_submit = self.clock.time()
        if self.on_submit:
            self.on_submit(self.last_submit)
        resp = self.http.request("GET", url, retries=0)
        j = resp.json
        if resp.status == 429 or (isinstance(j, dict) and j.get("error") == "limit_exceeded"):
            raise CheckHostLimit("check-host.net rate limit (limit_exceeded)")
        if resp.status != 200 or not isinstance(j, dict) or not j.get("ok"):
            raise InconclusiveError("check-host submit failed: HTTP %s %s"
                                    % (resp.status, (resp.text or "")[:200]))
        return str(j["request_id"]), dict(j.get("nodes") or {}), str(j.get("permanent_link") or "")

    def results(self, request_id: str, nodes: List[str]) -> Dict[str, Any]:
        deadline = self.clock.time() + float(self.cfg["CHECKHOST_RESULT_WAIT_SEC"])
        poll = float(self.cfg["CHECKHOST_RESULT_POLL_SEC"])
        last: Dict[str, Any] = {}
        while True:
            self.clock.sleep(poll)
            resp = self.http.request("GET", "%s/check-result/%s" % (self.base, request_id),
                                     retries=1)
            j = resp.json
            if resp.status == 200 and isinstance(j, dict):
                last = j
                if all(last.get(n) is not None for n in nodes):
                    return last
            if self.clock.time() >= deadline:
                return last

    def run(self, ctype: str, host: str, nodes: List[str]) -> Tuple[Dict[str, Any], List[str], str]:
        """Submit + collect, with one limit_exceeded backoff. Returns (raw, accepted, link)."""
        for attempt in range(2):
            try:
                rid, accepted, link = self.submit(ctype, host, nodes)
                acc = [n for n in nodes if n in accepted] or list(accepted.keys())
                return self.results(rid, acc), acc, link
            except CheckHostLimit:
                if attempt == 0:
                    self.log.warning("checkhost_limit_backoff",
                                     sleep_sec=self.cfg["CHECKHOST_LIMIT_BACKOFF_SEC"])
                    self.clock.sleep(float(self.cfg["CHECKHOST_LIMIT_BACKOFF_SEC"]))
                    continue
                raise InconclusiveError("check-host.net rate limit persisted")
        raise InconclusiveError("unreachable")  # pragma: no cover


class Reachability:
    """One "cycle" = one check-host request from Iranian + control nodes."""

    def __init__(self, cfg: Dict[str, Any], ch: CheckHost, log: EventLog):
        self.cfg = cfg
        self.ch = ch
        self.log = log

    def target(self, ip: str) -> str:
        t, port = self.cfg["CHECK_TYPE"], int(self.cfg["CHECK_PORT"])
        if t == "tcp":
            return "%s:%d" % (ip, port)
        if t == "http":
            scheme = "https" if port == 443 else "http"
            return "%s://%s:%d%s" % (scheme, ip, port, self.cfg["CHECK_HTTP_PATH"])
        return ip

    def cycle(self, ip: str, purpose: str) -> Dict[str, Any]:
        ctype = self.cfg["CHECK_TYPE"]
        if ctype not in ("tcp", "ping", "http"):
            raise HaltError("CHECK_TYPE must be tcp, ping or http")
        probes = self.ch.probe_nodes()
        controls = [n for n in self.ch.control_nodes() if n not in probes]
        raw, accepted, link = self.ch.run(ctype, self.target(ip), probes + controls)
        per_node = {}
        for n in accepted:
            v, detail = classify_node_result(ctype, raw.get(n))
            per_node[n] = {"v": v, "d": detail, "probe": n in probes}
        ir = {k: x for k, x in per_node.items() if x["probe"]}
        ctl = {k: x for k, x in per_node.items() if not x["probe"]}
        ok = [n for n, x in ir.items() if x["v"] == "ok"]
        fail = [n for n, x in ir.items() if x["v"] == "fail"]
        unknown = [n for n in probes if n not in ok and n not in fail]
        ctl_ok = sum(1 for x in ctl.values() if x["v"] == "ok")
        ctl_concl = sum(1 for x in ctl.values() if x["v"] in ("ok", "fail"))
        res: Dict[str, Any] = {
            "purpose": purpose, "ip": ip, "type": ctype, "target": self.target(ip),
            "link": link, "ok": len(ok), "fail": len(fail), "unknown": len(unknown),
            "control_ok": ctl_ok, "control_conclusive": ctl_concl, "nodes": per_node,
        }
        min_concl = int(self.cfg["MIN_CONCLUSIVE_NODES"])
        thr = float(self.cfg["FAIL_RATIO_THRESHOLD"])

        def finish(verdict: str, why: str) -> Dict[str, Any]:
            concl = res["ok"] + res["fail"]
            res["verdict"], res["why"] = verdict, why
            res["ok_ratio"] = round(res["ok"] / concl, 3) if concl else None
            self.log.check(res)
            lvl = "info" if verdict == REACHABLE else "warning"
            self.log.event(lvl, "reachability_cycle", purpose=purpose, ip=ip, verdict=verdict,
                           ok=res["ok"], fail=res["fail"], unknown=res["unknown"],
                           control_ok=ctl_ok, why=why, link=link)
            return res

        if len(ok) + len(fail) < min_concl:
            return finish(INCONCLUSIVE, "only %d conclusive Iranian nodes (< %d)"
                          % (len(ok) + len(fail), min_concl))
        if len(fail) / float(len(ok) + len(fail)) <= thr:
            return finish(REACHABLE, "%d/%d Iranian nodes reached the target"
                          % (len(ok), len(ok) + len(fail)))
        # --- looks blocked: rule out "server down" and "probe-side outage" ----
        if ctl_ok < int(self.cfg["CONTROL_MIN_SUCCESS"]):
            if ctl_concl == 0:
                return finish(INCONCLUSIVE, "Iran failed but no control node answered")
            return finish(DOWN, "unreachable from control nodes outside Iran too "
                                "(server/service down, not an Iran block)")
        guard = str(self.cfg.get("IRAN_CONTROL_TARGET") or "").strip()
        if guard:
            graw, gacc, glink = self.ch.run("tcp", guard, fail)
            healthy = [n for n in fail if classify_node_result("tcp", graw.get(n))[0] == "ok"]
            res["probe_guard"] = {"target": guard, "link": glink,
                                  "healthy_failing_nodes": healthy}
            dropped = [n for n in fail if n not in healthy]
            if dropped:
                for n in dropped:
                    per_node[n]["d"] += " (ignored: node cannot reach control target)"
                fail = healthy
                res["fail"] = len(fail)
                res["unknown"] = len(unknown) + len(dropped)
            if len(ok) + len(fail) < min_concl:
                return finish(INCONCLUSIVE, "Iranian probe nodes look unhealthy "
                                            "(cannot reach %s)" % guard)
            if len(fail) / float(len(ok) + len(fail)) <= thr:
                return finish(REACHABLE, "after probe-health filtering %d/%d reached"
                              % (len(ok), len(ok) + len(fail)))
        return finish(BLOCKED, "%d/%d Iranian nodes failed while %d control node(s) "
                               "outside Iran succeeded"
                      % (len(fail), len(ok) + len(fail), ctl_ok))


# =============================================================================
# Minimal DNS client (UDP with TCP fallback; A / NS / CNAME) — stdlib only
# =============================================================================
class DnsError(Exception):
    pass


def _split_hostport(spec: str, default_port: int = 53) -> Tuple[str, int]:
    spec = spec.strip()
    if spec.startswith("["):                       # [v6]:port
        host, _, rest = spec[1:].partition("]")
        return host, int(rest[1:]) if rest.startswith(":") else default_port
    if spec.count(":") == 1:
        host, port = spec.split(":")
        return host, int(port)
    return spec, default_port


class DnsClient:
    QTYPE = {"A": 1, "NS": 2, "CNAME": 5, "SOA": 6}
    RTYPE = {v: k for k, v in QTYPE.items()}
    RCODES = {0: "NOERROR", 1: "FORMERR", 2: "SERVFAIL", 3: "NXDOMAIN", 4: "NOTIMP", 5: "REFUSED"}

    def __init__(self, timeout: float = 3.0, retries: int = 2):
        self.timeout = timeout
        self.retries = retries

    @staticmethod
    def _qname(name: str) -> bytes:
        out = b""
        for label in name.rstrip(".").split("."):
            if label:
                raw = label.encode("idna")
                if len(raw) > 63:
                    raise DnsError("label too long")
                out += bytes([len(raw)]) + raw
        return out + b"\x00"

    @staticmethod
    def _read_name(msg: bytes, off: int) -> Tuple[str, int]:
        labels, jumped, end, hops = [], False, off, 0
        while True:
            if off >= len(msg):
                raise DnsError("truncated name")
            ln = msg[off]
            if ln & 0xC0 == 0xC0:
                if off + 1 >= len(msg):
                    raise DnsError("truncated pointer")
                ptr = ((ln & 0x3F) << 8) | msg[off + 1]
                if not jumped:
                    end = off + 2
                jumped, off, hops = True, ptr, hops + 1
                if hops > 64:
                    raise DnsError("compression loop")
                continue
            if ln == 0:
                if not jumped:
                    end = off + 1
                break
            labels.append(msg[off + 1: off + 1 + ln].decode("ascii", "replace"))
            off += 1 + ln
        return ".".join(labels).lower(), end

    def _parse(self, msg: bytes, qid: int) -> Dict[str, Any]:
        if len(msg) < 12:
            raise DnsError("short response")
        rid, flags, qd, an, ns, ar = struct.unpack(">HHHHHH", msg[:12])
        if rid != qid:
            raise DnsError("id mismatch")
        off = 12
        for _ in range(qd):
            _, off = self._read_name(msg, off)
            off += 4
        sections: Dict[str, List[Dict[str, Any]]] = {"answer": [], "authority": [], "additional": []}
        for sec, cnt in (("answer", an), ("authority", ns), ("additional", ar)):
            for _ in range(cnt):
                name, off = self._read_name(msg, off)
                rtype, _rclass, ttl, rdlen = struct.unpack(">HHIH", msg[off: off + 10])
                off += 10
                rdata = msg[off: off + rdlen]
                val: Any = None
                if rtype == 1 and rdlen == 4:
                    val = socket.inet_ntoa(rdata)
                elif rtype in (2, 5):
                    val, _ = self._read_name(msg, off)
                sections[sec].append({"name": name, "type": self.RTYPE.get(rtype, rtype),
                                      "ttl": ttl, "value": val})
                off += rdlen
        return {"rcode": self.RCODES.get(flags & 0xF, str(flags & 0xF)),
                "aa": bool(flags & 0x0400), "tc": bool(flags & 0x0200), **sections}

    def query(self, server: str, name: str, qtype: str = "A", rd: bool = True) -> Dict[str, Any]:
        host, port = _split_hostport(server)
        qid = random.randint(0, 0xFFFF)
        flags = 0x0100 if rd else 0x0000
        pkt = struct.pack(">HHHHHH", qid, flags, 1, 0, 0, 0) + self._qname(name) + \
            struct.pack(">HH", self.QTYPE[qtype], 1)
        fam = socket.AF_INET6 if ":" in host else socket.AF_INET
        last: Optional[Exception] = None
        for _ in range(self.retries + 1):
            try:
                with socket.socket(fam, socket.SOCK_DGRAM) as s:
                    s.settimeout(self.timeout)
                    s.sendto(pkt, (host, port))
                    while True:
                        data, _ = s.recvfrom(65535)
                        try:
                            res = self._parse(data, qid)
                            break
                        except DnsError as exc:
                            if "id mismatch" in str(exc):
                                continue
                            raise
                if res["tc"]:
                    res = self._query_tcp(host, port, fam, pkt, qid)
                return res
            except (socket.timeout, OSError, DnsError, struct.error) as exc:
                last = exc
        raise DnsError("query %s %s @%s failed: %s" % (name, qtype, server, last))

    def _query_tcp(self, host: str, port: int, fam: int, pkt: bytes, qid: int) -> Dict[str, Any]:
        with socket.socket(fam, socket.SOCK_STREAM) as s:
            s.settimeout(self.timeout)
            s.connect((host, port))
            s.sendall(struct.pack(">H", len(pkt)) + pkt)
            hdr = s.recv(2)
            ln = struct.unpack(">H", hdr)[0]
            buf = b""
            while len(buf) < ln:
                chunk = s.recv(ln - len(buf))
                if not chunk:
                    break
                buf += chunk
        return self._parse(buf, qid)


class DnsVerifier:
    """Checks that DNS names resolve to an expected IP on authoritative + public resolvers."""

    def __init__(self, cfg: Dict[str, Any], log: EventLog, client: Optional[DnsClient] = None):
        self.cfg = cfg
        self.log = log
        self.client = client or DnsClient()
        self.zone = str(cfg["DNS_ZONE"]).rstrip(".").lower()
        self._auth_cache: Optional[List[str]] = None
        self.ns_names: List[str] = []      # NS names found by auto-discovery (preflight compares)

    def fqdns(self) -> List[str]:
        out = []
        for n in self.cfg["DNS_NAMES"]:
            n = str(n).strip().rstrip(".").lower()
            if n in ("@", "", self.zone):
                out.append(self.zone)
            elif n.endswith("." + self.zone):
                out.append(n)
            else:
                out.append("%s.%s" % (n, self.zone))
        return out

    def relative(self, fqdn: str) -> str:
        return "@" if fqdn == self.zone else fqdn[: -(len(self.zone) + 1)]

    def _resolve_host(self, host: str) -> List[str]:
        if _is_ipv4(host):
            return [host]
        for r in self.cfg["DNS_PUBLIC_RESOLVERS"]:
            try:
                res = self.client.query(r, host, "A", rd=True)
                ips = [a["value"] for a in res["answer"] if a["type"] == "A"]
                if ips:
                    return ips
            except DnsError:
                continue
        try:
            return [socket.gethostbyname(host)]
        except OSError:
            return []

    def authoritative_servers(self) -> List[str]:
        if self._auth_cache is not None:
            return self._auth_cache
        servers: List[str] = []
        if self.cfg["DNS_AUTHORITATIVE_NS"]:
            for spec in self.cfg["DNS_AUTHORITATIVE_NS"]:
                host, port = _split_hostport(str(spec))
                for ip in self._resolve_host(host):
                    servers.append("%s:%d" % (ip, port))
        else:
            ns_names: List[str] = []
            for r in self.cfg["DNS_PUBLIC_RESOLVERS"]:
                try:
                    res = self.client.query(r, self.zone, "NS", rd=True)
                    ns_names = [a["value"] for a in res["answer"] if a["type"] == "NS"]
                    if ns_names:
                        break
                except DnsError:
                    continue
            self.ns_names = sorted({str(n).rstrip(".").lower() for n in ns_names})
            for ns in sorted(set(ns_names)):
                for ip in self._resolve_host(ns):
                    servers.append("%s:53" % ip)
        if not servers:
            raise TransientError("could not determine authoritative nameservers for %s" % self.zone)
        self._auth_cache = sorted(set(servers))
        return self._auth_cache

    def _lookup(self, server: str, fqdn: str, authoritative: bool) -> Dict[str, Any]:
        try:
            res = self.client.query(server, fqdn, "A", rd=not authoritative)
        except DnsError as exc:
            return {"error": str(exc), "ips": [], "ttl": None}
        a = [x for x in res["answer"] if x["type"] == "A"]
        cn = [x["value"] for x in res["answer"] if x["type"] == "CNAME"]
        out = {"rcode": res["rcode"], "ips": sorted({x["value"] for x in a}),
               "ttl": max([x["ttl"] for x in a], default=None), "cname": cn}
        if authoritative and not res["aa"] and res["rcode"] == "NOERROR":
            out["warning"] = "answer not authoritative (AA=0)"
        return out

    def evaluate(self, expect_ip: str, old_ip: Optional[str] = None,
                 names: Optional[List[str]] = None) -> Dict[str, Any]:
        """Return per-name results + overall booleans. Never raises on lookup errors.
        `names` limits the check to these FQDNs (default: every name in DNS_NAMES)."""
        report: Dict[str, Any] = {"expect": expect_ip, "old": old_ip, "names": {},
                                  "auth_ok": True, "public_ok": True, "old_absent": True,
                                  "max_auth_ttl": 0, "problems": []}
        fqdns = self.fqdns() if names is None else list(names)
        if not fqdns:
            report["ok"] = True
            return report
        try:
            auth = self.authoritative_servers()
        except TransientError as exc:
            report.update(auth_ok=False, public_ok=False, ok=False)
            report["problems"].append(str(exc))
            return report
        for fqdn in fqdns:
            entry: Dict[str, Any] = {"authoritative": {}, "public": {}}
            for s in auth:
                r = self._lookup(s, fqdn, authoritative=True)
                entry["authoritative"][s] = r
                if r.get("ttl"):
                    report["max_auth_ttl"] = max(report["max_auth_ttl"], int(r["ttl"]))
                if expect_ip not in r["ips"]:
                    report["auth_ok"] = False
                    report["problems"].append("%s @%s (authoritative) -> %s%s" % (
                        fqdn, s, r["ips"] or r.get("error") or r.get("rcode"),
                        (" CNAME %s" % r["cname"]) if r.get("cname") else ""))
                if old_ip and old_ip in r["ips"]:
                    report["old_absent"] = False
            for s in self.cfg["DNS_PUBLIC_RESOLVERS"]:
                r = self._lookup(s, fqdn, authoritative=False)
                entry["public"][s] = r
                if expect_ip not in r["ips"]:
                    report["public_ok"] = False
                    report["problems"].append("%s @%s (public) -> %s" % (
                        fqdn, s, r["ips"] or r.get("error") or r.get("rcode")))
                if old_ip and old_ip in r["ips"]:
                    report["old_absent"] = False
            report["names"][fqdn] = entry
        need_old_absent = bool(self.cfg["DNS_REQUIRE_OLD_ABSENT"]) and old_ip
        report["ok"] = report["auth_ok"] and report["public_ok"] and \
            (report["old_absent"] or not need_old_absent)
        return report


# =============================================================================
# Linux networking (iproute2).  Tests substitute a fake with the same methods.
# =============================================================================
def run_hook(cmd: str, action: str, payload: Dict[str, Any], log: EventLog,
             timeout: int = 300) -> int:
    """Run an optional external hook: <cmd...> <action> <json-payload>."""
    if not cmd:
        return 0
    argv = shlex.split(cmd) + [action, json.dumps(redact(payload))]
    try:
        p = subprocess.run(argv, capture_output=True, text=True, timeout=timeout,
                           env=dict(os.environ, ROTATOR_ACTION=action))
    except (OSError, subprocess.TimeoutExpired) as exc:
        log.error("hook_failed_to_run", action=action, cmd=argv[0], error=str(exc))
        return 127
    log.event("info" if p.returncode == 0 else "error", "hook_ran", action=action,
              cmd=argv[0], rc=p.returncode, stdout=p.stdout[-500:], stderr=p.stderr[-500:])
    return p.returncode


_WATCHDOGS: Dict[int, "subprocess.Popen[bytes]"] = {}


class LinuxNet:
    def __init__(self, cfg: Dict[str, Any], log: EventLog, clock: Clock, state_dir: str,
                 read_only: bool = False):
        self.cfg = cfg
        self.log = log
        self.clock = clock
        self.state_dir = state_dir
        self.read_only = read_only

    # -- plumbing -----------------------------------------------------------------
    def _run(self, args: List[str], check: bool = True) -> str:
        p = subprocess.run(["ip"] + args, capture_output=True, text=True, timeout=30)
        if check and p.returncode != 0:
            raise RotatorError("ip %s failed (rc=%d): %s" % (" ".join(args), p.returncode,
                                                             p.stderr.strip()[:300]))
        return p.stdout

    def _mut(self, args: List[str], check: bool = True) -> str:
        if self.read_only:
            raise RotatorError("SAFETY: refusing 'ip %s' in read-only/dry-run mode" % " ".join(args))
        self.log.info("net_cmd", cmd="ip " + " ".join(args))
        return self._run(args, check=check)

    def _json(self, args: List[str]) -> List[Dict[str, Any]]:
        out = self._run(["-j"] + args, check=False).strip()
        try:
            return json.loads(out) if out else []
        except ValueError:
            return []

    def available(self) -> Tuple[bool, str]:
        from shutil import which
        if which("ip") is None:
            return False, "iproute2 'ip' command not found"
        if os.geteuid() != 0:
            return False, "not running as root (needed to change addresses/routes/sysctls)"
        return True, "ok"

    # -- inspection ---------------------------------------------------------------
    def iface_for_mac(self, mac: str) -> Optional[str]:
        mac = (mac or "").lower()
        for link in self._json(["link", "show"]):
            if str(link.get("address", "")).lower() == mac:
                return link.get("ifname")
        return None

    def find_ip(self, ip: str) -> Optional[str]:
        for a in self._json(["addr", "show"]):
            for ai in a.get("addr_info", []):
                if ai.get("local") == ip:
                    return a.get("ifname")
        return None

    def ip_prefixlen(self, ip: str) -> Optional[int]:
        for a in self._json(["addr", "show"]):
            for ai in a.get("addr_info", []):
                if ai.get("local") == ip:
                    return int(ai.get("prefixlen"))
        return None

    def default_routes(self) -> List[Dict[str, Any]]:
        out = []
        for r in self._json(["route", "show", "default", "table", "main"]):
            out.append({"gateway": r.get("gateway"), "dev": r.get("dev"),
                        "metric": int(r.get("metric") or 0), "protocol": r.get("protocol"),
                        "prefsrc": r.get("prefsrc")})
        return out

    def route_get(self, dst: str = "1.1.1.1") -> Dict[str, Any]:
        r = self._json(["route", "get", dst])
        return r[0] if r else {}

    def used_tables(self) -> set:
        used = set()
        for rule in self._json(["rule", "show"]):
            t = rule.get("table")
            if t is not None and str(t).isdigit():
                used.add(int(t))
        return used

    # -- configuration --------------------------------------------------------------
    def link_up(self, ifname: str) -> None:
        self._mut(["link", "set", "dev", ifname, "up"])

    def ensure_addr(self, ip: str, prefixlen: int, ifname: str) -> None:
        if self.find_ip(ip) == ifname:
            return
        self._mut(["addr", "add", "%s/%d" % (ip, prefixlen), "dev", ifname])

    def remove_addr(self, ip: str, prefixlen: int, ifname: str) -> None:
        self._mut(["addr", "del", "%s/%d" % (ip, prefixlen), "dev", ifname], check=False)

    def ensure_policy(self, ip: str, cidr: str, gw: str, ifname: str, table: int,
                      prio: int) -> None:
        """Source-based routing so traffic FROM `ip` always leaves via `ifname`."""
        net = ipaddress.ip_network(cidr, strict=False)
        self._mut(["route", "replace", str(net), "dev", ifname, "src", ip, "table", str(table)])
        self._mut(["route", "replace", "default", "via", gw, "dev", ifname, "table", str(table)])
        for rule in self._json(["rule", "show"]):
            if rule.get("src") == ip and str(rule.get("table")) == str(table):
                return
        self._mut(["rule", "add", "from", "%s/32" % ip, "lookup", str(table),
                   "priority", str(prio)])

    def remove_policy(self, ip: str, table: Optional[int]) -> None:
        for rule in self._json(["rule", "show"]):
            if rule.get("src") == ip:
                args = ["rule", "del", "from", "%s/32" % ip]
                if rule.get("table") is not None:
                    args += ["lookup", str(rule.get("table"))]
                self._mut(args, check=False)
        if table:
            self._mut(["route", "flush", "table", str(table)], check=False)

    def remove_default_routes_via(self, ifname: str, keep: List[Dict[str, Any]]) -> List[Dict]:
        removed = []
        keep_keys = {(k.get("gateway"), k.get("dev"), int(k.get("metric") or 0)) for k in keep}
        for r in self.default_routes():
            key = (r.get("gateway"), r.get("dev"), int(r.get("metric") or 0))
            if r.get("dev") == ifname and key not in keep_keys:
                args = ["route", "del", "default"]
                if r.get("gateway"):
                    args += ["via", r["gateway"]]
                args += ["dev", ifname, "metric", str(r.get("metric") or 0)]
                self._mut(args, check=False)
                removed.append(r)
        return removed

    def tune_sysctls(self, ifnames: List[str]) -> None:
        if self.read_only:
            return
        settings = [("net/ipv4/conf/all/rp_filter", "2"),
                    ("net/ipv4/conf/all/arp_ignore", "1"),
                    ("net/ipv4/conf/all/arp_announce", "2")]
        for i in ifnames:
            if i:
                settings.append(("net/ipv4/conf/%s/rp_filter" % i, "2"))
        for key, val in settings:
            try:
                with open("/proc/sys/" + key, "w") as fh:
                    fh.write(val)
            except OSError as exc:
                self.log.warning("sysctl_failed", key=key.replace("/", "."), error=str(exc))

    # -- default-route switch with dead-man watchdog --------------------------------
    @staticmethod
    def _restore_cmd(r: Dict[str, Any]) -> List[str]:
        args = ["route", "replace", "default"]
        if r.get("gateway"):
            args += ["via", r["gateway"]]
        args += ["dev", r["dev"]]
        if r.get("prefsrc"):
            args += ["src", r["prefsrc"]]
        if r.get("metric"):
            args += ["metric", str(r["metric"])]
        if r.get("protocol") in ("dhcp", "static", "boot", "ra"):
            args += ["proto", r["protocol"]]
        return args

    def switch_plan(self, gw: str, ifname: str, src: str,
                    before: List[Dict[str, Any]]) -> Dict[str, List[List[str]]]:
        metrics = [int(r.get("metric") or 0) for r in before]
        if before and min(metrics) > 0:
            m = min(metrics) - 1      # win by metric, keep old route as fallback
            apply = [["route", "replace", "default", "via", gw, "dev", ifname, "src", src,
                      "metric", str(m)]]
            revert = [["route", "del", "default", "via", gw, "dev", ifname, "metric", str(m)]]
        else:                         # metric 0 -> must replace in place
            apply = [["route", "replace", "default", "via", gw, "dev", ifname, "src", src]]
            revert = [["route", "del", "default", "via", gw, "dev", ifname]]
        revert += [self._restore_cmd(r) for r in before]
        return {"apply": apply, "revert": revert}

    def run_cmds(self, cmds: List[List[str]], check: bool = True) -> None:
        for c in cmds:
            self._mut(c, check=check)

    def start_watchdog(self, revert: List[List[str]], timeout: int, tag: str) -> Dict[str, Any]:
        if self.read_only:
            raise RotatorError("SAFETY: no watchdog in read-only mode")
        claim = os.path.join(self.state_dir, "switch-%s.claim" % tag)   # mkdir = atomic mutex
        marker = os.path.join(self.state_dir, "switch-%s.reverted" % tag)
        with contextlib.suppress(FileNotFoundError):
            os.unlink(marker)
        with contextlib.suppress(FileNotFoundError, OSError):
            os.rmdir(claim)
        lines = ["sleep %d" % int(timeout), "if mkdir %s 2>/dev/null; then" % shlex.quote(claim)]
        lines += ["  ip %s >/dev/null 2>&1 || true" % " ".join(shlex.quote(a) for a in c)
                  for c in revert]
        lines += ["  echo reverted > %s" % shlex.quote(marker), "fi"]
        proc = subprocess.Popen(["/bin/sh", "-c", "\n".join(lines)], start_new_session=True,
                                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL, close_fds=True)
        _WATCHDOGS[proc.pid] = proc
        self.log.info("route_watchdog_started", pid=proc.pid, timeout_sec=timeout)
        return {"pid": proc.pid, "claim": claim, "marker": marker}

    def confirm_watchdog(self, wd: Optional[Dict[str, Any]]) -> bool:
        """Disarm atomically. Returns False if the watchdog won the race and reverted."""
        if not wd:
            return True
        try:
            os.mkdir(wd["claim"])
            won = True
        except FileExistsError:
            won = False
        if won:
            with contextlib.suppress(OSError):
                os.killpg(int(wd["pid"]), signal.SIGTERM)
        else:                                   # watchdog is reverting: let it finish
            deadline = time.time() + 30
            while not os.path.exists(wd["marker"]) and time.time() < deadline:
                time.sleep(0.5)
        proc = _WATCHDOGS.pop(int(wd["pid"]), None)
        if proc is not None:
            with contextlib.suppress(Exception):
                proc.wait(timeout=5)
        with contextlib.suppress(OSError):
            os.rmdir(wd["claim"])
        return won

    # -- egress probes ------------------------------------------------------------------
    def egress_ip(self, source_ip: Optional[str] = None) -> Optional[str]:
        seen: Dict[str, int] = {}
        for url in self.cfg["EGRESS_ECHO_URLS"]:
            try:
                txt = fetch_text_bound(url, source_ip, timeout=8.0,
                                       ua=self.cfg["HTTP_USER_AGENT"])
            except Exception as exc:  # noqa: BLE001 - any failure = no vote
                self.log.debug("egress_probe_failed", url=url, src=source_ip, error=str(exc))
                continue
            ip = txt.split()[0] if txt.split() else ""
            if _is_ipv4(ip):
                seen[ip] = seen.get(ip, 0) + 1
                if seen[ip] >= 2:
                    return ip
        return max(seen, key=lambda k: seen[k]) if seen else None

    # -- reboot persistence (optional) --------------------------------------------------
    def write_netplan(self, path: str, mac: str, ip: str, prefixlen: int, gw: str,
                      dns: List[str]) -> None:
        if self.read_only:
            return
        lines = [
            "# Managed by arvan_ip_rotator.py - persists the CURRENT public NIC across reboots.",
            "# Regenerated after every successful rotation. 'netplan generate' only; not applied.",
            "network:", "  version: 2", "  ethernets:", "    arvanrot-current:",
            "      match:", '        macaddress: "%s"' % mac.lower(),
            "      dhcp4: false", '      addresses: ["%s/%d"]' % (ip, prefixlen),
            "      routes:", "        - to: default", '          via: "%s"' % gw,
        ]
        if dns:
            lines += ["      nameservers:",
                      "        addresses: [%s]" % ", ".join('"%s"' % d for d in dns)]
        old = None
        if os.path.exists(path):
            with open(path) as fh:
                old = fh.read()
        tmp = path + ".tmp"
        with open(tmp, "w") as fh:
            fh.write("\n".join(lines) + "\n")
        os.chmod(tmp, 0o600)
        os.replace(tmp, path)
        p = subprocess.run(["netplan", "generate"], capture_output=True, text=True, timeout=60)
        if p.returncode != 0:
            if old is None:
                os.unlink(path)
            else:
                with open(path, "w") as fh:
                    fh.write(old)
            raise RotatorError("netplan generate rejected %s: %s" % (path, p.stderr[-300:]))


# =============================================================================
# Alerts (webhook / Telegram / command) + local audit + retry outbox
# =============================================================================
class Alerter:
    LEVELS = {"debug": 10, "info": 20, "warning": 30, "error": 40, "critical": 50}

    def __init__(self, cfg: Dict[str, Any], http: Http, log: EventLog, state_dir: str,
                 clock: Clock, readonly: bool = False):
        self.cfg = cfg
        self.http = http
        self.log = log
        self.clock = clock
        self.readonly = readonly
        self.webhook = os.environ.get(cfg["ALERT_WEBHOOK_URL_ENV"], "").strip()
        self.tg_token = os.environ.get(cfg["ALERT_TELEGRAM_TOKEN_ENV"], "").strip()
        self.tg_chat = os.environ.get(cfg["ALERT_TELEGRAM_CHAT_ENV"], "").strip()
        self.cmd = str(cfg.get("ALERT_COMMAND") or "").strip()
        self.min_level = self.LEVELS.get(str(cfg["ALERT_MIN_LEVEL"]).lower(), 30)
        self.outbox = os.path.join(state_dir, "alert_outbox.jsonl")
        self.context: Dict[str, Any] = {"host": socket.gethostname()}

    def channels(self) -> List[str]:
        ch = []
        if self.webhook:
            ch.append("webhook")
        if self.tg_token and self.tg_chat:
            ch.append("telegram")
        if self.cmd:
            ch.append("command")
        return ch

    def _deliver(self, channel: str, payload: Dict[str, Any]) -> None:
        if channel == "webhook":
            r = self.http.request("POST", self.webhook, json_body=payload, idempotent=True,
                                  retries=1, timeout=15)
            if not 200 <= r.status < 300:
                raise RotatorError("webhook HTTP %d" % r.status)
        elif channel == "telegram":
            text = "[%s] arvan-ip-rotator@%s\n%s" % (payload["level"].upper(),
                                                    payload.get("host"), payload["title"])
            if payload.get("details"):
                text += "\n" + json.dumps(payload["details"], ensure_ascii=False, indent=1)[:3500]
            url = "https://api.telegram.org/bot%s/sendMessage" % self.tg_token
            r = self.http.request("POST", url, json_body={"chat_id": self.tg_chat, "text": text},
                                  idempotent=True, retries=1, timeout=15)
            if not 200 <= r.status < 300:
                raise RotatorError("telegram HTTP %d" % r.status)
        elif channel == "command":
            p = subprocess.run(shlex.split(self.cmd) + [json.dumps(payload, ensure_ascii=False)],
                               capture_output=True, text=True, timeout=60)
            if p.returncode != 0:
                raise RotatorError("alert command rc=%d %s" % (p.returncode, p.stderr[-200:]))

    def send(self, level: str, title: str, details: Optional[Dict[str, Any]] = None,
             force: bool = False) -> bool:
        payload = dict(self.context)
        payload.update({"ts": iso(), "level": level, "title": title,
                        "details": redact(details or {})})
        self.log.event(level if level in self.LEVELS else "info", "alert", title=title,
                       details=payload["details"])
        self.log._write("alerts.jsonl", payload)
        if self.readonly or (self.LEVELS.get(level, 20) < self.min_level and not force):
            return True
        ok = True
        for ch in self.channels():
            try:
                self._deliver(ch, payload)
            except Exception as exc:  # noqa: BLE001
                ok = False
                self.log.warning("alert_delivery_failed", channel=ch, error=str(exc))
                self._queue(ch, payload)
        if not self.channels():
            self.log.debug("alert_no_channels", title=title)
        return ok

    def _queue(self, channel: str, payload: Dict[str, Any]) -> None:
        with contextlib.suppress(OSError):
            os.makedirs(os.path.dirname(self.outbox), exist_ok=True)
            with open(self.outbox, "a", encoding="utf-8") as fh:
                fh.write(json.dumps({"channel": channel, "queued_at": self.clock.time(),
                                     "payload": payload}) + "\n")

    def flush_outbox(self) -> None:
        if self.readonly or not os.path.exists(self.outbox):
            return
        try:
            with open(self.outbox, encoding="utf-8") as fh:
                items = [json.loads(line) for line in fh if line.strip()]
        except (OSError, ValueError):
            return
        keep = []
        for it in items[-500:]:
            if self.clock.time() - float(it.get("queued_at", 0)) > 3 * 86400:
                continue
            try:
                self._deliver(it["channel"], it["payload"])
            except Exception:  # noqa: BLE001
                keep.append(it)
        tmp = self.outbox + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            for it in keep:
                fh.write(json.dumps(it) + "\n")
        os.replace(tmp, self.outbox)


# =============================================================================
# Rotator — the make-before-break state machine
# =============================================================================
class RotationRefused(RotatorError):
    """A rotation is needed/requested but a safety gate refuses it (nothing changed)."""


ROUTE_PROBE_DST = "1.1.1.1"
MAX_TRANSIENT_ERRORS_PER_PHASE = 30


class Rotator:
    """Make-before-break state machine (phases: see PHASES).

    SAFETY GATES - each is marked "SAFETY GATE <n>" where the code enforces it:
       0 start-up     state belongs to this server/region; live inventory reconciled first
       1 detection    N consecutive BLOCKED consensus verdicts (INCONCLUSIVE/DOWN never count)
       2 anti-loop    cooldown, failure back-off, hourly/daily caps -> alert instead of rotating
       3 pre-allocate server ACTIVE/idle, IP headroom, DNS precheck + zone audit, write-ahead
       4 allocate     the billable POST is never blindly retried; lost replies reconciled by port diff
       5 attach       new port ACTIVE on THIS server, new IP on a local NIC, egress from it works
       6 verify       new IP reachable from Iran in VERIFY_CYCLES independent cycles
       7 switch       watchdog-protected route switch; egress must equal the new IP
       8 DNS          authoritative + public resolvers show the new IP (proxied Cloudflare
                      records: API read-back), else HALT
       9 drain        wait TTL + margin while the old IP keeps answering
      10 pre-release  gates 5-8 re-checked immediately before touching the old IP
      11 release      detach exactly the recorded old port, then verify it is gone
    Any gate failure -> HALT (state saved, alert sent). The old IP is never released
    unless gates 5-10 all passed for the new IP in this rotation.
    """

    def __init__(self, cfg: Dict[str, Any], log: EventLog, store: StateStore, http: Http,
                 api: ArvanAPI, ch: CheckHost, reach: Reachability, dns: DnsVerifier,
                 net: Any, alerter: Alerter, clock: Clock, dry_run: bool = False,
                 cf: Optional[CloudflareAPI] = None):
        self.cfg, self.log, self.store, self.http = cfg, log, store, http
        self.api, self.ch, self.reach, self.dns = api, ch, reach, dns
        self.net, self.alerter, self.clock, self.dry_run = net, alerter, clock, dry_run
        self.cf = cf                                   # DNS_UPDATE_MODE=cloudflare_api only
        self.state = store.load()
        self.ch.last_submit = max(self.ch.last_submit,
                                  float(self.state.get("checkhost_last_submit") or 0))
        self.ch.on_submit = self._on_checkhost_submit
        self.alerter.context.update({"server_id": api.server_id, "region": cfg["REGION"]})

    # ------------------------------------------------------------------ basics --
    def now(self) -> float:
        return self.clock.time()

    def save(self) -> None:
        self.store.save(self.state)

    def _on_checkhost_submit(self, ts: float) -> None:
        self.state["checkhost_last_submit"] = ts

    def _set_phase(self, rot: Dict[str, Any], phase: str) -> None:
        prev = rot.get("phase")
        rot["phase"] = phase
        rot.setdefault("trail", []).append([phase, self.now()])
        rot["transient_errors"] = 0
        self.save()
        self.log.info("phase", rotation=rot.get("id"), prev=prev, phase=phase,
                      old_ip=(rot.get("old") or {}).get("ip"),
                      new_ip=(rot.get("new") or {}).get("ip"))

    def alert_throttled(self, key: str, every: float, level: str, title: str,
                        details: Optional[Dict[str, Any]] = None) -> None:
        warned = self.state.setdefault("warned", {})
        last = warned.get(key)
        if last and self.now() - float(last) < every:
            self.log.debug("alert_suppressed", key=key, title=title)
            return
        warned[key] = self.now()
        self.save()
        self.alerter.send(level, title, details)

    def recovery_hint(self) -> str:
        rot = self.state.get("rotation")
        me = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else "arvan_ip_rotator.py"
        if not rot:
            return "Fix the cause, then: %s ack --yes" % me
        if phase_index(rot["phase"]) >= phase_index("RELEASING"):
            return ("Old-IP release already started. Fix the cause, then: %s ack --yes && %s resume"
                    % (me, me))
        return ("Old IP %s is still attached. Inspect with '%s status'. Then EITHER fix the "
                "cause and run '%s ack --yes && %s resume', OR roll back with "
                "'%s ack --yes && %s discard-pending --yes' (releases only the NEW IP%s)."
                % ((rot.get("old") or {}).get("ip"), me, me, me, me, me,
                   " %s" % rot["new"]["ip"] if rot.get("new") else ""))

    def halt(self, reason: str) -> None:
        rot = self.state.get("rotation")
        self.state["halt"] = {"reason": reason, "at": self.now(), "at_iso": iso(),
                              "phase": rot.get("phase") if rot else None,
                              "rotation_id": rot.get("id") if rot else None,
                              "last_alert_at": self.now()}
        try:
            self.save()
        finally:              # alert even if the state write fails (e.g. disk full)
            self.log.critical("halted", reason=reason, phase=self.state["halt"]["phase"])
            self.alerter.send("critical", "HALTED: %s" % reason, {
                "phase": self.state["halt"]["phase"],
                "old_ip": (rot or {}).get("old", {}).get("ip") if rot else
                (self.state.get("current") or {}).get("ip"),
                "new_ip": ((rot or {}).get("new") or {}).get("ip") if rot else None,
                "recovery": self.recovery_hint()})

    def remind_if_halted(self) -> None:
        h = self.state.get("halt")
        if not h:
            return
        if self.now() - float(h.get("last_alert_at") or 0) >= float(self.cfg["ALERT_REMIND_EVERY_SEC"]):
            h["last_alert_at"] = self.now()
            self.save()
            self.alerter.send("critical", "STILL HALTED since %s: %s" % (h.get("at_iso"), h["reason"]),
                              {"recovery": self.recovery_hint()})

    # ----------------------------------------------------------------- limits --
    def limits(self) -> Tuple[bool, str]:
        # SAFETY GATE 2 (anti-loop): cooldown after a completed rotation, back-off after a
        # failed attempt, and hourly/daily caps on IP allocations. When this gate blocks a
        # needed rotation the daemon alerts instead of rotating.
        cfg, st, now = self.cfg, self.state, self.now()
        lc = st.get("last_change_at")
        cooldown = float(cfg["COOLDOWN_AFTER_CHANGE_SEC"])
        if lc and now - float(lc) < cooldown:
            return False, "cooldown: last rotation %ds ago (< %ds)" % (now - lc, cooldown)
        lf = st.get("last_failed_attempt_at")
        backoff = float(cfg["RETRY_BACKOFF_AFTER_FAILED_ATTEMPT_SEC"])
        if lf and now - float(lf) < backoff:
            return False, "backoff: last failed attempt %ds ago (< %ds)" % (now - lf, backoff)
        allocs = [t for t in st.get("allocations", []) if now - float(t) < 86400]
        st["allocations"] = allocs
        hour = [t for t in allocs if now - float(t) < 3600]
        if len(hour) >= int(cfg["MAX_CHANGES_PER_HOUR"]):
            return False, "hourly cap reached (%d/%d IP allocations in the last hour)" % (
                len(hour), int(cfg["MAX_CHANGES_PER_HOUR"]))
        if len(allocs) >= int(cfg["MAX_CHANGES_PER_DAY"]):
            return False, "daily cap reached (%d/%d IP allocations in the last 24h)" % (
                len(allocs), int(cfg["MAX_CHANGES_PER_DAY"]))
        return True, "ok"

    # -------------------------------------------------------------- bootstrap --
    def bootstrap(self) -> Tuple[Dict[str, Any], List[Dict[str, Any]], List[Dict[str, Any]]]:
        # SAFETY GATE 0 (start-up): before acting, read the live server/ports and refuse
        # to continue if the state file belongs to another server/region, the server name
        # is unexpected, or the tracked current IP vanished. Public IPs this tool did not
        # allocate are recorded as 'untracked' and never touched.
        """Reconcile local state with ArvanCloud. Halts on anything surprising."""
        st, cfg = self.state, self.cfg
        if st.get("server_id") and st["server_id"] != self.api.server_id:
            raise HaltError("state file belongs to server %s but this run targets %s; refusing"
                            % (st["server_id"], self.api.server_id))
        if st.get("region") and st["region"] != cfg["REGION"]:
            raise HaltError("state file region %s != configured REGION %s"
                            % (st["region"], cfg["REGION"]))
        server = self.api.get_server()
        exp = str(cfg.get("EXPECTED_SERVER_NAME") or "")
        if exp and server.get("name") != exp:
            raise HaltError("server %s is named %r, expected %r (EXPECTED_SERVER_NAME)"
                            % (self.api.server_id, server.get("name"), exp))
        ports = self.api.list_server_ports()
        inv = self.api.public_inventory(server, ports)
        if not self.dry_run:
            st["server_id"], st["region"] = self.api.server_id, cfg["REGION"]
        by_ip = {x["ip"]: x for x in inv}
        rot = st.get("rotation")
        cur = st.get("current")
        if cur is None:
            want = str(cfg.get("ADOPT_CURRENT_IP") or "").strip()
            if want:
                if want not in by_ip:
                    raise HaltError("ADOPT_CURRENT_IP %s is not attached to the server (attached: %s)"
                                    % (want, sorted(by_ip)))
                pick = by_ip[want]
            elif len(inv) == 1:
                pick = inv[0]
            elif not inv:
                raise HaltError("server has no public IPv4 attached; nothing to manage")
            else:
                raise HaltError("server has %d public IPv4s (%s); set ADOPT_CURRENT_IP to the one "
                                "clients use" % (len(inv), ", ".join(sorted(by_ip))))
            st["current"] = {"ip": pick["ip"], "port_id": pick["port_id"], "mac": pick["mac"],
                             "network_id": pick["network_id"], "table": None,
                             "since": self.now()}
            if not self.dry_run:
                self.log.info("adopted_current_ip", ip=pick["ip"], port_id=pick["port_id"])
                self.alerter.send("info", "Now managing public IP %s" % pick["ip"])
        else:
            if cur["ip"] not in by_ip:
                releasing = rot and phase_index(rot["phase"]) >= phase_index("RELEASING") \
                    and (rot.get("old") or {}).get("ip") == cur["ip"]
                if not releasing:
                    raise HaltError("current public IP %s is no longer attached to server %s "
                                    "(changed outside this tool?). Attached: %s"
                                    % (cur["ip"], self.api.server_id, sorted(by_ip) or "none"))
            elif by_ip[cur["ip"]]["port_id"] != cur.get("port_id"):
                self.log.warning("current_port_changed", ip=cur["ip"], old=cur.get("port_id"),
                                 new=by_ip[cur["ip"]]["port_id"])
                cur["port_id"] = by_ip[cur["ip"]]["port_id"]
        known = {st["current"]["ip"]}
        pending_ports = set()
        if rot:
            for k in ("old", "new"):
                if rot.get(k):
                    known.add(rot[k]["ip"])
            if rot["phase"] == "PRE_ALLOCATE":
                pending_ports = {x["port_id"] for x in inv
                                 if x["port_id"] not in set(rot.get("ports_before") or [])}
        untracked = sorted(ip for ip, x in by_ip.items()
                           if ip not in known and x["port_id"] not in pending_ports)
        if untracked != st.get("untracked_public_ips"):
            st["untracked_public_ips"] = untracked
            if untracked and not self.dry_run:
                self.alert_throttled("untracked:" + ",".join(untracked), 86400, "warning",
                                     "Untracked public IPs attached (never touched by this tool): %s"
                                     % ", ".join(untracked))
        if not self.dry_run:
            self.save()
        return server, ports, inv

    # -------------------------------------------------------------- detection --
    def check_cycle(self) -> Dict[str, Any]:
        cur = self.state["current"]
        d = self.state.setdefault("detector", {})
        try:
            res = self.reach.cycle(cur["ip"], "monitor")
        except InconclusiveError as exc:
            res = {"verdict": INCONCLUSIVE, "why": str(exc)}
            self.log.warning("reachability_cycle", purpose="monitor", ip=cur["ip"],
                             verdict=INCONCLUSIVE, why=str(exc))
        v = res["verdict"]
        d["last_check_at"], d["last_verdict"] = self.now(), v
        d["last_link"] = res.get("link")
        if v == BLOCKED:
            d["consecutive_bad"] = int(d.get("consecutive_bad") or 0) + 1
            d["inconclusive_streak"] = 0
        elif v == REACHABLE:
            d["consecutive_bad"] = 0
            d["inconclusive_streak"] = 0
        elif v == DOWN:
            d["consecutive_bad"] = 0
            self.alert_throttled("down", 3600, "error",
                                 "Server %s is unreachable from outside Iran too (service down?) - "
                                 "NOT rotating" % cur["ip"], {"link": res.get("link")})
        else:
            d["inconclusive_streak"] = int(d.get("inconclusive_streak") or 0) + 1
            if d["inconclusive_streak"] >= 6:
                self.alert_throttled("inconclusive", 6 * 3600, "warning",
                                     "Iran reachability inconclusive for %d cycles: %s"
                                     % (d["inconclusive_streak"], res.get("why")))
        self.save()
        return res

    def should_rotate(self) -> Tuple[bool, str]:
        # SAFETY GATE 1 (detection): rotate only after CONSECUTIVE_FAILED_CYCLES BLOCKED
        # verdicts in a row. A single BLOCKED verdict already requires >= MIN_CONCLUSIVE_NODES
        # Iranian nodes with a clear answer and a fail ratio > FAIL_RATIO_THRESHOLD, control
        # nodes outside Iran reaching the host (else DOWN = service problem, no rotation) and
        # Iranian nodes reaching IRAN_CONTROL_TARGET (else INCONCLUSIVE = probe problem).
        # INCONCLUSIVE cycles neither count nor reset; REACHABLE/DOWN reset the streak.
        d = self.state.get("detector") or {}
        need = int(self.cfg["CONSECUTIVE_FAILED_CYCLES"])
        bad = int(d.get("consecutive_bad") or 0)
        if bad < need:
            return False, "consecutive blocked cycles %d/%d" % (bad, need)
        ok, why = self.limits()
        if not ok:
            self.alert_throttled("limits:" + why.split(":")[0], 3600, "error",
                                 "IP %s looks BLOCKED from Iran but rotation is gated: %s"
                                 % (self.state["current"]["ip"], why))
            return False, why
        return True, "blocked from Iran for %d consecutive cycles" % bad

    # ------------------------------------------------------------ start/advance --
    def start_rotation(self, mode: str, reason: str, ignore_limits: bool = False) -> str:
        # SAFETY GATE 3 (pre-allocation - nothing has been changed yet): not halted, no
        # rotation in flight, limits (gate 2), server ACTIVE and idle, headroom under
        # MAX_PUBLIC_IPS_PER_SERVER, local network control available, DNS precheck and
        # zone audit. Then the rotation record is saved (write-ahead) BEFORE the first
        # billable call, so a crash at any later point can be reconciled on restart.
        st, cfg = self.state, self.cfg
        if st.get("halt"):
            raise RotationRefused("halted: %s (run 'ack --yes' after fixing)" % st["halt"]["reason"])
        if st.get("rotation"):
            raise RotationRefused("a rotation is already in progress (phase %s); use 'resume' or "
                                  "'discard-pending --yes'" % st["rotation"]["phase"])
        if not ignore_limits:
            ok, why = self.limits()
            if not ok:
                raise RotationRefused(why)
        server, ports, inv = self.bootstrap()
        status = str(server.get("status") or "").upper()
        if status and status != "ACTIVE":
            raise RotationRefused("server status is %s (need ACTIVE)" % status)
        if server.get("task_state"):
            raise RotationRefused("server is busy (task_state=%s)" % server.get("task_state"))
        if len(inv) + 1 > int(cfg["MAX_PUBLIC_IPS_PER_SERVER"]):
            raise RotationRefused("server already has %d public IPv4s; one more would exceed "
                                  "MAX_PUBLIC_IPS_PER_SERVER=%s (clean up untracked IPs: %s)"
                                  % (len(inv), cfg["MAX_PUBLIC_IPS_PER_SERVER"],
                                     st.get("untracked_public_ips")))
        if cfg["OS_NETWORK_MODE"] == "iproute2":
            ok, why = self.net.available()
            if not ok:
                raise RotationRefused("OS_NETWORK_MODE=iproute2 but %s" % why)
        cur = st["current"]
        old = next(x for x in inv if x["ip"] == cur["ip"])
        self._dns_precheck(old["ip"], old.get("ipv6") or [])
        sgs = old["sg_ids"] or [g.get("id") for g in (server.get("security_groups") or [])
                                if isinstance(g, dict) and g.get("id")]
        rot = {"id": _uuid.uuid4().hex[:12], "mode": mode, "reason": reason,
               "started_at": self.now(), "started_iso": iso(), "phase": "PRE_ALLOCATE",
               "trail": [["PRE_ALLOCATE", self.now()]],
               "old": {"ip": old["ip"], "port_id": old["port_id"], "mac": old["mac"],
                       "sg_ids": sgs, "network_id": old["network_id"],
                       "table": cur.get("table")},
               "new": None, "ports_before": [p.get("id") for p in ports],
               "add_attempts": 0, "verify": {"good": 0, "attempts": 0, "links": []},
               "dns": {}, "transient_errors": 0}
        st["rotation"] = rot
        self.save()                                   # write-ahead record
        if old.get("ipv6"):
            self.log.warning("old_port_has_ipv6", ipv6=old["ipv6"],
                             detail="will be released together with the old IPv4")
        self.log.info("rotation_started", rotation=rot["id"], mode=mode, reason=reason,
                      old_ip=old["ip"], old_port=old["port_id"], security_groups=sgs)
        self.alerter.send("warning", "Rotation started for %s (%s, mode=%s)"
                          % (old["ip"], reason, mode))
        return self.advance()

    # -------------------------------------------------- DNS precheck + zone audit --
    def _cf(self) -> CloudflareAPI:
        if self.cf is None:
            raise HaltError("BUG: DNS_UPDATE_MODE=cloudflare_api but no Cloudflare client was built")
        return self.cf

    def _cf_records(self, fqdn: str) -> List[Dict[str, Any]]:
        """Cloudflare A records named exactly `fqdn` (the API's name filter is re-checked)."""
        return [r for r in self._cf().list_records("A", fqdn)
                if str(r.get("type") or "").upper() == "A"
                and str(r.get("name") or "").rstrip(".").lower() == fqdn]

    def _zone_records(self, want_aaaa: bool) -> List[Tuple[str, str, str, bool]]:
        """(relative name, type, address, proxied) for every A (+ AAAA) record in DNS_ZONE."""
        zone = self.dns.zone

        def rel(name: Any) -> str:
            n = str(name or "").rstrip(".").lower()
            if n in ("", "@", zone):
                return "@"
            return n[: -(len(zone) + 1)] if n.endswith("." + zone) else n

        out: List[Tuple[str, str, str, bool]] = []
        if self.cfg["DNS_UPDATE_MODE"] == "cloudflare_api":
            for r in self._cf().list_records():          # all types, one paginated listing
                t = str(r.get("type") or "").upper()
                if t in ("A", "AAAA"):
                    out.append((rel(r.get("name")), t, str(r.get("content") or ""), bool(r.get("proxied"))))
            return out
        for t in (("a", "aaaa") if want_aaaa else ("a",)):
            for rec in self.api.dns_list_records(zone, None, t):
                if str(rec.get("type", t)).lower() != t:
                    continue
                for v in rec.get("value") or []:
                    out.append((rel(rec.get("name")), t.upper(), str(v.get("ip") or ""), bool(rec.get("cloud"))))
        return out

    def zone_audit(self, ip: str, ipv6: Optional[List[str]] = None) -> List[str]:
        """Records that would silently break when `ip` (and its port's IPv6) is released:
        A records on `ip` whose name is not in DNS_NAMES, and AAAA records on the old
        port's IPv6 (AAAA records are never managed by this tool)."""
        covered = {self.dns.relative(f) for f in self.dns.fqdns()}
        v6 = set()
        for x in ipv6 or []:
            with contextlib.suppress(ValueError):
                v6.add(str(ipaddress.ip_address(str(x).split("/")[0])))
        out = set()
        for rel, rtype, addr, proxied in self._zone_records(bool(v6)):
            if rtype == "A" and addr == ip and rel not in covered:
                out.add("%s (A%s)" % (rel, ", proxied" if proxied else ""))
            elif rtype == "AAAA" and v6:
                with contextlib.suppress(ValueError):
                    if str(ipaddress.ip_address(addr)) in v6:
                        out.add("%s (AAAA %s)" % (rel, addr))
        return sorted(out)

    def _dns_precheck(self, old_ip: str, old_v6: Optional[List[str]] = None, audit: bool = True) -> None:
        """Before spending money: make sure the DNS step can succeed later."""
        cfg = self.cfg
        if not cfg["DNS_CHECK_ENABLED"]:
            return
        mode = cfg["DNS_UPDATE_MODE"]
        if mode == "cloudflare_api" and not (self.cf and self.cf.has_token):
            raise RotationRefused("DNS precheck: DNS_UPDATE_MODE=cloudflare_api but no Cloudflare API token "
                                  "is available (%s)" % getattr(self, "cf_token_source", "not configured"))
        # SAFETY GATE 3b (zone audit): every record that points at an address we are about
        # to release must be handled by the DNS step, otherwise it breaks silently.
        if cfg["DNS_AUDIT_ZONE"] and audit:
            try:
                unc = self.zone_audit(old_ip, old_v6)
            except ApiError as exc:
                if exc.transient or mode == "arvan_api":
                    raise
                if mode == "cloudflare_api":
                    raise RotationRefused("DNS zone audit: cannot list the Cloudflare DNS records of %s (%s)"
                                          % (self.dns.zone, exc))
                unc = []
                self.log.warning("dns_zone_audit_unavailable", error=str(exc)[:200],
                                 detail="cannot list DNS records; only DNS_NAMES will be verified")
            if unc:
                raise RotationRefused(
                    "DNS zone audit: %s point(s) at an address that is released together with the old IP "
                    "%s, but %s not managed by this tool; releasing it would break them. Add A names to "
                    "DNS_NAMES and remove/repoint AAAA records (or set DNS_AUDIT_ZONE=false to accept the "
                    "risk)" % (", ".join(unc), old_ip, "is" if len(unc) == 1 else "are"))
        if mode == "cloudflare_api":
            self._cf_precheck(old_ip)
        elif mode == "arvan_api":
            for fqdn in self.dns.fqdns():
                recs = self._matching_records(fqdn)
                if not recs:
                    raise RotationRefused("DNS precheck: no A record for %s via the ArvanCloud API" % fqdn)
                for rec in recs:
                    if rec.get("cloud") or rec.get("is_protected"):
                        raise RotationRefused("DNS precheck: %s is %s" % (
                            fqdn, "proxied (cloud=true)" if rec.get("cloud") else "protected"))
                    ips = [v.get("ip") for v in rec.get("value") or []]
                    if old_ip not in ips:
                        raise RotationRefused("DNS precheck: %s points to %s, not the current IP %s"
                                              % (fqdn, ips, old_ip))
        else:
            ev = self.dns.evaluate(old_ip)
            if not ev["auth_ok"]:
                self.log.warning("dns_precheck_mismatch", detail="names do not currently resolve to "
                                 "the current IP", problems=ev["problems"][:4])

    def _cf_precheck(self, old_ip: str) -> None:
        """cloudflare_api: the zone is active, every name has an editable A record on the
        current IP (DNS-only unless CLOUDFLARE_ALLOW_PROXIED), and the authoritative
        nameservers agree with the API - i.e. editing Cloudflare will really move DNS."""
        cfg, plain = self.cfg, []
        try:
            cf = self._cf()
            cf.zone_id()
            zp = cf.zone_problem()
            if zp:
                raise RotationRefused("DNS precheck: %s" % zp)
            for fqdn in self.dns.fqdns():
                recs = self._cf_records(fqdn)
                mine = [r for r in recs if r.get("content") == old_ip]
                if not mine:
                    raise RotationRefused("DNS precheck: Cloudflare has %s for %s, not an A record on the current "
                                          "IP %s" % (", ".join(str(r.get("content")) for r in recs) or
                                                     "no A record", fqdn, old_ip))
                if any(r.get("locked") for r in mine):
                    raise RotationRefused("DNS precheck: Cloudflare record %s is locked (read-only)" % fqdn)
                if any(r.get("proxied") for r in mine):
                    if not cfg["CLOUDFLARE_ALLOW_PROXIED"]:
                        raise RotationRefused(
                            "DNS precheck: %s is proxied (orange cloud) in Cloudflare, so public DNS shows "
                            "Cloudflare edge IPs and cannot prove the switch. Make it DNS-only, or set "
                            "CLOUDFLARE_ALLOW_PROXIED=true to update it and verify it via the Cloudflare API"
                            % fqdn)
                else:
                    plain.append(fqdn)
        except ApiError as exc:
            if exc.transient:
                raise
            raise RotationRefused("DNS precheck: Cloudflare API: %s" % exc)
        if plain:
            ev = self.dns.evaluate(old_ip, names=plain)
            if not ev["auth_ok"]:
                raise RotationRefused(
                    "DNS precheck: Cloudflare has %s on %s, but the zone's authoritative nameservers answer "
                    "otherwise (%s). Is Cloudflare authoritative for %s (zone active, NS delegated to "
                    "Cloudflare)? The DNS step could not succeed, so nothing was changed"
                    % (", ".join(plain), old_ip, "; ".join(ev["problems"][:3]), self.dns.zone))

    def _handlers(self) -> Dict[str, Callable[[Dict[str, Any]], Any]]:
        return {"PRE_ALLOCATE": self._do_allocate, "ALLOCATED": self._do_os_config,
                "OS_CONFIGURED": self._do_verify, "VERIFIED": self._do_switch,
                "SWITCHING": self._do_switch, "SWITCHED": self._do_dns_update,
                "DNS_UPDATED": self._do_dns_gate, "DNS_VERIFIED": self._do_start_drain,
                "DRAINING": self._do_drain, "RELEASING": self._do_release,
                "DONE": self._do_finish}

    def advance(self) -> str:
        """Drive the in-flight rotation as far as possible. Returns a status word."""
        while True:
            rot = self.state.get("rotation")
            if not rot:
                return "idle"
            if self.state.get("halt"):
                return "halted"
            if rot.get("paused"):
                return "paused"
            phase = rot["phase"]
            try:
                res = self._handlers()[phase](rot)
            except HaltError as exc:
                self.halt(str(exc))
                return "halted"
            except ApiError as exc:
                if exc.transient:
                    if self._note_transient(rot, exc):
                        return "halted"
                    raise TransientError(str(exc))
                self.halt("%s API error during %s: %s" % (exc.provider, phase, exc))
                return "halted"
            except TransientError as exc:
                if self._note_transient(rot, exc):
                    return "halted"
                raise
            if res is not True:
                return res

    def _note_transient(self, rot: Dict[str, Any], exc: Exception) -> bool:
        rot["transient_errors"] = int(rot.get("transient_errors") or 0) + 1
        rot["last_transient"] = str(exc)[:500]
        self.save()
        self.log.warning("transient_error", phase=rot["phase"], count=rot["transient_errors"],
                         error=str(exc))
        if rot["transient_errors"] >= MAX_TRANSIENT_ERRORS_PER_PHASE:
            self.halt("stuck in phase %s after %d transient errors; last: %s"
                      % (rot["phase"], rot["transient_errors"], exc))
            return True
        return False

    # ------------------------------------------------------------ PRE_ALLOCATE --
    @staticmethod
    def _parse_add_response(data: Any) -> Optional[Dict[str, Any]]:
        if not isinstance(data, dict):
            return None
        fixed = [f for f in (data.get("fixed_ips") or []) if isinstance(f, dict)]
        ip4 = next((f.get("ip_address") for f in fixed if _is_ipv4(f.get("ip_address"))), None)
        pid = data.get("port_id") or data.get("id")
        if not (pid and ip4):
            return None
        return {"ip": ip4, "port_id": pid,
                "mac": str(data.get("mac_addr") or data.get("mac_address") or "").lower(),
                "subnet_id": next((f.get("subnet_id") for f in fixed
                                   if f.get("ip_address") == ip4), None)}

    def _find_new_port(self, rot: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        before = set(rot.get("ports_before") or [])
        new = [x for x in self.api.public_inventory() if x["port_id"] not in before]
        if len(new) > 1:
            raise HaltError("%d new public ports appeared since the rotation started (%s); "
                            "refusing to guess which one is ours"
                            % (len(new), ", ".join("%s/%s" % (x["ip"], x["port_id"]) for x in new)))
        return new[0] if new else None

    def _adopt_new(self, rot: Dict[str, Any], new: Dict[str, Any], how: str) -> bool:
        if new["port_id"] in set(rot.get("ports_before") or []) or new["ip"] == rot["old"]["ip"]:
            raise HaltError("allocation result points at a pre-existing port/IP (%s); refusing"
                            % new)
        rot["new"] = {"ip": new["ip"], "port_id": new["port_id"], "mac": new.get("mac") or "",
                      "subnet_id": new.get("subnet_id"), "network_id": new.get("network_id")}
        self.log.info("new_ip_allocated", rotation=rot["id"], how=how, ip=new["ip"],
                      port_id=new["port_id"], mac=new.get("mac"))
        self._set_phase(rot, "ALLOCATED")
        self.alerter.send("info", "Allocated new public IP %s (port %s)" % (new["ip"], new["port_id"]))
        return True

    def _do_allocate(self, rot: Dict[str, Any]) -> Any:
        # SAFETY GATE 4 (allocation): add-public-ip is not idempotent, so it is sent once
        # per attempt and never auto-retried. If the reply is lost (timeout/crash), the
        # port list is diffed against the 'ports_before' snapshot and only a port that did
        # not exist before is adopted. MAX_ADD_ATTEMPTS bounds the spend; then HALT.
        cfg = self.cfg
        if int(rot.get("add_attempts") or 0) > 0:
            found = self._find_new_port(rot)
            if found:
                return self._adopt_new(rot, found, "reconciled")
            wait = float(rot.get("last_add_at") or 0) + float(cfg["ALLOCATION_SETTLE_SEC"]) - self.now()
            if wait > 0:
                self.log.info("allocation_settle_wait", seconds=int(wait))
                self.clock.sleep(wait)
                found = self._find_new_port(rot)
                if found:
                    return self._adopt_new(rot, found, "reconciled")
            if int(rot["add_attempts"]) >= int(cfg["MAX_ADD_ATTEMPTS"]):
                raise HaltError("add-public-ip was sent %d time(s) but no new public port appeared; "
                                "check the ArvanCloud panel before retrying" % rot["add_attempts"])
        rot["add_attempts"] = int(rot.get("add_attempts") or 0) + 1
        rot["last_add_at"] = self.now()
        self.state.setdefault("allocations", []).append(self.now())
        self.save()                                   # write-ahead BEFORE non-idempotent call
        self.log.info("add_public_ip_request", rotation=rot["id"], attempt=rot["add_attempts"],
                      security_groups=rot["old"]["sg_ids"])
        try:
            data = self.api.add_public_ip(rot["old"]["sg_ids"])
        except AmbiguousRequestError as exc:
            self.log.warning("add_public_ip_ambiguous", error=str(exc))
            return True                               # loop -> reconcile by port diff
        except ApiError as exc:
            if exc.transient:
                self.log.warning("add_public_ip_ambiguous", error=str(exc))
                return True
            raise HaltError("add-public-ip refused: %s" % exc)
        new = self._parse_add_response(data)
        if new:
            return self._adopt_new(rot, new, "api_response")
        self.log.warning("add_public_ip_unparsed_response", data=data)
        return True

    # -------------------------------------------------------- ALLOCATED -> OS --
    def _wait_for(self, fn: Callable[[], Any], timeout: float, interval: float = 3.0) -> Any:
        deadline = self.now() + float(timeout)
        while True:
            val = fn()
            if val:
                return val
            if self.now() >= deadline:
                return None
            self.clock.sleep(interval)

    def _pick_table(self, exclude: List[Optional[int]]) -> int:
        used = self.net.used_tables() | {int(x) for x in exclude if x}
        base = int(self.cfg["POLICY_TABLE"])
        for t in range(base, base + 64):
            if t not in used:
                return t
        raise HaltError("no free policy routing table in %d..%d" % (base, base + 63))

    def _prio(self, table: int) -> int:
        return int(self.cfg["POLICY_PRIORITY"]) + (int(table) - int(self.cfg["POLICY_TABLE"]))

    def _hook_payload(self, rot: Dict[str, Any]) -> Dict[str, Any]:
        return {"rotation_id": rot.get("id"), "phase": rot.get("phase"),
                "old": rot.get("old"), "new": rot.get("new")}

    def _do_os_config(self, rot: Dict[str, Any]) -> Any:
        # SAFETY GATE 5 (attachment + interface): the new port must be ACTIVE and bound to
        # THIS server, both old and new IPs must be listed on the server, the new IP must
        # be present on a local NIC (policy routing installed for it) and a source-bound
        # request from the new IP must see the new IP as its egress address.
        cfg, new = self.cfg, rot["new"]
        # 1) Arvan side: port must be ACTIVE and bound to this server
        port: Dict[str, Any] = {}

        def port_active() -> bool:
            nonlocal port
            p = self.api.get_port(new["port_id"])
            if p is None:
                p = next((x for x in self.api.list_server_ports() if x.get("id") == new["port_id"]), None)
            if p is None:
                raise HaltError("new port %s disappeared from ArvanCloud" % new["port_id"])
            port = p
            inst = p.get("instance_id")
            if inst and inst != self.api.server_id:
                raise HaltError("new port %s is bound to %s, not this server" % (new["port_id"], inst))
            return str(p.get("status") or "ACTIVE").upper() == "ACTIVE"

        if not self._wait_for(port_active, cfg["PORT_ACTIVE_TIMEOUT_SEC"], 5):
            raise HaltError("new port %s not ACTIVE after %ss (status=%s)"
                            % (new["port_id"], cfg["PORT_ACTIVE_TIMEOUT_SEC"], port.get("status")))
        if not new.get("mac") and port.get("mac_address"):
            new["mac"] = str(port["mac_address"]).lower()
        new["network_id"] = new.get("network_id") or port.get("network_id")
        if not (new.get("cidr") and new.get("gateway")):
            sn = self.api.subnet_for_ip(new["ip"], new.get("network_id"))
            if sn:
                new.update(cidr=sn["cidr"], gateway=sn["gateway"], subnet_id=sn["subnet_id"],
                           dns=sn["dns"], mtu=sn["mtu"])
        inv_ips = {x["ip"] for x in self.api.public_inventory()}
        if rot["old"]["ip"] not in inv_ips:
            raise HaltError("OLD IP %s vanished from the server during rotation" % rot["old"]["ip"])
        if new["ip"] not in inv_ips:
            raise HaltError("new IP %s is not listed on the server" % new["ip"])
        self.save()
        # 2) OS side
        mode = cfg["OS_NETWORK_MODE"]
        if mode == "iproute2":
            if not (new.get("cidr") and new.get("gateway")):
                raise HaltError("cannot determine subnet/gateway for new IP %s from the API; use "
                                "OS_NETWORK_MODE=hook or configure it manually" % new["ip"])
            if not new.get("mac"):
                raise HaltError("unknown MAC for new port %s" % new["port_id"])
            ifname = self._wait_for(lambda: self.net.iface_for_mac(new["mac"]),
                                    cfg["NIC_APPEAR_TIMEOUT_SEC"])
            if not ifname:
                raise HaltError("no NIC with MAC %s appeared within %ss (hot-plug not supported? a "
                                "reboot may be required - NOT done automatically)"
                                % (new["mac"], cfg["NIC_APPEAR_TIMEOUT_SEC"]))
            new["iface"] = ifname
            if not new.get("table"):
                new["table"] = self._pick_table([rot["old"].get("table")])
            self.save()
            self.net.link_up(ifname)
            plen = ipaddress.ip_network(new["cidr"], strict=False).prefixlen
            self.net.ensure_addr(new["ip"], plen, ifname)
            self.net.ensure_policy(new["ip"], new["cidr"], new["gateway"], ifname,
                                   int(new["table"]), self._prio(new["table"]))
            if cfg["SET_RP_FILTER_LOOSE"]:
                self.net.tune_sysctls([ifname])
            removed = self.net.remove_default_routes_via(ifname, rot.get("route_before") or [])
            if removed:
                self.log.warning("removed_hotplug_default_routes", routes=removed)
        elif mode == "hook":
            rc = run_hook(cfg["OS_CONFIGURE_HOOK"], "configure", self._hook_payload(rot), self.log)
            if rc != 0:
                raise HaltError("OS_CONFIGURE_HOOK configure exited %d" % rc)
        ifname = self._wait_for(lambda: self.net.find_ip(new["ip"]), cfg["NIC_APPEAR_TIMEOUT_SEC"])
        if not ifname:
            raise HaltError("new IP %s is not present on any local interface" % new["ip"])
        new["iface"] = ifname
        # 3) outbound from the new IP (source-bound) before we trust it
        eg = self.net.egress_ip(new["ip"])
        if eg != new["ip"]:
            msg = "egress probe bound to new IP %s returned %s" % (new["ip"], eg)
            if mode == "iproute2" and cfg["REQUIRE_EGRESS_MATCH"]:
                raise HaltError(msg)
            self.log.warning("new_ip_egress_probe_mismatch", detail=msg)
        self._set_phase(rot, "OS_CONFIGURED")
        return True

    # ------------------------------------------------------- OS -> VERIFIED --
    def _do_verify(self, rot: Dict[str, Any]) -> Any:
        # SAFETY GATE 6 (external verification): VERIFY_CYCLES independent check-host cycles
        # must show the NEW IP reachable from Iran (ok ratio >= VERIFY_MIN_SUCCESS_RATIO).
        # BLOCKED/DOWN -> HALT with the old IP untouched (optionally auto-discard the new
        # one). Trial mode pauses right after this gate.
        cfg, new, v = self.cfg, rot["new"], rot.setdefault("verify", {"good": 0, "attempts": 0, "links": []})
        need = int(cfg["VERIFY_CYCLES"])
        tries = 0
        while int(v["good"]) < need:
            if self.net.find_ip(new["ip"]) is None:
                raise HaltError("new IP %s disappeared from local interfaces" % new["ip"])
            tries += 1
            try:
                res = self.reach.cycle(new["ip"], "verify-new")
            except InconclusiveError as exc:
                res = {"verdict": INCONCLUSIVE, "why": str(exc)}
            v["attempts"] = int(v["attempts"]) + 1
            if res.get("link"):
                v["links"] = (v.get("links") or [])[-9:] + [res["link"]]
            verdict = res["verdict"]
            if verdict == REACHABLE and (res.get("ok_ratio") or 0) >= float(cfg["VERIFY_MIN_SUCCESS_RATIO"]):
                v["good"] = int(v["good"]) + 1
            elif verdict == BLOCKED:
                self.save()
                return self._new_ip_failed(rot, "NEW IP %s is ALSO unreachable from Iran (%s)"
                                           % (new["ip"], res.get("why")))
            elif verdict == DOWN:
                self.save()
                return self._new_ip_failed(rot, "new IP %s is unreachable from everywhere - OS/network "
                                                "config problem? (%s)" % (new["ip"], res.get("why")))
            self.save()
            if int(v["good"]) >= need:
                break
            if tries >= need * 2:
                raise TransientError("new-IP verification not yet conclusive (%s good of %s); "
                                     "will retry" % (v["good"], need))
            self.clock.sleep(float(cfg["VERIFY_CYCLE_SPACING_SEC"]))
        self._set_phase(rot, "VERIFIED")
        if rot.get("mode") == "trial":
            rot["paused"] = "trial"
            self.save()
            self.alerter.send("warning", "TRIAL complete: new IP %s allocated, configured and verified "
                                         "from Iran. Nothing switched. Run 'resume' to continue or "
                                         "'discard-pending --yes' to release the new IP." % new["ip"])
            return "paused"
        return True

    def _new_ip_failed(self, rot: Dict[str, Any], why: str) -> str:
        self.state["last_failed_attempt_at"] = self.now()
        self.save()
        if self.cfg["AUTO_DISCARD_FAILED_NEW_IP"] and phase_index(rot["phase"]) < phase_index("SWITCHING"):
            self.log.error("new_ip_failed_auto_discard", reason=why)
            self.alerter.send("error", "%s - releasing the NEW IP automatically "
                                       "(AUTO_DISCARD_FAILED_NEW_IP); old IP kept" % why)
            self.discard_pending(reason="auto: " + why)
            return "aborted"
        raise HaltError(why + ". Old IP kept.")

    # --------------------------------------------------- VERIFIED -> SWITCHED --
    def _ensure_old_policy(self, rot: Dict[str, Any]) -> None:
        """Keep the OLD IP fully usable (replies leave via its own NIC) during drain."""
        old = rot["old"]
        oif = self.net.find_ip(old["ip"])
        if not oif:
            raise HaltError("old IP %s not found on any local interface" % old["ip"])
        gw = next((r.get("gateway") for r in (rot.get("route_before") or [])
                   if r.get("dev") == oif and r.get("gateway")), None)
        plen = self.net.ip_prefixlen(old["ip"])
        cidr = str(ipaddress.ip_interface("%s/%d" % (old["ip"], plen)).network) if plen and plen < 32 else None
        if not (gw and cidr):
            sn = self.api.subnet_for_ip(old["ip"], old.get("network_id"))
            if sn:
                gw, cidr = gw or sn["gateway"], cidr or sn["cidr"]
        if not (gw and cidr):
            raise HaltError("cannot determine gateway/subnet of the old IP %s" % old["ip"])
        if not old.get("table"):
            old["table"] = self._pick_table([rot["new"].get("table")])
        old.update(iface=oif, gateway=gw, cidr=cidr)
        self.save()
        self.net.ensure_policy(old["ip"], cidr, gw, oif, int(old["table"]), self._prio(old["table"]))
        if self.cfg["SET_RP_FILTER_LOOSE"]:
            self.net.tune_sysctls([oif])

    def _verify_switch(self, rot: Dict[str, Any]) -> Tuple[bool, str]:
        cfg, new, mode = self.cfg, rot["new"], self.cfg["OS_NETWORK_MODE"]
        if mode == "iproute2":
            rg = self.net.route_get(ROUTE_PROBE_DST)
            if rg.get("dev") != new.get("iface"):
                return False, "kernel route to %s uses dev %s, expected %s" % (
                    ROUTE_PROBE_DST, rg.get("dev"), new.get("iface"))
        if mode in ("iproute2", "hook") and cfg["REQUIRE_EGRESS_MATCH"]:
            eg = self.net.egress_ip(None)
            if eg != new["ip"]:
                return False, "egress IP seen by echo services is %s, expected %s" % (eg, new["ip"])
        try:
            self.api.get_server()
        except Exception as exc:  # noqa: BLE001
            return False, "ArvanCloud API unreachable after switch: %s" % exc
        return True, "ok"

    def _revert_switch(self, rot: Dict[str, Any]) -> None:
        mode = self.cfg["OS_NETWORK_MODE"]
        if mode == "iproute2":
            new = rot["new"]
            plan = rot.get("switch_plan") or self.net.switch_plan(
                new["gateway"], new["iface"], new["ip"], rot.get("route_before") or [])
            self.net.run_cmds(plan["revert"], check=False)
            self.net.confirm_watchdog(rot.get("watchdog"))
            rot.pop("watchdog", None)
        elif mode == "hook":
            run_hook(self.cfg["OS_CONFIGURE_HOOK"], "revert-switch", self._hook_payload(rot), self.log)
        rot["switch_reverted_at"] = self.now()
        self.save()
        self.log.warning("switch_reverted", rotation=rot.get("id"))

    def _do_switch(self, rot: Dict[str, Any]) -> Any:
        # SAFETY GATE 7 (switch): write-ahead SWITCHING, arm a detached watchdog that
        # restores the previous default routes after ROUTE_SWITCH_CONFIRM_TIMEOUT_SEC even
        # if this process dies or loses connectivity, then require kernel route + echo-
        # service egress == new IP + API reachability before disarming it. Inbound traffic
        # to the old IP keeps working through its own policy table during the drain.
        cfg, new, mode = self.cfg, rot["new"], self.cfg["OS_NETWORK_MODE"]
        if rot["phase"] == "VERIFIED":
            if mode == "iproute2":
                rot["route_before"] = self.net.default_routes()
            self._set_phase(rot, "SWITCHING")         # write-ahead
        if mode == "iproute2":
            self._ensure_old_policy(rot)
            rg = self.net.route_get(ROUTE_PROBE_DST)
            if rg.get("dev") != new["iface"]:
                plan = self.net.switch_plan(new["gateway"], new["iface"], new["ip"],
                                            rot.get("route_before") or [])
                rot["switch_plan"] = plan
                rot["watchdog"] = self.net.start_watchdog(
                    plan["revert"], int(cfg["ROUTE_SWITCH_CONFIRM_TIMEOUT_SEC"]), rot["id"])
                self.save()
                try:
                    self.net.run_cmds(plan["apply"])
                except RotatorError as exc:
                    self._revert_switch(rot)
                    raise HaltError("default-route switch failed (%s); reverted to old IP" % exc)
        elif mode == "hook":
            rc = run_hook(cfg["OS_CONFIGURE_HOOK"], "switch", self._hook_payload(rot), self.log)
            if rc != 0:
                self._revert_switch(rot)
                raise HaltError("OS_CONFIGURE_HOOK switch exited %d; reverted" % rc)
        else:
            self.log.warning("egress_not_managed", detail="OS_NETWORK_MODE=none: egress/default "
                                                          "route is left to the OS")
        ok, why = self._verify_switch(rot)
        if ok and cfg["POST_SWITCH_HOOK"]:
            rc = run_hook(cfg["POST_SWITCH_HOOK"], "post-switch", self._hook_payload(rot), self.log)
            if rc != 0:
                ok, why = False, "POST_SWITCH_HOOK exited %d" % rc
        if not ok:
            self._revert_switch(rot)
            raise HaltError("switch verification failed: %s. Egress reverted to the old IP; "
                            "old IP untouched." % why)
        if mode == "iproute2":
            if not self.net.confirm_watchdog(rot.get("watchdog")):
                rot.pop("watchdog", None)
                self.save()
                raise TransientError("route watchdog reverted the switch before confirmation; retrying")
            rot.pop("watchdog", None)
        rot["switched_at"] = self.now()
        self._set_phase(rot, "SWITCHED")
        self.alerter.send("info", "Egress switched to new IP %s (old %s still attached)"
                          % (new["ip"], rot["old"]["ip"]))
        return True

    # ------------------------------------------------------- SWITCHED -> DNS --
    def _matching_records(self, fqdn: str) -> List[Dict[str, Any]]:
        zone, want = self.dns.zone, self.dns.relative(fqdn)
        search = None if want == "@" else want
        out = []
        for rec in self.api.dns_list_records(zone, search, "a"):
            if str(rec.get("type", "a")).lower() != "a":
                continue
            n = str(rec.get("name") or "").rstrip(".").lower()
            rel = "@" if n in ("", "@", zone) else (n[: -(len(zone) + 1)] if n.endswith("." + zone) else n)
            if rel == want:
                out.append(rec)
        return out

    def _dns_body(self, rec: Dict[str, Any], values: List[Dict[str, Any]]) -> Dict[str, Any]:
        ttl = int(self.cfg["DNS_RECORD_TTL"] or 0) or int(rec.get("ttl") or 120)
        body = {"type": "a", "name": rec.get("name"), "ttl": ttl,
                "cloud": bool(rec.get("cloud")), "value": values}
        for k in ("upstream_https", "ip_filter_mode"):
            if rec.get(k) is not None:
                body[k] = rec[k]
        return body

    @staticmethod
    def _clean_values(values: List[Dict[str, Any]], old_ip: Optional[str],
                      new_ip: Optional[str]) -> List[Dict[str, Any]]:
        out = []
        for v in values or []:
            nv = {k: v[k] for k in ("ip", "port", "weight", "country") if v.get(k) is not None}
            if old_ip and nv.get("ip") == old_ip:
                nv["ip"] = new_ip
            out.append(nv)
        return out

    def _do_dns_update(self, rot: Dict[str, Any]) -> Any:
        cfg, new, old = self.cfg, rot["new"], rot["old"]
        dns = rot.setdefault("dns", {})
        if not cfg["DNS_CHECK_ENABLED"]:
            dns["skipped"] = True
            self.log.warning("dns_check_disabled", detail="DNS_CHECK_ENABLED=False: the old IP will "
                                                          "be released without DNS verification")
            self._set_phase(rot, "DNS_VERIFIED")
            return True
        if cfg["DNS_UPDATE_MODE"] == "cloudflare_api":
            self._cf_dns_update(rot)
            dns["updated_at"] = self.now()
        elif cfg["DNS_UPDATE_MODE"] == "arvan_api":
            originals = dns.setdefault("originals", {})
            for fqdn in self.dns.fqdns():
                recs = self._matching_records(fqdn)
                if not recs:
                    raise HaltError("no A record for %s found via the ArvanCloud DNS API (zone %s)"
                                    % (fqdn, self.dns.zone))
                for rec in recs:
                    ips = [v.get("ip") for v in rec.get("value") or []]
                    if rec.get("is_protected"):
                        raise HaltError("A record %s (%s) is protected; cannot update" % (fqdn, rec.get("id")))
                    if rec.get("cloud"):
                        raise HaltError("A record %s is proxied (cloud=true): public DNS returns ArvanCloud "
                                        "edge IPs, so DNS cannot prove clients reach the new IP. Remove it "
                                        "from DNS_NAMES or turn the proxy off." % fqdn)
                    dns["orig_ttl"] = max(int(dns.get("orig_ttl") or 0), int(rec.get("ttl") or 0))
                    if new["ip"] in ips and old["ip"] not in ips:
                        continue                      # already done (idempotent restart)
                    if old["ip"] not in ips:
                        raise HaltError("A record %s points to %s, not the old IP %s; refusing to modify"
                                        % (fqdn, ips, old["ip"]))
                    if rec["id"] not in originals:
                        originals[rec["id"]] = self._dns_body(rec, self._clean_values(rec.get("value"), None, None))
                        self.save()                   # remember original for rollback
                    body = self._dns_body(rec, self._clean_values(rec.get("value"), old["ip"], new["ip"]))
                    self.log.info("dns_record_update", name=fqdn, record_id=rec["id"], old_ip=old["ip"],
                                  new_ip=new["ip"])
                    self.api.dns_update_record(self.dns.zone, rec["id"], body)
            dns["updated_at"] = self.now()
        else:
            self.alerter.send("warning", "ACTION: point %s to the NEW IP %s now (DNS_UPDATE_MODE=verify_only). "
                                         "The old IP %s is kept until DNS shows the new IP (timeout %ss)."
                              % (", ".join(self.dns.fqdns()), new["ip"], old["ip"],
                                 cfg["DNS_GATE_TIMEOUT_SEC"]))
        dns["gate_started_at"] = self.now()
        self._set_phase(rot, "DNS_UPDATED")
        return True

    def _cf_dns_update(self, rot: Dict[str, Any]) -> None:
        """PATCH every Cloudflare A record of DNS_NAMES that holds the old IP to the new IP.
        The original of each record is saved (write-ahead) before it is changed, so
        discard-pending can restore exactly what was changed."""
        cfg, new, old = self.cfg, rot["new"], rot["old"]
        dns = rot.setdefault("dns", {})
        originals = dns.setdefault("cf_originals", {})
        proxied = set(dns.get("proxied") or [])
        ttl_cfg = int(cfg["DNS_RECORD_TTL"] or 0)
        try:
            cf = self._cf()
            for fqdn in self.dns.fqdns():
                recs = self._cf_records(fqdn)
                contents = [r.get("content") for r in recs]
                if old["ip"] in contents and new["ip"] in contents:
                    raise HaltError("%s has Cloudflare A records for BOTH the old IP %s and the new IP %s; "
                                    "delete the old-IP record in Cloudflare, then 'ack --yes' and 'resume'"
                                    % (fqdn, old["ip"], new["ip"]))
                if old["ip"] not in contents and new["ip"] not in contents:
                    raise HaltError("Cloudflare A record(s) for %s point to %s - neither the old IP %s nor the "
                                    "new IP %s (changed outside this tool?); refusing to modify them"
                                    % (fqdn, contents or "nothing", old["ip"], new["ip"]))
                for rec in recs:
                    if rec.get("content") not in (old["ip"], new["ip"]):
                        continue                      # another server's record on the same name: untouched
                    if rec.get("proxied"):
                        if not cfg["CLOUDFLARE_ALLOW_PROXIED"]:
                            raise HaltError("%s is proxied (orange cloud) in Cloudflare; make it DNS-only or set "
                                            "CLOUDFLARE_ALLOW_PROXIED=true, then 'ack --yes' and 'resume'" % fqdn)
                        proxied.add(fqdn)
                    dns["orig_ttl"] = max(int(dns.get("orig_ttl") or 0), cf_ttl_seconds(rec.get("ttl")))
                    if rec.get("content") == new["ip"]:
                        continue                      # already done (idempotent restart)
                    rid = str(rec.get("id"))
                    if rid not in originals:
                        originals[rid] = {"fqdn": fqdn, "name": rec.get("name"), "content": old["ip"],
                                          "ttl": rec.get("ttl"), "proxied": bool(rec.get("proxied"))}
                        dns["proxied"] = sorted(proxied)
                        self.save()                   # remember the original for rollback
                    body = cf.patch_body(rec, new["ip"], ttl_cfg)
                    self.log.info("dns_record_update", provider="cloudflare", name=fqdn, record_id=rid,
                                  old_ip=old["ip"], new_ip=new["ip"], ttl=body["ttl"], proxied=body["proxied"])
                    cf.update_record(rid, body)
        except ApiError as exc:
            if exc.transient:
                raise
            raise HaltError("Cloudflare DNS update failed: %s. The OLD IP %s is still attached. Fix the token or "
                            "record, then 'ack --yes' and 'resume' - or roll back with 'ack --yes' and "
                            "'discard-pending --yes' (restores the records changed so far, releases only the "
                            "new IP)" % (exc, old["ip"]))
        dns["proxied"] = sorted(proxied)

    def _cf_readback(self, names: List[str], new_ip: str, old_ip: str) -> Tuple[bool, List[str]]:
        """Proxied names cannot be checked in public DNS (edge IPs): read them via the API."""
        probs = []
        for fqdn in names:
            contents = [r.get("content") for r in self._cf_records(fqdn)]
            if new_ip not in contents or old_ip in contents:
                probs.append("%s (proxied) -> Cloudflare API shows %s" % (fqdn, contents))
        return not probs, probs

    def _do_dns_gate(self, rot: Dict[str, Any]) -> Any:
        # SAFETY GATE 8 (DNS): every name in DNS_NAMES must resolve to the new IP on the
        # zone's authoritative servers (RD=0) and on the public resolvers before
        # DNS_GATE_TIMEOUT_SEC; otherwise HALT loudly and keep the old IP. This is what
        # tests the 'A record follows the VM' assumption on every rotation.
        cfg, new, old = self.cfg, rot["new"], rot["old"]
        dns = rot.setdefault("dns", {})
        if not dns.get("gate_started_at"):
            dns["gate_started_at"] = self.now()
        deadline = float(dns["gate_started_at"]) + float(cfg["DNS_GATE_TIMEOUT_SEC"])
        proxied = sorted(set(dns.get("proxied") or []))     # Cloudflare orange-cloud names
        plain = [f for f in self.dns.fqdns() if f not in proxied]
        while True:
            ev = self.dns.evaluate(new["ip"], old["ip"], names=plain)
            problems, api_ok = list(ev["problems"]), True
            if proxied:
                api_ok, api_problems = self._cf_readback(proxied, new["ip"], old["ip"])
                problems += api_problems
            dns["last_problems"] = problems[:20]
            dns["max_auth_ttl"] = max(int(dns.get("max_auth_ttl") or 0), int(ev.get("max_auth_ttl") or 0))
            if ev["auth_ok"] and api_ok and not dns.get("auth_switched_at"):
                dns["auth_switched_at"] = self.now()
                self.log.info("dns_authoritative_shows_new_ip", ip=new["ip"])
            self.save()
            if ev["ok"] and api_ok:
                break
            if self.now() >= deadline:
                hint = ""
                if cfg["DNS_UPDATE_MODE"] == "cloudflare_api":
                    hint = (" The Cloudflare API accepted the change, so check that Cloudflare is authoritative "
                            "for %s (zone active, NS delegated to Cloudflare)." % self.dns.zone)
                raise HaltError("DNS verification FAILED after %ss: %s. The OLD IP %s will NOT be released.%s "
                                "Make %s resolve to %s, then 'ack --yes' and 'resume'."
                                % (cfg["DNS_GATE_TIMEOUT_SEC"], "; ".join(problems[:6]),
                                   old["ip"], hint, ", ".join(self.dns.fqdns()), new["ip"]))
            self.log.info("dns_gate_waiting", remaining_sec=int(deadline - self.now()),
                          problems=problems[:4])
            self.clock.sleep(float(cfg["DNS_GATE_POLL_SEC"]))
        if cfg["DNS_VERIFY_FROM_IRAN"]:
            self._dns_from_iran(new["ip"])
        self._set_phase(rot, "DNS_VERIFIED")
        return True

    def _dns_from_iran(self, ip: str) -> None:
        """Informational only: what do Iranian check-host nodes resolve?"""
        for fqdn in self.dns.fqdns():
            try:
                raw, acc, link = self.ch.run("dns", fqdn, self.ch.probe_nodes())
                seen = {n: (raw.get(n) or [{}])[0].get("A") if isinstance(raw.get(n), list) else None
                        for n in acc}
                self.log.info("dns_from_iran", name=fqdn, expect=ip, seen=seen, link=link)
            except (TransientError, AttributeError, IndexError, TypeError) as exc:
                self.log.warning("dns_from_iran_failed", name=fqdn, error=str(exc))

    # --------------------------------------------------- DNS -> DRAIN -> GATES --
    def _do_start_drain(self, rot: Dict[str, Any]) -> Any:
        # SAFETY GATE 9 (TTL drain): resolvers may cache the old answer for up to the
        # record TTL, so the old IP keeps serving for max(TTL, DNS_DRAIN_MIN_SEC) +
        # DNS_DRAIN_EXTRA_SEC after the authoritative servers switched.
        cfg, dns = self.cfg, rot.get("dns") or {}
        ttl = max(int(dns.get("max_auth_ttl") or 0), int(dns.get("orig_ttl") or 0))
        base = float(dns.get("auth_switched_at") or self.now())
        rot["drain_until"] = base + max(ttl, int(cfg["DNS_DRAIN_MIN_SEC"])) + int(cfg["DNS_DRAIN_EXTRA_SEC"])
        self.log.info("drain_started", ttl=ttl, drain_until=iso(_dt.datetime.fromtimestamp(
            rot["drain_until"], tz=_dt.timezone.utc)))
        self._set_phase(rot, "DRAINING")
        return True

    def _do_drain(self, rot: Dict[str, Any]) -> Any:
        rem = float(rot["drain_until"]) - self.now()
        if rem > 0:
            self.log.info("draining", remaining_sec=int(rem), old_ip=rot["old"]["ip"])
            self.clock.sleep(min(rem, 60.0))
            return True
        self._pre_release_gates(rot)
        self._set_phase(rot, "RELEASING")
        return True

    def _pre_release_gates(self, rot: Dict[str, Any]) -> None:
        # SAFETY GATE 10 (pre-release): immediately before the only destructive call, re-check
        # that the new port is still attached and ACTIVE, the new IP is on the NIC and carries
        # egress, Iran still reaches it, and authoritative DNS still shows it.
        cfg, new, old = self.cfg, rot["new"], rot["old"]
        if self.dry_run or rot.get("mode") == "trial":
            raise HaltError("BUG: release gate reached in dry-run/trial mode")
        if not new or new["ip"] == old["ip"] or new["port_id"] == old["port_id"]:
            raise HaltError("BUG: new and old IP/port are identical or missing")
        inv = self.api.public_inventory()
        if not any(x["port_id"] == new["port_id"] and x["ip"] == new["ip"] for x in inv):
            raise HaltError("new IP %s is no longer attached; NOT releasing old IP" % new["ip"])
        p = self.api.get_port(new["port_id"]) or {}
        if str(p.get("status") or "ACTIVE").upper() != "ACTIVE":
            raise HaltError("new port %s status %s; NOT releasing old IP" % (new["port_id"], p.get("status")))
        rot["old_already_gone"] = not any(x["port_id"] == old["port_id"] for x in inv)
        if rot["old_already_gone"]:
            self.log.critical("old_ip_already_gone", ip=old["ip"], detail="removed outside this tool")
        if self.net.find_ip(new["ip"]) is None:
            raise HaltError("new IP %s missing from local interfaces; NOT releasing old IP" % new["ip"])
        if cfg["OS_NETWORK_MODE"] == "iproute2" and \
                self.net.route_get(ROUTE_PROBE_DST).get("dev") != new.get("iface"):
            raise HaltError("default egress is no longer via the new IP; NOT releasing old IP")
        try:
            res = self.reach.cycle(new["ip"], "pre-release")
        except InconclusiveError as exc:
            raise TransientError("pre-release Iran check inconclusive: %s" % exc)
        if res["verdict"] == INCONCLUSIVE:
            raise TransientError("pre-release Iran check inconclusive: %s" % res.get("why"))
        if res["verdict"] != REACHABLE:
            raise HaltError("pre-release Iran check on new IP %s returned %s (%s); NOT releasing old IP"
                            % (new["ip"], res["verdict"], res.get("why")))
        if cfg["DNS_CHECK_ENABLED"]:
            proxied = sorted(set((rot.get("dns") or {}).get("proxied") or []))
            ev = self.dns.evaluate(new["ip"], old["ip"], names=[f for f in self.dns.fqdns() if f not in proxied])
            if not ev["auth_ok"]:
                raise HaltError("authoritative DNS no longer shows %s (%s); NOT releasing old IP"
                                % (new["ip"], "; ".join(ev["problems"][:4])))
            if proxied:
                try:
                    ok, probs = self._cf_readback(proxied, new["ip"], old["ip"])
                except ApiError as exc:
                    if exc.transient:
                        raise TransientError("pre-release Cloudflare read-back failed: %s" % exc)
                    raise HaltError("cannot re-check the proxied Cloudflare records (%s); NOT releasing old IP"
                                    % exc)
                if not ok:
                    raise HaltError("%s; NOT releasing old IP" % "; ".join(probs))
        if cfg["PRE_RELEASE_HOOK"]:
            rc = run_hook(cfg["PRE_RELEASE_HOOK"], "pre-release", self._hook_payload(rot), self.log)
            if rc != 0:
                raise HaltError("PRE_RELEASE_HOOK exited %d; NOT releasing old IP" % rc)
        self.log.info("pre_release_gates_passed", old_ip=old["ip"], new_ip=new["ip"])

    # ---------------------------------------------------------- RELEASING --
    def _do_release(self, rot: Dict[str, Any]) -> Any:
        # SAFETY GATE 11 (release): detach exactly the recorded old port (never the new,
        # current or an untracked one), write-ahead before sending, and confirm via the
        # port list that it is gone; a refusal HALTs with the new IP fully in service.
        cfg, old, new = self.cfg, rot["old"], rot["new"]
        if old["port_id"] == new["port_id"] or old["ip"] == new["ip"]:
            raise HaltError("BUG: refusing to release - old and new are the same")

        def old_attached() -> bool:
            return any(x["port_id"] == old["port_id"] for x in self.api.public_inventory())

        if not rot.get("old_already_gone") and old_attached():
            last = float(rot.get("detach_sent_at") or 0)
            if not last or self.now() - last > float(cfg["PORT_ACTIVE_TIMEOUT_SEC"]):
                rot["detach_attempts"] = int(rot.get("detach_attempts") or 0) + 1
                if rot["detach_attempts"] > 3:
                    raise HaltError("old port %s still attached after 3 detach requests" % old["port_id"])
                rot["detach_sent_at"] = self.now()
                self.save()                           # write-ahead
                self.log.info("release_old_ip", ip=old["ip"], port_id=old["port_id"],
                              attempt=rot["detach_attempts"])
                try:
                    self.api.detach_port(old["port_id"])
                except AmbiguousRequestError as exc:
                    self.log.warning("detach_ambiguous", error=str(exc))
                except ApiError as exc:
                    if exc.kind != "not_found" and not exc.transient:
                        raise HaltError("ArvanCloud refused to release old IP %s: %s. The new IP %s is "
                                        "active; the old IP stays attached (and billed) until fixed."
                                        % (old["ip"], exc, new["ip"]))
                    self.log.warning("detach_error_will_verify", error=str(exc))
            gone = self._wait_for(lambda: not old_attached(), cfg["PORT_ACTIVE_TIMEOUT_SEC"], 5)
            if not gone:
                raise TransientError("old port %s still attached; will re-check" % old["port_id"])
        if cfg["OS_NETWORK_MODE"] == "iproute2":
            with contextlib.suppress(Exception):
                self.net.remove_policy(old["ip"], old.get("table"))
        self.log.info("old_ip_released", ip=old["ip"], port_id=old["port_id"])
        self._set_phase(rot, "DONE")
        return True

    def _do_finish(self, rot: Dict[str, Any]) -> Any:
        cfg, st, new, old = self.cfg, self.state, rot["new"], rot["old"]
        st["current"] = {"ip": new["ip"], "port_id": new["port_id"], "mac": new.get("mac"),
                         "network_id": new.get("network_id"), "table": new.get("table"),
                         "iface": new.get("iface"), "since": self.now()}
        st["last_change_at"] = self.now()
        st["detector"] = {"consecutive_bad": 0, "last_verdict": None, "last_check_at": None,
                          "inconclusive_streak": 0}
        st.setdefault("history", []).append({
            "rotation": rot["id"], "result": "completed", "old_ip": old["ip"], "new_ip": new["ip"],
            "started_iso": rot.get("started_iso"), "finished_iso": iso(), "reason": rot.get("reason")})
        st["history"] = st["history"][-50:]
        st["rotation"] = None
        self.save()
        if cfg["PERSIST_NETPLAN"] and cfg["OS_NETWORK_MODE"] == "iproute2" and new.get("cidr"):
            try:
                self.net.write_netplan(cfg["NETPLAN_PATH"], new["mac"], new["ip"],
                                       ipaddress.ip_network(new["cidr"], strict=False).prefixlen,
                                       new["gateway"], new.get("dns") or [])
                self.log.info("netplan_written", path=cfg["NETPLAN_PATH"])
            except Exception as exc:  # noqa: BLE001
                self.alerter.send("error", "Could not persist network config for reboot: %s" % exc)
        elif cfg["OS_NETWORK_MODE"] == "iproute2":
            self.alert_throttled("reboot-persistence", 30 * 86400, "warning",
                                 "Reminder: the new IP's OS config is live-only (PERSIST_NETPLAN=False). "
                                 "Persist it before the next reboot.")
        if cfg["POST_RELEASE_HOOK"]:
            run_hook(cfg["POST_RELEASE_HOOK"], "post-release", self._hook_payload(rot), self.log)
        self.alerter.send("warning", "Rotation complete: %s -> %s (old IP released)" % (old["ip"], new["ip"]))
        return "done"

    # ------------------------------------------------------ operator commands --
    def ack(self) -> str:
        h = self.state.get("halt")
        if not h:
            return "not halted"
        self.state.setdefault("history", []).append({"result": "halt_acknowledged", "reason": h["reason"],
                                                     "at_iso": iso()})
        self.state["halt"] = None
        rot = self.state.get("rotation")
        if rot:
            rot["transient_errors"] = 0
        self.save()
        self.log.warning("halt_acknowledged", reason=h["reason"])
        return "acknowledged"

    def resume(self) -> str:
        if self.state.get("halt"):
            raise RotationRefused("halted: %s. Fix the cause, then 'ack --yes' first."
                                  % self.state["halt"]["reason"])
        rot = self.state.get("rotation")
        if not rot:
            return "idle"
        if rot.get("paused"):
            rot.pop("paused", None)
            rot["mode"] = "resumed-trial" if rot.get("mode") == "trial" else rot.get("mode")
        if rot["phase"] == "DNS_UPDATED":
            rot.setdefault("dns", {})["gate_started_at"] = self.now()   # fresh DNS window
        if rot["phase"] == "OS_CONFIGURED":
            rot["verify"] = {"good": 0, "attempts": 0, "links": []}     # re-verify from scratch
        self.save()
        self.bootstrap()
        return self.advance()

    def _revert_dns(self, rot: Dict[str, Any]) -> None:
        dns = rot.get("dns") or {}
        if dns.get("cf_originals"):
            self._cf_revert(rot, dns["cf_originals"])
        originals = dns.get("originals") or {}
        if not originals:
            return
        current: Dict[str, Dict[str, Any]] = {}
        for fqdn in self.dns.fqdns():
            for rec in self._matching_records(fqdn):
                current[rec["id"]] = rec
        for rid, body in originals.items():
            want = sorted(str(v.get("ip")) for v in body.get("value") or [])
            have = sorted(str(v.get("ip")) for v in (current.get(rid) or {}).get("value") or [])
            if rid in current and have == want:
                continue                              # never changed (or already restored)
            self.log.warning("dns_record_revert", record_id=rid, to=want, was=have)
            try:
                self.api.dns_update_record(self.dns.zone, rid, body)
            except ApiError as exc:
                raise HaltError("could not restore DNS record %s to %s (%s); refusing to release the "
                                "new IP while DNS may still point at it" % (rid, want, exc))

    def _cf_revert(self, rot: Dict[str, Any], originals: Dict[str, Dict[str, Any]]) -> None:
        """Put every Cloudflare record this rotation changed back on the old IP - but only
        if it still holds the new IP (a record changed by someone else is left alone)."""
        new_ip = (rot.get("new") or {}).get("ip")
        manual = ("restore it by hand to %s, then run 'discard-pending --yes --skip-dns-revert'"
                  % rot["old"]["ip"])
        if self.cf is None or not self.cf.has_token:
            raise HaltError("Cloudflare records %s were changed but no Cloudflare API token is available to "
                            "restore them; %s" % (", ".join(sorted(str(o.get("fqdn")) for o in originals.values())),
                                                  manual))
        for rid, orig in sorted(originals.items()):
            label = orig.get("fqdn") or orig.get("name") or rid
            try:
                rec = self.cf.get_record(rid)
                if not rec:
                    self.log.warning("dns_record_revert_skipped", provider="cloudflare", name=label,
                                     record_id=rid, why="record no longer exists")
                    continue
                cur = rec.get("content")
                if cur == orig.get("content"):
                    continue                          # never changed (or already restored)
                if cur != new_ip:
                    self.log.warning("dns_record_revert_skipped", provider="cloudflare", name=label,
                                     record_id=rid, content=cur, why="changed outside this tool; left as is")
                    continue
                body = self.cf.patch_body(rec, str(orig.get("content")), int(orig.get("ttl") or 0))
                self.log.warning("dns_record_revert", provider="cloudflare", name=label, record_id=rid,
                                 to=orig.get("content"), was=cur)
                self.cf.update_record(rid, body)
            except ApiError as exc:
                if exc.transient:
                    raise TransientError("could not restore Cloudflare record %s yet (%s); re-run "
                                         "discard-pending" % (label, exc))
                raise HaltError("could not restore Cloudflare DNS record %s to %s (%s); refusing to release the "
                                "new IP while DNS may still point at it. Fix the token, or %s"
                                % (label, orig.get("content"), exc, manual))

    def discard_pending(self, reason: str = "operator", skip_dns_revert: bool = False) -> str:
        """Abort the in-flight rotation: release ONLY the new IP, revert route/DNS. Never the old IP."""
        st, cfg = self.state, self.cfg
        rot = st.get("rotation")
        if not rot:
            return "nothing to discard"
        if phase_index(rot["phase"]) >= phase_index("RELEASING"):
            raise RotationRefused("release of the old IP has already started (phase %s); "
                                  "use 'resume' instead" % rot["phase"])
        old, new = rot["old"], rot.get("new")
        # 1) DNS back to the old IP (only records we changed, only if they differ now)
        if skip_dns_revert:
            self.log.warning("dns_revert_skipped_by_operator", rotation=rot["id"],
                             detail="operator states the DNS records already point at the old IP")
        else:
            self._revert_dns(rot)
        # 2) egress back to the old IP
        if phase_index(rot["phase"]) >= phase_index("SWITCHING"):
            self._revert_switch(rot)
        # 3) find the new port even if the allocation response was lost
        if not new and int(rot.get("add_attempts") or 0) > 0:
            found = self._find_new_port(rot)
            if found:
                new = rot["new"] = {"ip": found["ip"], "port_id": found["port_id"], "mac": found["mac"]}
                self.save()
        if new:
            if new["port_id"] == old["port_id"] or new["ip"] == old["ip"] or \
                    new["port_id"] in set(rot.get("ports_before") or []) or \
                    new["ip"] == (st.get("current") or {}).get("ip"):
                raise HaltError("SAFETY: refusing to discard - 'new' port %s looks like a pre-existing/"
                                "current port" % new["port_id"])
            if cfg["OS_NETWORK_MODE"] == "iproute2":
                with contextlib.suppress(Exception):
                    self.net.remove_policy(new["ip"], new.get("table"))
                    if new.get("iface") and new.get("cidr"):
                        self.net.remove_addr(new["ip"], ipaddress.ip_network(new["cidr"], strict=False).prefixlen,
                                             new["iface"])
            if any(x["port_id"] == new["port_id"] for x in self.api.public_inventory()):
                self.log.warning("discard_new_ip", ip=new["ip"], port_id=new["port_id"])
                try:
                    self.api.detach_port(new["port_id"])
                except AmbiguousRequestError:
                    pass
                except ApiError as exc:
                    if exc.kind != "not_found":
                        raise
                gone = self._wait_for(lambda: not any(x["port_id"] == new["port_id"]
                                                      for x in self.api.public_inventory()),
                                      cfg["PORT_ACTIVE_TIMEOUT_SEC"], 5)
                if not gone:
                    raise TransientError("new port %s still attached; re-run discard-pending" % new["port_id"])
        st.setdefault("history", []).append({
            "rotation": rot["id"], "result": "discarded", "reason": reason, "old_ip": old["ip"],
            "new_ip": (new or {}).get("ip"), "phase": rot["phase"], "at_iso": iso()})
        st["history"] = st["history"][-50:]
        st["rotation"] = None
        if (st.get("halt") or {}).get("rotation_id") == rot["id"]:
            st["halt"] = None
        st["last_failed_attempt_at"] = self.now()
        self.save()
        self.alerter.send("warning", "Rotation %s discarded (%s): new IP %s released, old IP %s kept"
                          % (rot["id"], reason, (new or {}).get("ip"), old["ip"]))
        return "discarded"

    # ---------------------------------------------------------------- daemon --
    def run_forever(self, max_loops: Optional[int] = None) -> int:
        cfg = self.cfg
        interval = float(cfg["CHECK_INTERVAL_SEC"])
        self.log.info("daemon_started", version=__version__, server_id=self.api.server_id,
                      region=cfg["REGION"], current=(self.state.get("current") or {}).get("ip"),
                      dns_mode=cfg["DNS_UPDATE_MODE"], os_mode=cfg["OS_NETWORK_MODE"])
        if not cfg["DNS_CHECK_ENABLED"]:
            self.log.warning("dns_check_disabled", detail="old IPs will be released without DNS proof")
        loops = 0
        while max_loops is None or loops < max_loops:
            loops += 1
            busy = False
            try:
                self.alerter.flush_outbox()
                if self.state.get("halt"):
                    self.remind_if_halted()
                    self.clock.sleep(min(interval, 300.0))
                    continue
                self.bootstrap()
                if self.state.get("rotation"):
                    res = self.advance()
                    busy = res not in ("idle", "done", "paused", "halted", "aborted")
                    if res == "paused":
                        self.alert_throttled("paused", float(cfg["ALERT_REMIND_EVERY_SEC"]), "warning",
                                             "Trial rotation is paused (monitoring is suspended until you "
                                             "run 'resume' or 'discard-pending --yes')")
                else:
                    self.check_cycle()
                    go, why = self.should_rotate()
                    if go:
                        try:
                            self.start_rotation("auto", why)
                        except RotationRefused as exc:
                            self.alert_throttled("refused:" + str(exc)[:40], 3600, "error",
                                                 "Rotation needed but refused: %s" % exc)
            except StopRequested:
                break
            except HaltError as exc:
                self.halt(str(exc))
            except RotationRefused as exc:
                self.alert_throttled("refused:" + str(exc)[:40], 3600, "error", "Rotation refused: %s" % exc)
            except ApiError as exc:
                if exc.transient:
                    busy = True
                    self.log.warning("api_transient", error=str(exc))
                elif exc.kind in ("unauthenticated", "forbidden") or self.state.get("rotation"):
                    self.halt("%s API error: %s" % (exc.provider, exc))
                else:
                    self.log.error("api_error", provider=exc.provider, error=str(exc))
                    self.alert_throttled("api:%s:%s" % (exc.provider, exc.kind), 3600, "error",
                                         "%s API error: %s" % (exc.provider, exc))
            except TransientError as exc:
                busy = True
                self.log.warning("transient", error=str(exc))
            except Exception as exc:  # noqa: BLE001 - last-resort safety net
                self.log.error("unexpected_error", error=repr(exc), traceback=traceback.format_exc())
                if self.state.get("rotation"):
                    self.halt("unexpected error during rotation: %r" % exc)
                else:
                    self.alert_throttled("bug:" + type(exc).__name__, 3600, "error",
                                         "Unexpected error (monitoring continues): %r" % exc)
            if max_loops is not None and loops >= max_loops:
                break
            try:
                rot = self.state.get("rotation")
                active = busy or (rot and not rot.get("paused") and not self.state.get("halt"))
                self.clock.sleep(min(interval, 60.0) if active else interval)
            except StopRequested:
                break
        self.log.info("daemon_stopped")
        return 0

    # ---------------------------------------------------------------- status --
    def status_text(self) -> str:
        st, cfg = self.state, self.cfg

        def ts(x: Any) -> str:
            return iso(_dt.datetime.fromtimestamp(float(x), tz=_dt.timezone.utc)) if x else "-"

        cur = st.get("current") or {}
        out = ["server      : %s (region %s)" % (st.get("server_id") or self.api.server_id or "?",
                                                 st.get("region") or cfg["REGION"]),
               "current IP  : %s (port %s, since %s)" % (cur.get("ip", "-"), cur.get("port_id", "-"),
                                                       ts(cur.get("since")))]
        h = st.get("halt")
        out.append("HALTED      : %s  [at %s, phase %s]" % (h["reason"], h.get("at_iso"), h.get("phase"))
                   if h else "halted      : no")
        rot = st.get("rotation")
        if rot:
            out.append("rotation    : %s phase=%s mode=%s%s" % (
                rot["id"], rot["phase"], rot.get("mode"),
                "  PAUSED(%s)" % rot["paused"] if rot.get("paused") else ""))
            out.append("  old       : %s (port %s)" % (rot["old"]["ip"], rot["old"]["port_id"]))
            if rot.get("new"):
                out.append("  new       : %s (port %s, iface %s)" % (rot["new"]["ip"], rot["new"]["port_id"],
                                                                     rot["new"].get("iface")))
            if rot.get("drain_until"):
                out.append("  drain til : %s" % ts(rot["drain_until"]))
            if (rot.get("dns") or {}).get("last_problems"):
                out.append("  dns       : %s" % "; ".join(rot["dns"]["last_problems"][:3]))
            cfo = (rot.get("dns") or {}).get("cf_originals") or {}
            if cfo:
                out.append("  dns edits : Cloudflare %s (were %s; discard-pending puts back any that now "
                           "hold the new IP)" % (", ".join(sorted({str(v.get("fqdn") or v.get("name") or k)
                                                                   for k, v in cfo.items()})), rot["old"]["ip"]))
            if rot.get("last_transient"):
                out.append("  last err  : %s (x%s)" % (rot["last_transient"], rot.get("transient_errors")))
        else:
            out.append("rotation    : none")
        d = st.get("detector") or {}
        out.append("detector    : last=%s consecutive_blocked=%s/%s last_check=%s" % (
            d.get("last_verdict"), d.get("consecutive_bad", 0), cfg["CONSECUTIVE_FAILED_CYCLES"],
            ts(d.get("last_check_at"))))
        if d.get("last_link"):
            out.append("  report    : %s" % d["last_link"])
        ok, why = self.limits()
        out.append("limits      : %s; allocations last 24h=%d (hour cap %s, day cap %s)" % (
            "ok" if ok else why, len(st.get("allocations") or []),
            cfg["MAX_CHANGES_PER_HOUR"], cfg["MAX_CHANGES_PER_DAY"]))
        if st.get("untracked_public_ips"):
            out.append("untracked   : %s (never touched)" % ", ".join(st["untracked_public_ips"]))
        for hst in (st.get("history") or [])[-5:]:
            out.append("history     : %s" % json.dumps(hst, ensure_ascii=False))
        if h or rot:
            out.append("next step   : %s" % self.recovery_hint())
        return "\n".join(out)

    # ------------------------------------------------------------- preflight --
    def preflight(self, probe_writes: bool = False, test_alert: bool = False) -> int:
        cfg = self.cfg
        rows: List[Tuple[str, str, str]] = []

        def row(status: str, item: str, detail: str = "") -> None:
            rows.append((status, item, detail))
            print("[%-4s] %-30s %s" % (status, item, detail))

        probs = config_problems(cfg)
        row("FAIL" if probs else "PASS", "config sanity", "; ".join(probs) or "ok")
        row("PASS" if self.api._key else "FAIL", "API key present",
            getattr(self, "key_source", "") or "missing")
        row("INFO", "server id", "%s (from %s)" % (self.api.server_id, getattr(self, "server_id_source", "?")))
        cur_ip = (self.state.get("current") or {}).get("ip")
        cur_v6: List[str] = []
        if self.api._key:
            try:
                me = self.api.whoami() or {}
                acc = me.get("account") or {}
                row("PASS", "identity (/v1/me)", "%s %s; account %s" % (
                    me.get("identityType"), me.get("identity"), acc.get("name") or acc.get("id")))
            except ApiError as exc:
                row("FAIL" if exc.kind == "unauthenticated" else "WARN", "identity (/v1/me)", str(exc))
            except TransientError as exc:
                row("WARN", "identity (/v1/me)", str(exc))
            try:
                server = self.api.get_server()
                row("PASS", "IaaS read: server", "%s status=%s" % (server.get("name"), server.get("status")))
                exp = cfg.get("EXPECTED_SERVER_NAME")
                if exp and server.get("name") != exp:
                    row("FAIL", "EXPECTED_SERVER_NAME", "server is named %r" % server.get("name"))
                ports = self.api.list_server_ports()
                row("PASS", "IaaS read: ports", "%d port(s)" % len(ports))
                inv = self.api.public_inventory(server, ports)
                row("PASS" if inv else "FAIL", "public IPv4s", ", ".join(
                    "%s(port %s)" % (x["ip"], x["port_id"]) for x in inv) or "none")
                if not cur_ip:
                    want = cfg.get("ADOPT_CURRENT_IP")
                    cur_ip = want or (inv[0]["ip"] if len(inv) == 1 else None)
                    row("PASS" if cur_ip else "FAIL", "current IP (to adopt)",
                        cur_ip or "ambiguous: set ADOPT_CURRENT_IP")
                head = int(cfg["MAX_PUBLIC_IPS_PER_SERVER"]) - len(inv)
                row("PASS" if head >= 1 else "FAIL", "per-server IP headroom", "%d free slot(s)" % head)
                if cur_ip:
                    me_port = next((x for x in inv if x["ip"] == cur_ip), {})
                    cur_v6 = list(me_port.get("ipv6") or [])
                    sn = self.api.subnet_for_ip(cur_ip, me_port.get("network_id"))
                    row("PASS" if sn else "WARN", "IaaS read: networks", (
                        "subnet %s gw %s" % (sn["cidr"], sn["gateway"])) if sn else
                        "could not map current IP to a subnet (gateway discovery may fail)")
                    row("INFO", "security groups to copy", ", ".join(me_port.get("sg_ids") or []) or
                        "(none on port; server groups will be used)")
                    if me_port.get("ipv6"):
                        row("WARN", "IPv6 on current port", "%s will be released together with the old "
                            "IPv4 (AAAA records are not managed)" % ", ".join(me_port["ipv6"]))
                try:
                    q = self.api.get_quotas()
                    row("INFO", "quotas", json.dumps(q, ensure_ascii=False)[:300])
                except (ApiError, TransientError) as exc:
                    row("INFO", "quotas", "unavailable (%s)" % str(exc)[:120])
            except ApiError as exc:
                hint = {"unauthenticated": "key invalid/expired",
                        "forbidden": "key lacks IaaS read permission or server not in its resource group",
                        "not_found": "wrong SERVER_ID or REGION"}.get(exc.kind, "")
                row("FAIL", "IaaS read", "%s %s" % (exc, hint))
            except TransientError as exc:
                row("FAIL", "IaaS read", str(exc))
        mode = cfg["OS_NETWORK_MODE"]
        if mode == "iproute2":
            ok, why = self.net.available()
            row("PASS" if ok else "FAIL", "local network control", why)
        try:
            if cur_ip:
                iface = self.net.find_ip(cur_ip)
                row("PASS" if iface else "WARN", "current IP on interface", iface or
                    "%s not found locally (NAT/floating IP? rotation cannot work)" % cur_ip)
            row("INFO", "default routes", json.dumps(self.net.default_routes()))
            eg = self.net.egress_ip(None)
            row("PASS" if eg and eg == cur_ip else "WARN", "egress IP", "%s (current %s)" % (eg, cur_ip))
        except Exception as exc:  # noqa: BLE001
            row("WARN", "local network inspection", str(exc))
        try:
            probes, controls = self.ch.probe_nodes(), self.ch.control_nodes()
            row("PASS" if len(probes) >= int(cfg["MIN_CONCLUSIVE_NODES"]) else "FAIL",
                "check-host Iranian nodes", "%d: %s" % (len(probes), ", ".join(p.split(".")[0] for p in probes)))
            row("INFO", "check-host control nodes", ", ".join(c.split(".")[0] for c in controls))
        except Exception as exc:  # noqa: BLE001
            row("FAIL", "check-host.net", str(exc))
        if cfg["DNS_CHECK_ENABLED"]:
            dmode = cfg["DNS_UPDATE_MODE"]
            row("INFO", "DNS update mode", "%s for %s" % (dmode, ", ".join(self.dns.fqdns())))
            try:
                row("PASS", "authoritative NS", ", ".join(self.dns.authoritative_servers()))
            except Exception as exc:  # noqa: BLE001
                row("FAIL", "DNS", str(exc))
            proxied = self._preflight_cloudflare(row, cur_ip) if dmode == "cloudflare_api" else set()
            if cur_ip:
                try:
                    ev = self.dns.evaluate(cur_ip, names=[f for f in self.dns.fqdns() if f not in proxied])
                    row("PASS" if ev["ok"] else "WARN", "DNS -> current IP",
                        ("ok" if ev["ok"] else "; ".join(ev["problems"][:4])) +
                        (" (proxied, checked via API: %s)" % ", ".join(sorted(proxied)) if proxied else ""))
                except Exception as exc:  # noqa: BLE001
                    row("FAIL", "DNS", str(exc))
            if cfg["DNS_UPDATE_MODE"] == "arvan_api" and self.api._key:
                for fqdn in self.dns.fqdns():
                    try:
                        recs = self._matching_records(fqdn)
                        bad = [r for r in recs if r.get("cloud") or r.get("is_protected")]
                        row("FAIL" if (not recs or bad) else "PASS", "DNS API record %s" % fqdn,
                            "not found" if not recs else ("proxied/protected record" if bad else
                                                          "%d A record(s), ttl %s" % (len(recs), recs[0].get("ttl"))))
                    except (ApiError, TransientError) as exc:
                        row("FAIL", "DNS API read %s" % fqdn, str(exc))
            can_list = (self.cf is not None and self.cf.has_token) if dmode == "cloudflare_api" \
                else bool(self.api._key)
            if cfg["DNS_AUDIT_ZONE"] and cur_ip and can_list:
                try:
                    unc = self.zone_audit(cur_ip, cur_v6)
                    row("FAIL" if unc else "PASS", "DNS zone audit",
                        ("records on addresses released with %s but not managed here: %s"
                         % (cur_ip, ", ".join(unc))) if unc else
                        "every record pointing at %s is in DNS_NAMES" % cur_ip)
                except (ApiError, TransientError, HaltError) as exc:
                    row("WARN" if dmode == "verify_only" else "FAIL", "DNS zone audit",
                        "cannot list records (%s); list every name that points here in DNS_NAMES"
                        % str(exc)[:120])
        else:
            row("WARN", "DNS verification", "DISABLED - old IP would be released without DNS proof")
        try:
            os.makedirs(cfg["STATE_DIR"], exist_ok=True)
            with tempfile.NamedTemporaryFile(dir=cfg["STATE_DIR"]):
                pass
            row("PASS", "state dir writable", cfg["STATE_DIR"])
        except OSError as exc:
            row("FAIL", "state dir writable", "%s: %s" % (cfg["STATE_DIR"], exc))
        chans = self.alerter.channels()
        row("PASS" if chans else "WARN", "alert channels", ", ".join(chans) or "none (log files only)")
        if test_alert:
            ok = self.alerter.send("warning", "Test alert from arvan_ip_rotator preflight", force=True)
            row("PASS" if ok else "FAIL", "test alert", "delivered" if ok else "delivery failed (queued)")
        if probe_writes and self.api._key:
            fake = str(_uuid.uuid4())
            for label, fn in (("IaaS write probe (detach)", lambda: self.api.detach_port(fake)),
                              ("DNS write probe (PUT)", lambda: self.api.dns_update_record(
                                  self.dns.zone, fake, {"type": "a", "name": "preflight-probe",
                                                        "ttl": 120, "value": [{"ip": "192.0.2.1"}]}))):
                if label.startswith("DNS") and cfg["DNS_UPDATE_MODE"] != "arvan_api":
                    continue
                try:
                    fn()
                    row("WARN", label, "unexpected success on a random id - investigate")
                except ApiError as exc:
                    if exc.kind in ("forbidden", "unauthenticated"):
                        row("FAIL", label, "%s -> key lacks this write permission" % exc.kind)
                    else:
                        row("INFO", label, "HTTP %d (%s): not rejected as forbidden - INCONCLUSIVE"
                            % (exc.status, exc.kind))
                except (TransientError, RotatorError) as exc:
                    row("WARN", label, str(exc))
        if probe_writes and cfg["DNS_CHECK_ENABLED"] and cfg["DNS_UPDATE_MODE"] == "cloudflare_api" \
                and self.cf is not None and self.cf.has_token:
            label = "Cloudflare DNS write probe"
            try:      # PATCH of a random, non-existent record id: cannot change anything
                self.cf.update_record(_uuid.uuid4().hex, {"type": "A", "name": "preflight-probe.%s" % self.dns.zone,
                                                          "content": "192.0.2.1", "ttl": 1, "proxied": False})
                row("WARN", label, "unexpected success on a random record id - investigate")
            except ApiError as exc:
                if exc.kind in ("forbidden", "unauthenticated"):
                    row("FAIL", label, "%s -> token lacks Zone > DNS > Edit on %s" % (exc.kind, self.dns.zone))
                else:
                    row("INFO", label, "HTTP %d (%s): not rejected as forbidden - INCONCLUSIVE (likely OK)"
                        % (exc.status, exc.kind))
            except (TransientError, RotatorError) as exc:
                row("WARN", label, str(exc)[:160])
        row("INFO", "write permissions", "cannot be proven read-only. Conclusive test: "
                                         "'rotate --trial --yes' then 'discard-pending --yes'")
        fails = sum(1 for r in rows if r[0] == "FAIL")
        warns = sum(1 for r in rows if r[0] == "WARN")
        print("\npreflight: %d FAIL, %d WARN" % (fails, warns))
        return 1 if fails else 0

    def _preflight_cloudflare(self, row: Callable[..., None], cur_ip: Optional[str]) -> set:
        """Cloudflare rows of preflight. Returns the proxied names (verified via the API)."""
        cfg, cf, proxied = self.cfg, self.cf, set()
        if cf is None or not cf.has_token:
            row("FAIL", "Cloudflare API token", getattr(self, "cf_token_source", "") or "missing")
            return proxied
        row("PASS", "Cloudflare API token", getattr(self, "cf_token_source", "") or "present")
        try:
            t = cf.verify_token()
            row("PASS" if t.get("status") == "active" else "FAIL", "Cloudflare token status", "%s%s" % (
                t.get("status"), (", expires %s" % t["expires_on"]) if t.get("expires_on") else ", no expiry"))
        except (ApiError, TransientError) as exc:
            row("WARN", "Cloudflare token status", "/user/tokens/verify failed (%s); normal for account-owned "
                "tokens - the record reads below are the real test" % str(exc)[:140])
        try:
            zid = cf.zone_id()
            if cf.zone:
                zp = cf.zone_problem()
                ns_cf = sorted(str(n).rstrip(".").lower() for n in cf.zone.get("name_servers") or [])
                row("FAIL" if zp else "PASS", "Cloudflare zone", zp or "%s id %s, status %s, nameservers %s" % (
                    cf.zone_name, zid, cf.zone.get("status"), ", ".join(ns_cf) or "?"))
                ns_pub = self.dns.ns_names
                if ns_cf and ns_pub and set(ns_pub) != set(ns_cf):
                    row("FAIL" if not set(ns_pub) & set(ns_cf) else "WARN", "Cloudflare is authoritative",
                        "public NS for %s are %s, Cloudflare assigned %s - edits may not reach clients"
                        % (cf.zone_name, ", ".join(ns_pub), ", ".join(ns_cf)))
                elif ns_cf and ns_pub:
                    row("PASS", "Cloudflare is authoritative", "public NS match Cloudflare's")
            else:
                row("INFO", "Cloudflare zone", "%s id %s (CLOUDFLARE_ZONE_ID; status not checked)" % (cf.zone_name, zid))
            for fqdn in self.dns.fqdns():
                recs = self._cf_records(fqdn)
                mine = [r for r in recs if r.get("content") == cur_ip] if cur_ip else recs
                desc = ", ".join("A %s ttl %s%s" % (r.get("content"), "auto" if int(r.get("ttl") or 1) == 1
                                                    else r.get("ttl"), " PROXIED" if r.get("proxied") else "")
                                 for r in recs) or "no A record"
                status = "PASS"
                if not mine:
                    status, desc = "FAIL", desc + " - needs an A record on the current IP %s" % (cur_ip or "(unknown)")
                elif any(r.get("locked") for r in mine):
                    status, desc = "FAIL", desc + " - record is locked"
                elif any(r.get("proxied") for r in mine):
                    proxied.add(fqdn)
                    if not cfg["CLOUDFLARE_ALLOW_PROXIED"]:
                        status, desc = "FAIL", desc + " - make it DNS-only or set CLOUDFLARE_ALLOW_PROXIED=true"
                row(status, "Cloudflare record %s" % fqdn, desc)
        except ApiError as exc:
            hint = {"forbidden": "token lacks DNS access to this zone",
                    "unauthenticated": "token invalid, revoked or expired",
                    "not_found": "zone not visible: grant Zone > Zone > Read or set CLOUDFLARE_ZONE_ID"}.get(exc.kind, "")
            row("FAIL", "Cloudflare DNS read", "%s %s" % (exc, hint))
        except (TransientError, HaltError) as exc:
            row("FAIL", "Cloudflare DNS read", str(exc)[:200])
        return proxied

    # --------------------------------------------------------------- dry-run --
    def dry_run_report(self) -> int:
        cfg = self.cfg
        assert self.dry_run and self.http.read_only and self.store.readonly
        P = print
        P("=" * 78)
        P("DRY RUN - read-only: no ArvanCloud/Cloudflare writes, no OS changes, no state changes, no alerts")
        P("=" * 78)
        server, ports, inv = self.bootstrap()
        cur = self.state["current"]
        old = next(x for x in inv if x["ip"] == cur["ip"])
        sgs = old["sg_ids"] or [g.get("id") for g in (server.get("security_groups") or [])
                                if isinstance(g, dict) and g.get("id")]
        P("\nSTEP 1  RECORD (real, read-only)")
        P("  server        : %s  %s  status=%s" % (self.api.server_id, server.get("name"), server.get("status")))
        P("  public IPv4s  : %s" % ", ".join("%s(port %s)" % (x["ip"], x["port_id"]) for x in inv))
        P("  current/old   : %s  port=%s  mac=%s" % (old["ip"], old["port_id"], old["mac"]))
        P("  sec. groups   : %s" % (", ".join(sgs) or "(none -> arDefault)"))
        ok, why = self.limits()
        P("  rate limits   : %s" % ("would allow a rotation now" if ok else "WOULD BLOCK: " + why))
        head = int(cfg["MAX_PUBLIC_IPS_PER_SERVER"]) - len(inv)
        P("  IP headroom   : %d slot(s) (MAX_PUBLIC_IPS_PER_SERVER=%s)%s" % (
            head, cfg["MAX_PUBLIC_IPS_PER_SERVER"], "" if head >= 1 else "  -> WOULD REFUSE"))
        try:
            P("  quotas        : %s" % json.dumps(self.api.get_quotas(), ensure_ascii=False)[:300])
        except (ApiError, TransientError) as exc:
            P("  quotas        : unavailable (%s)" % str(exc)[:100])
        P("\nSTEP 2  ALLOCATE (simulated - NOT sent)")
        P("  would send    : %s" % json.dumps(self.api.add_public_ip_request_preview(sgs)))
        P("  expected resp : {data:{port_id, mac_addr, fixed_ips:[{ip_address, subnet_id}]}} -> new NIC")
        P("\nSTEP 3  VERIFY (simulated for the new IP; real read-only checks of the current IP)")
        mode = cfg["OS_NETWORK_MODE"]
        try:
            P("  OS mode       : %s %s" % (mode, ("(%s)" % self.net.available()[1]) if mode == "iproute2" else ""))
            P("  current IP on : %s" % (self.net.find_ip(cur["ip"]) or "NOT FOUND on any interface"))
            routes = self.net.default_routes()
            P("  default routes: %s" % json.dumps(routes))
        except Exception as exc:  # noqa: BLE001
            routes = []
            P("  local inspect : failed (%s)" % exc)
        try:
            res = self.reach.cycle(cur["ip"], "dry-run")
            P("  Iran probe    : %s - %s" % (res["verdict"], res.get("why")))
            P("  report        : %s" % res.get("link"))
        except (InconclusiveError, TransientError) as exc:
            P("  Iran probe    : INCONCLUSIVE (%s)" % exc)
        d = self.state.get("detector") or {}
        P("  detector      : %s/%s consecutive blocked cycles recorded by the daemon" % (
            d.get("consecutive_bad", 0), cfg["CONSECUTIVE_FAILED_CYCLES"]))
        P("\nSTEP 4  SWITCH (simulated)")
        if mode == "iproute2":
            plan = self.net.switch_plan("<NEW_GW>", "<NEW_IFACE>", "<NEW_IP>", routes)
            for c in plan["apply"]:
                P("  would run     : ip %s" % " ".join(c))
            for c in plan["revert"]:
                P("  revert/watchdg: ip %s" % " ".join(c))
            P("  + policy rules: 'ip rule from <NEW_IP> lookup %s' and the same for %s, so both IPs "
              "answer correctly during the drain" % (cfg["POLICY_TABLE"], cur["ip"]))
        else:
            P("  mode %s: switching handled by %s" % (mode, "OS_CONFIGURE_HOOK" if mode == "hook" else "the OS"))
        P("\nSTEP 5  DNS (real read-only lookups)")
        if cfg["DNS_CHECK_ENABLED"]:
            ev = self.dns.evaluate(cur["ip"])
            for fqdn, entry in ev["names"].items():
                for kind in ("authoritative", "public"):
                    for srv, r in entry[kind].items():
                        P("  %-13s : %s @%s -> %s ttl=%s" % (kind[:13], fqdn, srv, r.get("ips") or r.get("error")
                                                            or r.get("rcode"), r.get("ttl")))
            dmode = cfg["DNS_UPDATE_MODE"]
            P("  mode          : %s%s" % (dmode, ("  (token: %s)" % getattr(self, "cf_token_source", "?"))
                                          if dmode == "cloudflare_api" else ""))
            if cfg["DNS_AUDIT_ZONE"]:
                try:
                    unc = self.zone_audit(cur["ip"], old.get("ipv6") or [])
                    P("  zone audit    : %s" % (("WOULD REFUSE - pointing at released addresses but not "
                                                 "managed: %s" % ", ".join(unc)) if unc else
                                                "ok (all records covered)"))
                except (ApiError, TransientError, HaltError) as exc:
                    P("  zone audit    : unavailable (%s)" % str(exc)[:100])
            try:
                self._dns_precheck(cur["ip"], old.get("ipv6") or [], audit=False)
                P("  precheck      : ok - the DNS step can run")
            except RotationRefused as exc:
                P("  precheck      : WOULD REFUSE - %s" % exc)
            except (ApiError, TransientError, HaltError) as exc:
                P("  precheck      : unavailable (%s)" % str(exc)[:160])
            if dmode == "cloudflare_api":
                try:
                    zid = self._cf().zone_id()
                    for fqdn in self.dns.fqdns():
                        for rec in self._cf_records(fqdn):
                            if rec.get("content") != cur["ip"]:
                                P("  left as is    : %s A %s (not the current IP)" % (fqdn, rec.get("content")))
                                continue
                            body = self._cf().patch_body(rec, "<NEW_IP>", int(cfg["DNS_RECORD_TTL"] or 0))
                            P("  would PATCH   : /zones/%s/dns_records/%s %s%s" % (
                                zid, rec.get("id"), json.dumps(body),
                                "  (proxied: verified via the API)" if rec.get("proxied") else ""))
                except (ApiError, TransientError, HaltError) as exc:
                    P("  cloudflare    : unavailable (%s)" % str(exc)[:160])
            if dmode == "arvan_api":
                for fqdn in self.dns.fqdns():
                    for rec in self._matching_records(fqdn):
                        body = self._dns_body(rec, self._clean_values(rec.get("value"), cur["ip"], "<NEW_IP>"))
                        P("  would PUT     : /domains/%s/dns-records/%s %s" % (self.dns.zone, rec.get("id"),
                                                                            json.dumps(body)))
            ttl = ev.get("max_auth_ttl") or 0
            P("\nSTEP 6  DRAIN: %ss after authoritative DNS shows the new IP (TTL %s, min %s, +%s extra)" % (
                max(ttl, int(cfg["DNS_DRAIN_MIN_SEC"])) + int(cfg["DNS_DRAIN_EXTRA_SEC"]), ttl,
                cfg["DNS_DRAIN_MIN_SEC"], cfg["DNS_DRAIN_EXTRA_SEC"]))
        else:
            P("  DNS verification DISABLED")
        P("\nSTEP 7  RELEASE OLD IP (simulated - NOT sent; only after all gates pass)")
        P("  would send    : %s" % json.dumps(self.api.detach_request_preview(old["port_id"])))
        muts = list(self.http.mutations)
        P("\nmutating HTTP requests made during this dry run: %d" % len(muts))
        return 0 if not muts else 1


# =============================================================================
# Config validation, credentials, server identity, wiring
# =============================================================================
def _config_type_problems(cfg: Dict[str, Any]) -> List[str]:
    p = []
    for k, default in CONFIG.items():
        v = cfg.get(k)
        if isinstance(default, bool):
            if not isinstance(v, bool):
                p.append("%s must be true or false (got %r)" % (k, v))
        elif isinstance(default, (int, float)):
            if isinstance(v, bool) or not isinstance(v, (int, float)):
                p.append("%s must be a number (got %r)" % (k, v))
        elif isinstance(default, list):
            if not isinstance(v, list):
                p.append('%s must be a JSON list, e.g. ["a","b"] (got %r)' % (k, v))
    return p


def config_problems(cfg: Dict[str, Any]) -> List[str]:
    """Every problem here makes run/rotate/resume refuse to start."""
    p = _config_type_problems(cfg)
    if not p:                      # value checks assume the types are right
        try:
            p.extend(_config_value_problems(cfg))
        except (TypeError, ValueError, KeyError) as exc:
            p.append("invalid config value: %s" % exc)
    known = {"ROTATOR_" + k for k in CONFIG} | {"ROTATOR_ACTION"}
    known |= {str(cfg.get(k)) for k in CONFIG if k.endswith("_ENV")}
    for name in sorted(os.environ):
        if name.startswith("ROTATOR_") and name not in known:
            p.append("unknown environment variable %s (typo? it would be ignored)" % name)
    return p


def _config_value_problems(cfg: Dict[str, Any]) -> List[str]:
    p = []
    if cfg["CHECK_TYPE"] not in ("tcp", "ping", "http"):
        p.append("CHECK_TYPE must be tcp|ping|http")
    if cfg["OS_NETWORK_MODE"] not in ("iproute2", "hook", "none"):
        p.append("OS_NETWORK_MODE must be iproute2|hook|none")
    if cfg["OS_NETWORK_MODE"] == "hook" and not cfg["OS_CONFIGURE_HOOK"]:
        p.append("OS_NETWORK_MODE=hook needs OS_CONFIGURE_HOOK")
    dmode = cfg["DNS_UPDATE_MODE"]
    if dmode not in ("cloudflare_api", "arvan_api", "verify_only"):
        p.append("DNS_UPDATE_MODE must be cloudflare_api|arvan_api|verify_only")
    if not 0 < float(cfg["FAIL_RATIO_THRESHOLD"]) < 1:
        p.append("FAIL_RATIO_THRESHOLD must be in (0,1)")
    if not 0 < float(cfg["VERIFY_MIN_SUCCESS_RATIO"]) <= 1:
        p.append("VERIFY_MIN_SUCCESS_RATIO must be in (0,1]")
    for k in ("MIN_CONCLUSIVE_NODES", "CONSECUTIVE_FAILED_CYCLES", "VERIFY_CYCLES",
              "MAX_CHANGES_PER_HOUR", "MAX_CHANGES_PER_DAY", "MAX_ADD_ATTEMPTS"):
        if int(cfg[k]) < 1:
            p.append("%s must be >= 1" % k)
    if int(cfg["MAX_CHANGES_PER_DAY"]) < int(cfg["MAX_CHANGES_PER_HOUR"]):
        p.append("MAX_CHANGES_PER_DAY < MAX_CHANGES_PER_HOUR")
    if float(cfg["CHECKHOST_MIN_SPACING_SEC"]) < 30:
        p.append("CHECKHOST_MIN_SPACING_SEC < 30 will hit check-host.net rate limits")
    if float(cfg["CHECK_INTERVAL_SEC"]) < 120:
        p.append("CHECK_INTERVAL_SEC < 120 is too aggressive for check-host.net")
    ttl = int(cfg["DNS_RECORD_TTL"] or 0)
    if dmode == "cloudflare_api" and not (ttl in (0, 1) or 60 <= ttl <= 86400):
        p.append("DNS_RECORD_TTL must be 0 (keep), 1 (automatic) or 60..86400 for Cloudflare")
    if dmode == "arvan_api" and ttl not in (0, 120, 180, 300, 600, 900, 1800, 3600, 7200,
                                            18000, 43200, 86400, 172800, 432000):
        p.append("DNS_RECORD_TTL must be 0 or an ArvanCloud TTL value (120, 180, 300, ...)")
    zid = str(cfg["CLOUDFLARE_ZONE_ID"] or "")
    if zid and not re.match(r"^[0-9a-fA-F]{32}$", zid):
        p.append("CLOUDFLARE_ZONE_ID must be empty or the 32-character hex Zone ID (Cloudflare "
                 "dashboard > the zone > Overview > API)")
    if dmode == "cloudflare_api" and cfg["DNS_CHECK_ENABLED"]:
        try:
            tok, src = load_cf_token(cfg)
            if not tok:
                p.append("DNS_UPDATE_MODE=cloudflare_api needs a Cloudflare API token: %s" % src)
        except RotatorError as exc:
            p.append(str(exc))
    if cfg["DNS_CHECK_ENABLED"] and not cfg["DNS_NAMES"]:
        p.append("DNS_NAMES is empty")
    if int(cfg["ROUTE_SWITCH_CONFIRM_TIMEOUT_SEC"]) < 60:
        p.append("ROUTE_SWITCH_CONFIRM_TIMEOUT_SEC < 60 risks premature auto-revert")
    if not re.match(r"^[a-z]{2}-[a-z0-9]+-[a-z0-9]+$", str(cfg["REGION"])):
        p.append("REGION %r does not look like an ArvanCloud region code (e.g. ir-thr-ba1)" % cfg["REGION"])
    return p


def _load_secret(cfg: Dict[str, Any], cred_name: str, file_key: str, env_key: str,
                 label: str, strip: Callable[[str], str]) -> Tuple[Optional[str], str]:
    """systemd credential -> <file_key> file (must be chmod 600) -> env var named by <env_key>."""
    cands: List[Tuple[str, bool]] = []
    cd = os.environ.get("CREDENTIALS_DIRECTORY")
    if cd:
        cands.append((os.path.join(cd, cred_name), True))
    if cfg.get(file_key):
        cands.append((str(cfg[file_key]), False))
    for path, trusted in cands:
        if os.path.isfile(path):
            mode = os.stat(path).st_mode
            if not trusted and mode & 0o077:
                raise RotatorError("refusing %s file %s: permissions %o are too open (chmod 600)"
                                   % (label, path, mode & 0o777))
            with open(path, encoding="utf-8") as fh:
                val = fh.read().strip()
            if val:
                return strip(val), "file:%s" % path
    val = os.environ.get(cfg[env_key], "").strip()
    if val:
        return strip(val), "env:$%s" % cfg[env_key]
    return None, "missing (set $%s, %s or the systemd credential %s)" % (cfg[env_key], file_key, cred_name)


def load_api_key(cfg: Dict[str, Any]) -> Tuple[Optional[str], str]:
    return _load_secret(cfg, "arvan_api_key", "API_KEY_FILE", "API_KEY_ENV", "API key", _strip_prefix)


def load_cf_token(cfg: Dict[str, Any]) -> Tuple[Optional[str], str]:
    tok, src = _load_secret(cfg, "cloudflare_api_token", "CLOUDFLARE_API_TOKEN_FILE",
                            "CLOUDFLARE_API_TOKEN_ENV", "Cloudflare API token",
                            lambda v: v[7:].strip() if v.lower().startswith("bearer ") else v)
    if tok and not re.match(r"^[\x21-\x7e]+$", tok):
        raise RotatorError("the Cloudflare API token from %s contains spaces or non-printable characters" % src)
    if tok and re.match(r"^[0-9a-f]{37}$", tok):
        raise RotatorError("the value in %s looks like the Cloudflare Global API Key; create a scoped API "
                           "Token instead (My Profile > API Tokens > Create Token > Edit zone DNS)" % src)
    return tok, src


def _strip_prefix(key: str) -> str:
    return key[7:].strip() if key.lower().startswith("apikey ") else key


def resolve_server_id(cfg: Dict[str, Any], http: Http,
                      state_sid: Optional[str] = None) -> Tuple[str, str]:
    if cfg.get("SERVER_ID"):
        return str(cfg["SERVER_ID"]), "config"
    try:
        r = http.request("GET", cfg["METADATA_URL"], no_proxy=True, timeout=4, retries=1)
        uid = (r.json or {}).get("uuid") if r.status == 200 else None
        if uid:
            return str(uid), "metadata"
        raise RotatorError("metadata HTTP %s without uuid" % r.status)
    except (RotatorError, TransientError) as exc:
        if state_sid:          # metadata route can vanish after the original NIC is released
            return str(state_sid), "state (metadata unavailable: %s)" % str(exc)[:80]
        raise RotatorError("SERVER_ID is not configured and the metadata service is unavailable "
                           "(%s); set ROTATOR_SERVER_ID" % exc)


def build(cfg: Dict[str, Any], *, dry_run: bool = False, readonly_state: bool = False,
          clock: Optional[Clock] = None, net: Any = None, need_server: bool = True,
          dns_client: Optional[DnsClient] = None) -> Rotator:
    clock = clock or Clock()
    log = EventLog(cfg)
    http = Http(cfg, log, clock, read_only=dry_run)
    key, key_src = load_api_key(cfg)
    store = StateStore(cfg["STATE_DIR"], log, readonly=dry_run or readonly_state)
    if need_server:
        try:
            state_sid = store.load().get("server_id")
        except RotatorError:
            state_sid = None
        sid, sid_src = resolve_server_id(cfg, http, state_sid)
    else:
        sid, sid_src = (cfg.get("SERVER_ID") or None), "config"
    api = ArvanAPI(cfg, http, log, key, sid)
    cf: Optional[CloudflareAPI] = None
    cf_src = "not used (DNS_UPDATE_MODE=%s)" % cfg["DNS_UPDATE_MODE"]
    if cfg["DNS_UPDATE_MODE"] == "cloudflare_api":
        try:
            cf_token, cf_src = load_cf_token(cfg)
        except RotatorError as exc:      # reported by config_problems / preflight; never used
            cf_token, cf_src = None, "unusable: %s" % exc
        cf = CloudflareAPI(cfg, http, log, cf_token)
    ch = CheckHost(cfg, http, log, clock)
    reach = Reachability(cfg, ch, log)
    dns = DnsVerifier(cfg, log, dns_client)
    net = net or LinuxNet(cfg, log, clock, cfg["STATE_DIR"], read_only=dry_run)
    alerter = Alerter(cfg, http, log, cfg["STATE_DIR"], clock, readonly=dry_run)
    r = Rotator(cfg, log, store, http, api, ch, reach, dns, net, alerter, clock, dry_run=dry_run, cf=cf)
    if not sid and r.state.get("server_id"):
        api.server_id = r.state["server_id"]
    r.key_source, r.server_id_source = key_src, sid_src  # type: ignore[attr-defined]
    r.cf_token_source = cf_src  # type: ignore[attr-defined]
    return r


# =============================================================================
# CLI
# =============================================================================
EPILOG = """\
typical first run:
  export ARVAN_API_KEY=...       # or systemd LoadCredential=arvan_api_key:/path
  export CLOUDFLARE_API_TOKEN=...  # or LoadCredential=cloudflare_api_token:/path
  %(prog)s preflight             # read-only checks (+ --probe-writes / --test-alert)
  %(prog)s rotate --dry-run      # exact plan, zero changes
  %(prog)s rotate --trial --yes  # allocate + configure + verify a new IP, then STOP
  %(prog)s discard-pending --yes # release the trial IP (or: resume)
  %(prog)s run                   # daemon (see the systemd unit in the README)

exit codes: 0 ok | 1 error | 2 halted | 3 refused/not needed | 4 temporary failure/stopped
"""


def _install_signal_handlers() -> None:
    def _h(signum: int, _frame: Any) -> None:
        STOP_EVENT.set()
    signal.signal(signal.SIGTERM, _h)
    signal.signal(signal.SIGINT, _h)


def _code_for(res: str) -> int:
    return {"done": 0, "idle": 0, "paused": 0, "discarded": 0, "acknowledged": 0,
            "not halted": 0, "nothing to discard": 0, "halted": 2, "aborted": 2}.get(res, 4)


def format_cycle(res: Dict[str, Any]) -> str:
    lines = ["verdict: %s - %s" % (res.get("verdict"), res.get("why")),
             "report : %s" % res.get("link")]
    for n, x in sorted((res.get("nodes") or {}).items()):
        lines.append("  %-4s %-26s %-7s %s" % ("IR" if x["probe"] else "CTRL", n, x["v"], x["d"]))
    if res.get("probe_guard"):
        lines.append("probe-health guard: %s" % json.dumps(res["probe_guard"]))
    return "\n".join(lines)


def daemon_failure_alert(cfg: Dict[str, Any], what: str) -> None:
    """Best-effort alert when the daemon cannot run (no Rotator exists yet).

    Throttled per distinct message to once per ALERT_REMIND_EVERY_SEC, so a
    systemd restart loop yields hourly reminders instead of spam."""
    with contextlib.suppress(Exception):
        clock = Clock()
        log = EventLog(cfg)
        marker = os.path.join(str(cfg["STATE_DIR"]), "daemon_failure_alerts.json")
        try:
            with open(marker, encoding="utf-8") as fh:
                seen = json.load(fh)
        except (OSError, ValueError):
            seen = {}
        try:
            every = float(cfg.get("ALERT_REMIND_EVERY_SEC") or 3600)
        except (TypeError, ValueError):
            every = 3600.0
        key = re.sub(r"\d+", "#", what)[:160]
        now = clock.time()
        if now - float(seen.get(key, 0)) < every:
            return
        log.critical("daemon_not_running", reason=what)
        Alerter(cfg, Http(cfg, log, clock), log, str(cfg["STATE_DIR"]), clock).send(
            "critical", "DAEMON NOT MONITORING: %s" % what,
            {"action": "fix the cause; systemd keeps retrying and this alert repeats while it fails"})
        seen = {k: v for k, v in seen.items() if now - float(v) < 86400}
        seen[key] = now
        os.makedirs(str(cfg["STATE_DIR"]), exist_ok=True)
        tmp = marker + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(seen, fh)
        os.replace(tmp, marker)


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(
        prog=os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else "arvan_ip_rotator.py",
        description="Rotate an ArvanCloud server's public IPv4 when blocked from Iran "
                    "(make-before-break, DNS-verified).",
        epilog=EPILOG, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--version", action="version", version=__version__)
    sub = ap.add_subparsers(dest="cmd")
    p = sub.add_parser("preflight", help="read-only environment/permission checks")
    p.add_argument("--probe-writes", action="store_true",
                   help="send harmless write requests against random ids (403 vs 404)")
    p.add_argument("--test-alert", action="store_true", help="send a test alert")
    p = sub.add_parser("check", help="one Iran reachability cycle (no changes)")
    p.add_argument("--ip", help="IP to check (default: current)")
    p = sub.add_parser("status", help="show state (read-only, no lock)")
    p.add_argument("--json", action="store_true")
    sub.add_parser("run", help="daemon: monitor and rotate automatically")
    p = sub.add_parser("rotate", help="manual rotation")
    g = p.add_mutually_exclusive_group()
    g.add_argument("--dry-run", action="store_true", help="zero changes; print the plan")
    g.add_argument("--trial", action="store_true",
                   help="allocate+configure+verify a new IP, then stop before switching")
    p.add_argument("--force", action="store_true", help="rotate even if current IP is not blocked")
    p.add_argument("--ignore-limits", action="store_true", help="bypass cooldown/hourly/daily caps")
    p.add_argument("--yes", action="store_true", help="confirm a billable/real change")
    sub.add_parser("resume", help="continue a paused (trial) or acknowledged rotation")
    p = sub.add_parser("discard-pending", help="abort rotation: release ONLY the new IP")
    p.add_argument("--yes", action="store_true")
    p.add_argument("--skip-dns-revert", action="store_true",
                   help="do not touch DNS: you already pointed the records back at the old IP by hand")
    p = sub.add_parser("ack", help="acknowledge a halt after fixing its cause")
    p.add_argument("--yes", action="store_true")
    sub.add_parser("config", help="print effective config (secrets redacted)")
    args = ap.parse_args(argv)
    if not args.cmd:
        ap.print_help()
        return 1
    cfg = load_config()
    probs = config_problems(cfg)
    if args.cmd == "config":
        print(json.dumps(redact(cfg), indent=2, ensure_ascii=False))
        for pr in probs:
            print("CONFIG PROBLEM: %s" % pr, file=sys.stderr)
        return 1 if probs else 0
    changes = args.cmd in ("run", "resume") or (args.cmd == "rotate" and not args.dry_run)
    if probs:
        print("%s configuration:\n  - %s" % ("REFUSED: invalid" if changes else "WARNING: problems in",
                                            "\n  - ".join(probs)))
        if changes:
            if args.cmd == "run":
                daemon_failure_alert(cfg, "invalid configuration: %s" % "; ".join(probs))
            return 3
    _install_signal_handlers()
    r: Optional[Rotator] = None
    try:
        if args.cmd == "status":
            r = build(cfg, readonly_state=True, need_server=False)
            print(json.dumps(redact(r.state), indent=2, default=str) if args.json else r.status_text())
            return 2 if r.state.get("halt") else 0
        if args.cmd == "rotate" and args.dry_run:
            r = build(cfg, dry_run=True)
            return r.dry_run_report()
        if args.cmd == "preflight":
            r = build(cfg, readonly_state=True)
            return r.preflight(args.probe_writes, args.test_alert)
        if args.cmd == "check":
            r = build(cfg, readonly_state=True)
            ip = args.ip or (r.state.get("current") or {}).get("ip")
            if not ip:
                inv = r.api.public_inventory()
                if len(inv) != 1:
                    print("cannot pick current IP automatically (%d public IPs); use --ip" % len(inv))
                    return 1
                ip = inv[0]["ip"]
            res = r.reach.cycle(ip, "manual-check")
            print(format_cycle(res))
            return 0 if res["verdict"] == REACHABLE else 3
        r = build(cfg)
        r.store.acquire_lock()
        if args.cmd == "run":
            if cfg["OS_NETWORK_MODE"] == "iproute2":
                ok, why = r.net.available()
                if not ok:
                    print("ERROR: OS_NETWORK_MODE=iproute2 but %s" % why)
                    daemon_failure_alert(cfg, "OS_NETWORK_MODE=iproute2 but %s" % why)
                    return 1
            return r.run_forever()
        if args.cmd in ("ack", "discard-pending") and not args.yes:
            print("refusing without --yes")
            return 3
        if args.cmd == "ack":
            res = r.ack()
        elif args.cmd == "discard-pending":
            res = r.discard_pending(skip_dns_revert=args.skip_dns_revert)
        elif args.cmd == "resume":
            res = r.resume()
        else:  # rotate (real or trial)
            if not args.yes:
                print("A real rotation allocates a billable IP and changes networking. "
                      "Re-run with --yes, or use --dry-run.")
                return 3
            r.bootstrap()
            mode = "trial" if args.trial else ("force" if args.force else "manual")
            if mode == "manual":
                chk = r.check_cycle()
                if chk["verdict"] != BLOCKED:
                    print("current IP %s is %s from Iran (%s); use --force to rotate anyway"
                          % (r.state["current"]["ip"], chk["verdict"], chk.get("why")))
                    return 3
            res = r.start_rotation(mode, "manual rotate (%s)" % mode, ignore_limits=args.ignore_limits)
        print(res)
        print(r.status_text())
        return _code_for(res)
    except StopRequested:
        print("stopped by signal; state is saved - re-run the same command or 'resume'")
        return 4
    except HaltError as exc:
        if r is not None and not r.dry_run and not r.store.readonly:
            r.halt(str(exc))
        elif args.cmd == "run":
            daemon_failure_alert(cfg, "HALT at start-up: %s" % exc)
        print("HALT: %s" % exc)
        return 2
    except RotationRefused as exc:
        print("REFUSED: %s" % exc)
        return 3
    except TransientError as exc:
        print("TEMPORARY FAILURE (state saved; retry or 'resume' later): %s" % exc)
        return 4
    except LockHeldError as exc:          # another instance is active: not an outage
        print("ERROR: %s" % exc)
        return 1
    except RotatorError as exc:
        if args.cmd == "run":
            daemon_failure_alert(cfg, "start-up error: %s" % exc)
        print("ERROR: %s" % exc)
        return 1
    except Exception as exc:  # noqa: BLE001
        if args.cmd == "run":
            daemon_failure_alert(cfg, "daemon crashed: %r" % exc)
        raise
    finally:
        if r is not None:
            r.store.release_lock()


if __name__ == "__main__":
    sys.exit(main())
