# arvan-ip-rotator

Rotates the public IPv4 of an ArvanCloud cloud server when Iran can no longer reach it, and moves the Cloudflare A records `gt.honeyhost.click`, `px.honeyhost.click` and `sb.honeyhost.click` to the new IP. The order is strictly make-before-break: **record → allocate new → verify → switch → update and verify DNS → drain → release old**.
The tool is one file (`arvan_ip_rotator.py`) that needs only the Python 3.8+ standard library. It runs on the server whose IP it rotates.

> **Status:** this has **not** been run against the real ArvanCloud or Cloudflare APIs, because no credentials were available when it was written. It passes 61 fault-injection scenarios against mocks (`python3 tests/test_scenarios.py`). Before you trust it, go through the first-run sequence below and check every item in `ASSUMPTIONS.md`.

## What it does

- **Probing:** every `CHECK_INTERVAL_SEC` (300 s), check-host.net probes the current IP (TCP 443 by default) from up to 10 Iranian nodes. In the same request, 3 non-Iranian control nodes probe it too, and the Iranian nodes also probe a known-good target (1.1.1.1:443).
- **Verdicts:**
  - **BLOCKED:** at least 3 Iranian nodes gave a clear answer, more than 50 % of them failed, at least one control node reached the server, and at least one Iranian node reached 1.1.1.1 (proving the probes themselves work).
  - **DOWN:** the server is unreachable from everywhere. It alerts and does not rotate.
  - **INCONCLUSIVE:** it never acts on this verdict.
- **When it rotates:** after **2 BLOCKED cycles in a row**, subject to these limits:
  - a 1 h cooldown after each rotation
  - a 15 min back-off after a failed attempt
  - at most 1 new IP per hour and 3 per day
  - at most 4 public IPs on the server

  If one of these limits stops a rotation the server needs, it **alerts instead of rotating**.
- **DNS (Cloudflare):** once egress has moved to the new IP, it sends one `PATCH` per record to the Cloudflare API. Only the IP changes: each record keeps its TTL and proxy setting unless you set `DNS_RECORD_TTL`. The old IP is released only after Cloudflare's authoritative nameservers and 1.1.1.1, 8.8.8.8 and 9.9.9.9 all return the new IP, and the TTL drain has passed.
- **DNS checks before buying an IP:** it refuses to rotate, and spends nothing, if:
  - one of the records is missing, doesn't point at the current IP, or is locked
  - one of the records is proxied (orange cloud), unless `CLOUDFLARE_ALLOW_PROXIED=true`
  - Cloudflare isn't serving the zone: the zone isn't active, or the real nameservers return something else
  - the zone audit finds another A record in the zone, or an AAAA record on the old IPv6, that points at an address about to be released
- **Phases:** `PRE_ALLOCATE → ALLOCATED → OS_CONFIGURED → VERIFIED → SWITCHING → SWITCHED → DNS_UPDATED → DNS_VERIFIED → DRAINING → RELEASING → DONE`.
  - Each phase is saved to disk before it runs (write-ahead), so a crash or connection loss mid-change resumes on the next start.
  - Each safety gate is marked `SAFETY GATE n` in the code.
- **On any failure it HALTs:** the state is saved and you get a critical alert with recovery steps (reminders repeat hourly). After that, nothing is touched until you act. **The old IP is released only after the new IP has passed every gate.**

## Setup

**Requirements**
- Linux with systemd and iproute2, Python ≥ 3.8, running as root. Root is needed because the default `OS_NETWORK_MODE=iproute2` adds the new address and its policy routes.
- Outbound HTTPS to `napi.arvancloud.ir`, `api.cloudflare.com`, `check-host.net`, `api.ipify.org`, `ifconfig.me`, `icanhazip.com`, plus your alert endpoint.
- DNS over UDP and TCP port 53 to the zone's nameservers (Cloudflare's `*.ns.cloudflare.com`) and to 1.1.1.1, 8.8.8.8 and 9.9.9.9.
- `gt`, `px` and `sb` must already exist in Cloudflare as A records that point at the current IP. Set them to **DNS only** (grey cloud): a proxied record answers with Cloudflare edge IPs, so DNS can't show that it moved.
- Your services must listen on `0.0.0.0`, not on the old IP. Local firewall rules must not hard-code the old IP. If something does need updating, use `POST_SWITCH_HOOK`.

```sh
sudo install -m 0750 arvan_ip_rotator.py /usr/local/sbin/arvan-ip-rotator
sudo install -d -m 0700 /etc/arvan-ip-rotator
# Secrets never go into the script or the env file:
sudo bash -c 'umask 077; read -rsp "ArvanCloud API key: " K; echo; printf %s "$K" > /etc/arvan-ip-rotator/api_key'
sudo bash -c 'umask 077; read -rsp "Cloudflare API token: " K; echo; printf %s "$K" > /etc/arvan-ip-rotator/cloudflare_api_token'
```

### Cloudflare API token

In the Cloudflare dashboard go to **My Profile → API Tokens → Create Token** and use the **Edit zone DNS** template:
- **Permissions:** keep `Zone → DNS → Edit` and add `Zone → Zone → Read`. The tool needs Zone Read to look up the zone ID and to check that the zone is active. If you set `ROTATOR_CLOUDFLARE_ZONE_ID` (shown on the zone's Overview page), Zone Read is optional, but then `preflight` can't check the zone status.
- **Zone Resources:** Include → Specific zone → `honeyhost.click`.
- **Client IP Address Filtering:** leave it empty. The token is used from the server, and the server's IP is exactly what changes.
- **TTL (token expiry):** optional. `preflight` shows the expiry date.

Use an API **Token**, not the Global API Key. The tool rejects anything that looks like a Global API Key.

### Config file

Create `/etc/arvan-ip-rotator/env` (`chmod 600`). It holds one `ROTATOR_<KEY>=value` line per key you want to change from the `CONFIG` block at the top of the script.
- Values are parsed as JSON.
- Put JSON lists in single quotes.
- Keep comments on their own lines: systemd doesn't support comments after a value.

```sh
# Find the server UUID in the panel (instance details). If unset, it is read from the metadata service.
ROTATOR_SERVER_ID=00000000-0000-0000-0000-000000000000
ROTATOR_REGION=ir-thr-ba1
# List EVERY A record in honeyhost.click that points at this server (gt, px, sb is the default):
ROTATOR_DNS_NAMES='["gt","px","sb"]'
# cloudflare_api (default) = the script updates the A records via Cloudflare.
# verify_only = you update DNS when alerted. arvan_api = ArvanCloud CDN DNS instead of Cloudflare.
ROTATOR_DNS_UPDATE_MODE=cloudflare_api
# Optional: skips the zone lookup (Zone ID from the zone's Overview page):
# ROTATOR_CLOUDFLARE_ZONE_ID=0123456789abcdef0123456789abcdef
ROTATOR_CHECK_PORT=443
# Alerts: Telegram and/or ROTATOR_ALERT_WEBHOOK_URL and/or ROTATOR_ALERT_COMMAND
ROTATOR_ALERT_TG_TOKEN=123456:replace-me
ROTATOR_ALERT_TG_CHAT=123456789
```

`run`, `rotate` and `resume` refuse to start if a value has the wrong type or a `ROTATOR_*` name is unknown, for example a typo. `arvan-ip-rotator config` prints the effective config with secrets redacted.

### Wrapper for manual commands

This wrapper runs manual commands with the same config as the service:

```sh
sudo tee /usr/local/sbin/rotctl >/dev/null <<'SH'
#!/bin/sh
set -a; . /etc/arvan-ip-rotator/env; set +a
export ROTATOR_API_KEY_FILE=/etc/arvan-ip-rotator/api_key
export ROTATOR_CLOUDFLARE_API_TOKEN_FILE=/etc/arvan-ip-rotator/cloudflare_api_token
exec /usr/bin/python3 /usr/local/sbin/arvan-ip-rotator "$@"
SH
sudo chmod 0750 /usr/local/sbin/rotctl
```

### systemd unit

Create `/etc/systemd/system/arvan-ip-rotator.service`:

```ini
[Unit]
Description=ArvanCloud public IPv4 rotator (make-before-break)
Wants=network-online.target
After=network-online.target
StartLimitIntervalSec=0

[Service]
Type=simple
EnvironmentFile=/etc/arvan-ip-rotator/env
# systemd >= 247. On older systemd use instead:
# Environment=ROTATOR_API_KEY_FILE=/etc/arvan-ip-rotator/api_key
# Environment=ROTATOR_CLOUDFLARE_API_TOKEN_FILE=/etc/arvan-ip-rotator/cloudflare_api_token
LoadCredential=arvan_api_key:/etc/arvan-ip-rotator/api_key
LoadCredential=cloudflare_api_token:/etc/arvan-ip-rotator/cloudflare_api_token
ExecStart=/usr/bin/python3 /usr/local/sbin/arvan-ip-rotator run
Restart=always
RestartSec=30
TimeoutStopSec=120
# Lets the detached route watchdog (auto-revert of a bad route switch) outlive a crash or restart:
KillMode=process
NoNewPrivileges=yes
PrivateTmp=yes
ProtectHome=yes

[Install]
WantedBy=multi-user.target
```

Each secret is read from the first source found:

| Order | ArvanCloud API key | Cloudflare API token |
|---|---|---|
| 1. systemd credential | `arvan_api_key` | `cloudflare_api_token` |
| 2. file (must be mode 600) | `ROTATOR_API_KEY_FILE` | `ROTATOR_CLOUDFLARE_API_TOKEN_FILE` |
| 3. environment variable | `$ARVAN_API_KEY` | `$CLOUDFLARE_API_TOKEN` |

Both are redacted in every log. In `cloudflare_api` mode, `run`, `rotate` and `resume` refuse to start without a token.

## Required API permissions

**None of this has been confirmed against real credentials.** `preflight` checks the read permissions, but write permissions can only be proven by making a change (see step 4 of the first run).

### ArvanCloud

Create a dedicated ArvanCloud **machine user** (IAM → Machine user) and give its API key only the access below.

| Service | Calls (base `https://napi.arvancloud.ir`) | Needed for |
|---|---|---|
| Cloud Server, read | `GET /ecc/v1/regions/{region}/servers/{id}`, `…/servers/{id}/ports`, `…/ports/{id}`, `…/networks`, `…/networks/{id}`, `…/quotas` | all modes |
| Cloud Server, write | `POST …/servers/{id}/add-public-ip` (**billable**), `PATCH …/networks/{port_id}/detach` (releases the old IP) | rotation |
| CDN DNS, read | `GET /cdn/4.0/domains/honeyhost.click/dns-records` | `arvan_api` mode (required) and the zone audit in `verify_only` mode (recommended); not used in `cloudflare_api` mode |
| CDN DNS, write | `PUT /cdn/4.0/domains/honeyhost.click/dns-records/{id}` | `arvan_api` mode only |
| Identity, read | `GET https://dejban.arvancloud.ir/v1/me` | `preflight` only (optional) |

### Cloudflare

Used in `cloudflare_api` mode only. All calls use `Authorization: Bearer <token>`.

| Permission | Calls (base `https://api.cloudflare.com/client/v4`) | Needed for |
|---|---|---|
| Zone → Zone → Read | `GET /zones?name=honeyhost.click` | zone ID lookup and the "zone is active" check; not needed if `CLOUDFLARE_ZONE_ID` is set |
| Zone → DNS → Edit (includes read) | `GET /zones/{zone_id}/dns_records` (one name with `name.exact`, or the whole zone for the audit) | precheck, zone audit, read-back and rollback |
| Zone → DNS → Edit | `PATCH /zones/{zone_id}/dns_records/{record_id}` | moving the 3 records to the new IP, and moving them back on `discard-pending` |
| none | `GET /user/tokens/verify` | `preflight` only: token status and expiry |

## First run and dry-run

Stop the service first: commands that change anything need the state lock. `status` is read-only and works while the service runs.

1. **Read-only checks:** `sudo rotctl preflight --probe-writes --test-alert`. This checks:
   - the key, server, ports, networks, quotas and IP headroom
   - that the current IP is on the interface and is the egress IP
   - the Iranian check-host nodes
   - DNS: that it points at the current IP, and the zone audit
   - Cloudflare: the token status, that the zone is active and that the public nameservers are the ones Cloudflare assigned, and that each record exists on the current IP and isn't proxied or locked
   - that alerts are delivered

   `--probe-writes` sends a detach against a random ID, plus a Cloudflare `PATCH` against a random record ID (a DNS PUT in `arvan_api` mode). A 403 proves a permission is missing; any other answer is inconclusive.
2. **One probe of the current IP:** `sudo rotctl check` prints each node's result and the check-host report link. Use `--ip X` to probe another address.
3. **Dry run with zero changes:** `sudo rotctl rotate --dry-run`
   - It prints all 7 steps with the exact API requests and `ip` commands it would run, including each Cloudflare `PATCH` and its body.
   - The HTTP client refuses any mutating method in this mode, and no state is written and no alerts are sent.
   - The last line must read `mutating HTTP requests made during this dry run: 0`.
4. **Trial (real, billable):** `sudo rotctl rotate --trial --yes` allocates a new IPv4, configures it and verifies it from Iran, then **pauses before switching**. DNS isn't touched yet. Then either:
   - `sudo rotctl discard-pending --yes` releases only the trial IP, or
   - `sudo rotctl resume` completes a full rotation to it, including the Cloudflare update.

   This is the only conclusive test of the write permissions and NIC hot-plug.
5. **Start the daemon:** `sudo systemctl enable --now arvan-ip-rotator`, then watch it with `journalctl -fu arvan-ip-rotator`.

`rotate --yes` without `--trial` rotates only if the current IP is BLOCKED right now. Add `--force` to rotate anyway, or `--ignore-limits` to bypass the caps.

Exit codes: `0` ok · `1` error · `2` halted · `3` refused or not needed · `4` temporary failure or stopped.

## Failure recovery

1. Read the alert, which includes a recovery hint, then run `sudo rotctl status`.
2. Stop the service: `sudo systemctl stop arvan-ip-rotator`.
3. Fix the cause, then use one of these commands:
   - `sudo rotctl ack --yes`: clears the halt. It changes nothing else.
   - `sudo rotctl resume`: continues from the saved phase. It re-verifies the new IP if needed and opens a fresh DNS window.
   - `sudo rotctl discard-pending --yes`: rolls back. It restores any DNS records it changed, moves egress back to the old IP and releases **only the new IP**. It is refused once release of the old IP has started.
     - Cloudflare records are put back on the old IP with their original TTL, but only those that still hold the new IP. A record someone else changed in the meantime is left alone.
     - If the records can't be checked (for example the token was revoked), it refuses. Point them back at the old IP by hand, then run `sudo rotctl discard-pending --yes --skip-dns-revert`.
4. Start the service again: `sudo systemctl start arvan-ip-rotator`.

| Halted in phase | Situation | Typical recovery |
|---|---|---|
| none (no rotation) | bad or forbidden key, the current IP vanished, several IPs and it's unclear which is current | fix the cause (set `ROTATOR_ADOPT_CURRENT_IP` if needed), then `ack` |
| `PRE_ALLOCATE`, `ALLOCATED` | add-public-ip was refused (403 or quota), or its reply was lost | `discard-pending` (finds any port this rotation created by comparing the port list with the one saved before the request), or fix the permission or quota, then `ack` + `resume` |
| `OS_CONFIGURED`, `VERIFIED` | the new IP never appeared on a NIC, has no egress, or is BLOCKED from Iran too | usually `discard-pending` (a new IP from a blocked range is likely blocked too); `ack` + `resume` re-verifies from scratch |
| `SWITCHING`, `SWITCHED` | the route switch failed verification; egress was already reverted to the old IP | fix the routing or firewall, then `ack` + `resume`, or `discard-pending` |
| `SWITCHED` | the Cloudflare update was refused (token invalid, revoked or expired, or a permission missing), or a record was changed or deleted after the precheck. The old IP is still attached | fix the token or record, then `ack` + `resume`, or `ack` + `discard-pending` (puts back the records changed so far) |
| `DNS_UPDATED` | DNS didn't show the new IP within 15 min; egress uses the new IP, and the old IP is still attached and answering. In `cloudflare_api` mode Cloudflare accepted the change, so check that the domain's nameservers are Cloudflare's and that the TTL is short | make the records resolve to the new IP (Cloudflare dashboard → DNS → Records), then `ack` + `resume`, or `discard-pending` |
| `DRAINING` | a pre-release re-check failed | fix the cause, then `ack` + `resume` |
| `RELEASING` | the detach of the old IP was refused or never completed; the new IP is fully in service | fix the permission, then `ack` + `resume`, or detach the old IP in the panel, then `ack` + `resume` (it sees that the port is gone) |

Other notes:
- **State files:**
  - State lives in `/var/lib/arvan-ip-rotator/state.json`, with `.bak` as the last good copy. If `state.json` is corrupt, the backup is used automatically. If both are corrupt, the tool refuses to run.
  - **Never delete state during a rotation.** To start over by hand, first make sure only the IP that DNS points at is attached, then move the state file aside.
- **Logs** are JSON lines in `/var/log/arvan-ip-rotator/`: `events.jsonl` (every action), `checks.jsonl` (every probe, with its check-host link) and `alerts.jsonl`. Example: `jq -c '{ts,purpose,ip,verdict,why,link}' /var/log/arvan-ip-rotator/checks.jsonl | tail`.
- **Reboots:** the new IP's OS configuration is live-only unless you set `ROTATOR_PERSIST_NETPLAN=true`, and you get a reminder alert after each rotation. Test a reboot after your trial rotation.
- **DNS timing:**
  - In `verify_only` mode, you have `DNS_GATE_TIMEOUT_SEC` (900 s) after the "ACTION: point … to the NEW IP" alert.
  - Public resolvers can keep the old answer for one TTL, and the DNS gate waits at most 900 s, so keep the TTL short. Cloudflare's "Auto" TTL is 300 s; 60–300 s works.
  - The drain after DNS switches is max(TTL, 120 s) + 300 s. With "Auto" that is 600 s.
