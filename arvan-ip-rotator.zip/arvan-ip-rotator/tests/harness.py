"""Test harness: mock ArvanCloud (IaaS v1 + CDN DNS + identity), mock Cloudflare API v4
(zones + DNS records), mock check-host.net, mock DNS servers, a fake `ip` interpreter,
and a fake clock."""
import http.server
import importlib.util
import ipaddress
import json
import os
import random
import socket
import socketserver
import struct
import tempfile
import threading
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location("rot", os.path.join(HERE, "..", "arvan_ip_rotator.py"))
rot = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rot)

API_KEY = "0f1e2d3c-4b5a-6978-8796-a5b4c3d2e1f0"
CF_TOKEN = "cfTEST_k9Qm2Zx7Lw4Rt8Yp1Vb6Nc3Hs5Jd0Fg2A"
CF_EDGE_IP = "104.21.7.7"          # what public DNS shows for a proxied (orange-cloud) name
ZONE = "honeyhost.click"


class FakeClock(rot.Clock):
    def __init__(self, t0=1_800_000_000.0):
        self.t = t0

    def time(self):
        return self.t

    def sleep(self, s):
        if s > 0:
            self.t += s


# ----------------------------------------------------------------------------- world
class World:
    def __init__(self):
        self.lock = threading.RLock()
        self.region, self.server_id, self.server_name = "ir-thr-ba1", "srv-1111-2222", "honey-1"
        self.cidr, self.gw = "185.10.20.0/24", "185.10.20.1"
        self.pool = ["185.10.20.%d" % i for i in range(50, 90)]
        self.ports = {}
        self.mac_seq = 0
        self.port_seq = 0
        self.blocked = set()
        self.server_down = False
        self.iran_probe_outage = False
        self.limit_exceeded_remaining = 0
        self.ir_alive = 7
        self.faults = {}
        self.calls = []
        self.net = None
        self.port_build_gets = 1
        self.records = {}
        self.dns_auth = {}
        self.dns_pub = {}
        self.pub_pending = []
        self.public_lag = 1
        self.ttl = 120
        self.cdn_proxied = False
        # Cloudflare mock state
        self.cf_token = CF_TOKEN
        self.cf_zone_id = "9f8e7d6c5b4a39281706f5e4d3c2b1a0"
        self.cf_zone_status, self.cf_zone_type = "active", "full"
        self.cf_records = {}
        self.cf_patches = []           # (record_id, body) of every PATCH that was applied
        self.cf_per_page_cap = 100
        self.cf_seq = 0
        primary = self.create_port(ip="185.10.20.10", status="ACTIVE", notify=False)
        self.primary_port = primary["id"]
        for name in ("@", "www"):
            rid = "rec-%s" % ("apex" if name == "@" else name)
            self.records[rid] = {"id": rid, "type": "a", "name": name, "ttl": self.ttl, "cloud": False,
                                 "upstream_https": "default", "is_protected": False,
                                 "ip_filter_mode": {"count": "single", "geo_filter": "none", "order": "none"},
                                 "value": [{"ip": "185.10.20.10", "port": None, "weight": None, "country": ""}]}
            self.dns_auth[self.fqdn(name)] = ["185.10.20.10"]
            self.dns_pub[self.fqdn(name)] = ["185.10.20.10"]

    @staticmethod
    def fqdn(name):
        return ZONE if name == "@" else "%s.%s" % (name, ZONE)

    def cf_add(self, name, ip, proxied=False, rtype="A", ttl=1):
        with self.lock:
            self.cf_seq += 1
            rid = "%032x" % (0xcf000 + self.cf_seq)
            fq = self.fqdn(name)
            self.cf_records[rid] = {"id": rid, "zone_id": self.cf_zone_id, "zone_name": ZONE, "name": fq,
                                    "type": rtype, "content": ip, "proxiable": True, "proxied": proxied,
                                    "ttl": ttl, "locked": False, "meta": {"auto_added": False},
                                    "comment": None, "tags": []}
            vis = self.cf_visible(fq)
            self.dns_auth[fq] = vis
            self.dns_pub[fq] = list(vis)
        return rid

    def cf_visible(self, fqdn):
        """A answers DNS gives for fqdn: record contents, or the edge IP when proxied."""
        return sorted({CF_EDGE_IP if r["proxied"] else r["content"] for r in self.cf_records.values()
                       if r["name"] == fqdn and r["type"] == "A"})

    def cf_named(self, name, rtype="A"):
        fq = self.fqdn(name)
        return sorted(r["content"] for r in self.cf_records.values() if r["name"] == fq and r["type"] == rtype)

    def create_port(self, ip=None, status="BUILD", notify=True):
        with self.lock:
            self.mac_seq += 1
            self.port_seq += 1
            pid = "port-%04d" % self.port_seq
            ip = ip or self.pool.pop(0)
            p = {"id": pid, "instance_id": self.server_id, "ips": [ip],
                 "mac_address": "fa:16:3e:00:00:%02x" % self.mac_seq, "network_id": "net-pub1",
                 "port_security_enabled": True, "security_group_ids": ["sg-aaa"], "status": status,
                 "_gets": 0}
            self.ports[pid] = p
        if notify and self.net:
            self.net.hotplug_add(p)
        return p

    def detach(self, pid):
        with self.lock:
            p = self.ports.pop(pid)
        if self.net:
            self.net.hotplug_remove(p)
        return p

    def public_ips(self):
        return sorted(ip for p in self.ports.values() for ip in p["ips"])

    def server_json(self):
        addrs = [{"addr": ip, "version": "4", "type": "fixed", "is_public": True,
                  "mac_addr": p["mac_address"]} for p in self.ports.values() for ip in p["ips"]]
        return {"id": self.server_id, "name": self.server_name, "status": "ACTIVE", "task_state": None,
                "addresses": {"public210": addrs},
                "security_groups": [{"id": "sg-aaa", "name": "web", "description": ""}]}

    def port_json(self, p):
        if p["status"] == "BUILD":
            p["_gets"] += 1
            if p["_gets"] > self.port_build_gets:
                p["status"] = "ACTIVE"
        return {k: v for k, v in p.items() if not k.startswith("_")}

    def network_json(self):
        return {"id": "net-pub1", "name": "public210", "subnets": [{
            "id": "sub-pub1", "cidr": self.cidr, "gateway_ip": self.gw, "enable_dhcp": True,
            "dns_nameservers": ["8.8.8.8"], "mtu": 1500, "servers": []}]}

    def set_auth(self, fqdn, ips):
        with self.lock:
            self.dns_auth[fqdn] = list(ips)
            self.pub_pending.append([fqdn, list(ips), self.public_lag])

    def pub_answer(self, fqdn):
        with self.lock:
            for item in list(self.pub_pending):
                if item[0] == fqdn:
                    if item[2] <= 0:
                        self.dns_pub[fqdn] = item[1]
                        self.pub_pending.remove(item)
                    else:
                        item[2] -= 1
            return list(self.dns_pub.get(fqdn, []))

    def reachable(self, ip, from_iran):
        if ip == "1.1.1.1":
            return not (from_iran and self.iran_probe_outage)
        if from_iran and self.iran_probe_outage:
            return False
        if not any(ip in p["ips"] for p in self.ports.values()):
            return False
        if self.server_down:
            return False
        if self.net and not self.net.answers(ip):
            return False
        if from_iran and ip in self.blocked:
            return False
        return True


IR_NODES = ["ir%d.node.check-host.net" % i for i in range(1, 8)]
CTL_NODES = {"de1.node.check-host.net": ["de", "Germany", "Frankfurt"],
             "nl1.node.check-host.net": ["nl", "Netherlands", "Amsterdam"],
             "fi1.node.check-host.net": ["fi", "Finland", "Helsinki"],
             "us1.node.check-host.net": ["us", "USA", "Los Angeles"]}


# ------------------------------------------------------------------------ HTTP mock
def make_handler(world):
    class H(http.server.BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, *a):
            pass

        def _send(self, code, obj, headers=None):
            body = json.dumps(obj).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("X-AR-Request-Id", "req-%06d" % random.randint(0, 999999))
            for k, v in (headers or {}).items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(body)

        def _drop(self):
            self.close_connection = True
            try:
                self.connection.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass

        def _body(self):
            n = int(self.headers.get("Content-Length") or 0)
            return json.loads(self.rfile.read(n) or b"null") if n else None

        def do_GET(self):
            self.route("GET")

        def do_POST(self):
            self.route("POST")

        def do_PATCH(self):
            self.route("PATCH")

        def do_PUT(self):
            self.route("PUT")

        def route(self, method):
            u = urllib.parse.urlsplit(self.path)
            path, q = u.path, urllib.parse.parse_qs(u.query)
            body = self._body() if method in ("POST", "PATCH", "PUT") else None
            with world.lock:
                world.calls.append((method, path))
            if path.startswith("/checkhost/"):
                return self.checkhost(path[len("/checkhost"):], q)
            if path.startswith("/cf/client/v4/"):
                return self.cf(method, path[len("/cf/client/v4"):], q, body)
            if self.headers.get("Authorization") != "Apikey " + API_KEY:
                return self._send(401, {"message": "Unauthenticated."})
            if path == "/v1/me":
                return self._send(200, {"identityType": "machine_user", "identity": "rotator-bot",
                                        "account": {"id": "acc-1", "name": "hudson", "country": "IR"}})
            if path.startswith("/cdn/4.0/domains/%s/dns-records" % ZONE):
                return self.cdn(method, path, q, body)
            pre = "/ecc/v1/regions/%s" % world.region
            if not path.startswith(pre):
                return self._send(404, {"message": "no route"})
            p = path[len(pre):]
            sid = world.server_id
            if method == "GET" and p == "/servers/%s" % sid:
                return self._send(200, {"data": world.server_json()})
            if method == "GET" and p == "/servers/%s/ports" % sid:
                return self._send(200, {"data": [world.port_json(x) for x in list(world.ports.values())]})
            if method == "GET" and p.startswith("/ports/"):
                x = world.ports.get(p.split("/")[2])
                return self._send(200, {"data": world.port_json(x)}) if x else self._send(404, {"message": "not found"})
            if method == "GET" and p == "/networks":
                return self._send(200, {"data": [world.network_json()]})
            if method == "GET" and p == "/networks/net-pub1":
                return self._send(200, {"data": world.network_json()})
            if method == "GET" and p.startswith("/networks/"):
                return self._send(404, {"message": "network not found"})
            if method == "GET" and p == "/quotas":
                return self._send(200, {"data": {"public_ip": {"used": len(world.ports), "limit": 15}}})
            if method == "POST" and p == "/servers/%s/add-public-ip" % sid:
                f = world.faults
                if f.get("add_forbidden"):
                    return self._send(403, {"message": "This action is unauthorized."})
                if f.get("add_quota"):
                    return self._send(420, {"message": "quota exceeded"})
                if (body or {}).get("type") != "ipv4" or not isinstance((body or {}).get("security_groups"), list):
                    return self._send(422, {"message": "invalid body"})
                port = world.create_port()
                if f.pop("add_lost_response", False):
                    return self._send(502, {"message": "Bad Gateway"})
                if f.pop("add_conn_drop", False):
                    return self._drop()
                return self._send(200, {"data": {"fixed_ips": [{"ip_address": port["ips"][0], "subnet_id": "sub-pub1"}],
                                                 "port_id": port["id"], "mac_addr": port["mac_address"]},
                                        "message": "Public IP added"})
            if method == "PATCH" and p.startswith("/networks/") and p.endswith("/detach"):
                pid = p.split("/")[2]
                if (body or {}).get("server_id") != sid:
                    return self._send(422, {"message": "server_id mismatch"})
                if pid in world.faults.get("detach_forbidden", ()):
                    return self._send(422, {"message": "The primary network interface cannot be detached."})
                if pid not in world.ports:
                    return self._send(404, {"message": "port not found"})
                world.detach(pid)
                if world.faults.pop("detach_conn_drop", False):
                    return self._drop()
                return self._send(200, {"message": "Server detached from network"})
            return self._send(404, {"message": "no route %s %s" % (method, p)})

        def cdn(self, method, path, q, body):
            rest = path[len("/cdn/4.0/domains/%s/dns-records" % ZONE):]
            if method == "GET" and rest in ("", "/"):
                if world.faults.get("dns_get_forbidden"):
                    return self._send(403, {"message": "This action is unauthorized."})
                search = (q.get("search") or [""])[0]
                recs = [dict(r, cloud=world.cdn_proxied) for r in world.records.values()
                        if not search or search in r["name"]]
                return self._send(200, {"data": recs, "meta": {"current_page": 1, "last_page": 1}})
            if method == "PUT" and rest.startswith("/"):
                rid = rest[1:]
                if world.faults.get("dns_put_forbidden"):
                    return self._send(403, {"message": "This action is unauthorized."})
                if rid not in world.records:
                    return self._send(404, {"message": "record not found"})
                rec = world.records[rid]
                rec.update({k: body[k] for k in ("ttl", "value", "cloud", "name") if k in body})
                world.set_auth(World.fqdn(rec["name"]), [v["ip"] for v in rec["value"]])
                return self._send(200, {"data": rec, "message": "updated"})
            return self._send(404, {"message": "no cdn route"})

        def _cf_send(self, code, result=None, errors=None, info=None):
            obj = {"success": not errors, "errors": errors or [], "messages": [], "result": result}
            if info is not None:
                obj["result_info"] = info
            self._send(code, obj, {"CF-RAY": "8f%014x-FRA" % random.getrandbits(56)})

        def cf(self, method, p, q, body):
            def err(http_code, code, msg):
                return self._cf_send(http_code, None, [{"code": code, "message": msg}])
            auth = self.headers.get("Authorization") or ""
            if not auth.startswith("Bearer "):
                return err(400, 6003, "Invalid request headers")
            if auth != "Bearer " + world.cf_token:
                return err(403, 10000, "Authentication error")
            f = world.faults
            if p == "/user/tokens/verify" and method == "GET":
                return self._cf_send(200, {"id": "tok-1", "status": "active"})
            if p == "/zones" and method == "GET":
                name = (q.get("name") or [""])[0]
                zs = [] if f.get("cf_zone_hidden") or name not in ("", ZONE) else [{
                    "id": world.cf_zone_id, "name": ZONE, "status": world.cf_zone_status,
                    "type": world.cf_zone_type, "name_servers": ["ada.ns.cloudflare.com", "bob.ns.cloudflare.com"]}]
                return self._cf_send(200, zs, info={"page": 1, "per_page": 50, "count": len(zs),
                                                    "total_count": len(zs), "total_pages": 1})
            pre = "/zones/%s/dns_records" % world.cf_zone_id
            if not p.startswith(pre):
                return err(400, 7003, "Could not route to %s, perhaps your object identifier is invalid?" % p)
            rest = p[len(pre):]
            if method == "GET" and rest in ("", "/"):
                if f.get("cf_list_forbidden"):
                    return err(403, 10000, "Authentication error")
                with world.lock:
                    recs = [dict(r) for r in world.cf_records.values()]
                t = (q.get("type") or [None])[0]
                n = (q.get("name.exact") or [None])[0]
                if t:
                    recs = [r for r in recs if r["type"] == t]
                if n:
                    recs = [r for r in recs if r["name"] == n.lower()]
                page = int((q.get("page") or ["1"])[0])
                per = min(int((q.get("per_page") or ["100"])[0]), world.cf_per_page_cap)
                pages = max(1, -(-len(recs) // per))
                chunk = recs[(page - 1) * per: page * per]
                return self._cf_send(200, chunk, info={"page": page, "per_page": per, "count": len(chunk),
                                                       "total_count": len(recs), "total_pages": pages})
            rid = rest.strip("/")
            with world.lock:
                rec = world.cf_records.get(rid)
            if method == "GET":
                return self._cf_send(200, dict(rec)) if rec else err(404, 81044, "Record does not exist.")
            if method == "PATCH":
                after = f.get("cf_patch_forbidden_after")
                if f.get("cf_patch_forbidden") or (after is not None and len(world.cf_patches) >= after):
                    return err(403, 10000, "Authentication error")
                if not rec:
                    return err(404, 81044, "Record does not exist.")
                b = body or {}
                if b.get("type") != rec["type"] or b.get("name") != rec["name"] or not isinstance(b.get("ttl"), int):
                    return err(400, 9000, "type, name and ttl are required")
                try:
                    ipaddress.IPv4Address(b.get("content"))
                except ValueError:
                    return err(400, 9005, "Content for A record must be a valid IPv4 address.")
                with world.lock:
                    world.cf_patches.append((rid, dict(b)))
                    rec.update({k: b[k] for k in ("content", "ttl", "proxied") if k in b})
                    if not f.get("cf_not_authoritative"):
                        world.set_auth(rec["name"], world.cf_visible(rec["name"]))
                if f.pop("cf_patch_drop", False):
                    return self._drop()
                return self._cf_send(200, dict(rec))
            return err(405, 10405, "Method not allowed")

        def checkhost(self, p, q):
            if p == "/nodes/hosts":
                nodes = {n: {"asn": "AS1", "ip": "10.0.0.%d" % i, "location": ["ir", "Iran", "Tehran"]}
                         for i, n in enumerate(IR_NODES)}
                nodes.update({n: {"asn": "AS2", "ip": "10.1.0.1", "location": loc} for n, loc in CTL_NODES.items()})
                return self._send(200, {"nodes": nodes})
            if p.startswith("/check-") and p[7:] in ("tcp", "ping", "http", "dns"):
                if world.limit_exceeded_remaining > 0:
                    world.limit_exceeded_remaining -= 1
                    return self._send(200, {"error": "limit_exceeded"})
                host = q["host"][0]
                alive = set(IR_NODES[: world.ir_alive]) | set(CTL_NODES)
                nodes = [n for n in q.get("node", []) if n in alive]
                rid = "%012x" % random.getrandbits(48)
                world.__dict__.setdefault("ch_requests", {})[rid] = (p[7:], host, nodes)
                return self._send(200, {"ok": 1, "request_id": rid,
                                        "permanent_link": "https://check-host.net/check-report/" + rid,
                                        "nodes": {n: ["xx", "X", "Y", "1.2.3.4", "AS1"] for n in nodes}})
            if p.startswith("/check-result/"):
                rid = p.split("/")[2]
                ctype, host, nodes = world.ch_requests[rid]
                ip = host.split(":")[0]
                out = {}
                for n in nodes:
                    if n in world.faults.get("pending_nodes", ()):
                        out[n] = None
                        continue
                    ok = world.reachable(ip, n.startswith("ir"))
                    if ctype == "tcp":
                        out[n] = [{"address": ip, "time": 0.04}] if ok else [{"error": "Connection timed out"}]
                    elif ctype == "ping":
                        out[n] = [[["OK", 0.04, ip]] * 4] if ok else [[["TIMEOUT", 3.0]] * 4]
                    else:
                        out[n] = [[1, 0.1, "OK", "200", ip]] if ok else [[0, 3.0, "Connection timed out", None, None]]
                return self._send(200, out)
            return self._send(404, {"error": "unknown"})
    return H


class ThreadingHTTP(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


# ------------------------------------------------------------------------- DNS mock
class DnsMock:
    def __init__(self, world, authoritative):
        self.world, self.auth = world, authoritative
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(("127.0.0.1", 0))
        self.port = self.sock.getsockname()[1]
        self.queries = 0
        threading.Thread(target=self.loop, daemon=True).start()

    def loop(self):
        while True:
            try:
                data, addr = self.sock.recvfrom(4096)
            except OSError:
                return
            try:
                self.sock.sendto(self.answer(data), addr)
            except Exception:
                pass

    def answer(self, q):
        self.queries += 1
        qid, qflags = struct.unpack(">HH", q[:4])
        off, labels = 12, []
        while q[off]:
            ln = q[off]
            labels.append(q[off + 1: off + 1 + ln].decode())
            off += 1 + ln
        off += 1
        qtype = struct.unpack(">H", q[off: off + 2])[0]
        question = q[12: off + 4]
        name = ".".join(labels).lower()
        ips = (self.world.dns_auth.get(name, []) if self.auth else self.world.pub_answer(name)) if qtype == 1 else []
        known = name in self.world.dns_auth
        rcode = 0 if known else 3
        flags = 0x8000 | (0x0400 if self.auth else 0) | (qflags & 0x0100) | 0x0080 | rcode
        hdr = struct.pack(">HHHHHH", qid, flags, 1, len(ips), 0, 0)
        ans = b"".join(struct.pack(">HHHIH", 0xC00C, 1, 1, self.world.ttl if self.auth else 60, 4)
                       + socket.inet_aton(ip) for ip in ips)
        return hdr + question + ans


# --------------------------------------------------------------- fake `ip` + host
class FakeIpError(Exception):
    pass


class FakeNet(rot.LinuxNet):
    def __init__(self, world, cfg, log, clock, state_dir, hotplug=True, dhcp_default=False):
        super().__init__(cfg, log, clock, state_dir)
        self.world = world
        world.net = self
        self.hotplug, self.dhcp_default = hotplug, dhcp_default
        self.links = {}
        self.routes = {"main": []}
        self.rules = []
        self.history = []
        self.watchdogs = []
        self.netplan = None
        self.egress_broken = set()
        self.on_default_change = None
        p = world.ports[world.primary_port]
        self.links["eth0"] = {"mac": p["mac_address"], "up": True, "addrs": [("185.10.20.10", 24)]}
        self.routes["main"].append({"dst": "default", "gateway": world.gw, "dev": "eth0", "metric": 100,
                                    "protocol": "dhcp", "prefsrc": "185.10.20.10"})

    # ---- world callbacks
    def hotplug_add(self, port):
        if not self.hotplug:
            return
        idx = 0
        while "eth%d" % idx in self.links:
            idx += 1
        name = "eth%d" % idx
        self.links[name] = {"mac": port["mac_address"], "up": False, "addrs": []}
        if self.dhcp_default:
            self.links[name]["up"] = True
            self.links[name]["addrs"].append((port["ips"][0], 24))
            self.routes["main"].append({"dst": "default", "gateway": self.world.gw, "dev": name,
                                        "metric": 50, "protocol": "dhcp", "prefsrc": port["ips"][0]})

    def hotplug_remove(self, port):
        for name, l in list(self.links.items()):
            if l["mac"] == port["mac_address"]:
                del self.links[name]
                for t in self.routes:
                    self.routes[t] = [r for r in self.routes[t] if r["dev"] != name]

    # ---- LinuxNet overrides
    def available(self):
        return True, "fake"

    def tune_sysctls(self, ifnames):
        self.history.append(("sysctl", tuple(ifnames)))

    def write_netplan(self, path, mac, ip, prefixlen, gw, dns):
        self.netplan = (path, mac, ip, prefixlen, gw, tuple(dns))

    def start_watchdog(self, revert, timeout, tag):
        wd = {"pid": -1, "claim": "c-" + tag, "marker": "m-" + tag, "revert": revert, "fired": False,
              "armed": True}
        self.watchdogs.append(wd)
        return {"pid": -1, "claim": wd["claim"], "marker": wd["marker"], "idx": len(self.watchdogs) - 1}

    def fire_watchdog(self):
        for wd in self.watchdogs:
            if wd["armed"]:
                for c in wd["revert"]:
                    try:
                        self._exec(c)
                    except FakeIpError:
                        pass
                wd["fired"], wd["armed"] = True, False

    def confirm_watchdog(self, wd):
        if not wd:
            return True
        w = self.watchdogs[wd["idx"]]
        w["armed"] = False
        return not w["fired"]

    def egress_ip(self, source_ip=None):
        r = self.lookup("1.1.1.1", source_ip)
        if not r:
            return None
        src = source_ip or r["prefsrc"]
        if not any(a[0] == src for a in self.links.get(r["dev"], {}).get("addrs", [])):
            return None
        port = next((p for p in self.world.ports.values() if p["mac_address"] == self.links[r["dev"]]["mac"]), None)
        if not port or src not in port["ips"] or src in self.egress_broken:
            return None
        return src

    def answers(self, ip):
        owner = next((n for n, l in self.links.items() if l["up"] and any(a[0] == ip for a in l["addrs"])), None)
        if not owner:
            return False
        r = self.lookup("203.0.113.9", ip)
        return bool(r) and r["dev"] == owner

    def _run(self, args, check=True):
        try:
            out = self._exec(list(args))
            self.history.append(("ip", tuple(args)))
            return out
        except FakeIpError as exc:
            if check:
                raise rot.RotatorError("ip %s failed: %s" % (" ".join(args), exc))
            return ""

    # ---- routing model
    def connected(self):
        out = []
        for n, l in self.links.items():
            if l["up"]:
                for ip, plen in l["addrs"]:
                    out.append({"dst": str(ipaddress.ip_interface("%s/%d" % (ip, plen)).network), "dev": n,
                                "prefsrc": ip, "metric": 0, "scope": "link", "gateway": None})
        return out

    def _best(self, table, dst):
        cands = list(self.routes.get(table, []))
        if table == "main":
            cands += self.connected()
        d = ipaddress.ip_address(dst)
        best = None
        for r in cands:
            net = ipaddress.ip_network("0.0.0.0/0" if r["dst"] == "default" else r["dst"])
            if d in net and r["dev"] in self.links and self.links[r["dev"]]["up"]:
                key = (net.prefixlen, -int(r.get("metric") or 0))
                if best is None or key > best[0]:
                    best = (key, r)
        return best[1] if best else None

    def lookup(self, dst, src=None):
        chain = sorted(self.rules, key=lambda x: x["priority"]) + [{"priority": 32766, "src": "all", "table": "main"}]
        for rule in chain:
            if rule["src"] != "all" and rule["src"] != src:
                continue
            r = self._best(rule["table"], dst)
            if r:
                dev = r["dev"]
                pref = r.get("prefsrc") or src or (self.links[dev]["addrs"][0][0] if self.links[dev]["addrs"] else None)
                return {"dst": dst, "gateway": r.get("gateway"), "dev": dev, "prefsrc": pref}
        return None

    def _opts(self, a):
        o, i = {}, 0
        while i < len(a):
            k = a[i]
            if k in ("via", "dev", "src", "metric", "table", "proto", "lookup", "priority", "from"):
                o[k] = a[i + 1]
                i += 2
            else:
                o.setdefault("_pos", []).append(k)
                i += 1
        return o

    def _exec(self, a):
        if a[:1] == ["-j"]:
            a = a[1:]
            if a == ["link", "show"]:
                return json.dumps([{"ifname": n, "address": l["mac"], "operstate": "UP" if l["up"] else "DOWN"}
                                   for n, l in self.links.items()])
            if a == ["addr", "show"]:
                return json.dumps([{"ifname": n, "address": l["mac"], "addr_info": [
                    {"family": "inet", "local": ip, "prefixlen": pl} for ip, pl in l["addrs"]]}
                    for n, l in self.links.items()])
            if a[:3] == ["route", "show", "default"]:
                out = []
                for r in self.routes["main"]:
                    if r["dst"] == "default":
                        x = {"dst": "default", "gateway": r.get("gateway"), "dev": r["dev"],
                             "protocol": r.get("protocol") or "boot", "flags": []}
                        if r.get("metric"):
                            x["metric"] = int(r["metric"])
                        if r.get("prefsrc"):
                            x["prefsrc"] = r["prefsrc"]
                        out.append(x)
                return json.dumps(out)
            if a[:2] == ["route", "get"]:
                r = self.lookup(a[2])
                return json.dumps([r] if r else [])
            if a == ["rule", "show"]:
                rules = [{"priority": 0, "src": "all", "table": "local"}]
                rules += [{"priority": r["priority"], "src": r["src"], "srclen": 32, "table": str(r["table"])}
                          for r in sorted(self.rules, key=lambda x: x["priority"])]
                rules += [{"priority": 32766, "src": "all", "table": "main"},
                          {"priority": 32767, "src": "all", "table": "default"}]
                return json.dumps(rules)
            raise FakeIpError("unsupported -j %s" % a)
        if a[:3] == ["link", "set", "dev"]:
            if a[3] not in self.links:
                raise FakeIpError("Cannot find device")
            self.links[a[3]]["up"] = a[4] == "up"
            return ""
        if a[:2] == ["addr", "add"]:
            ip, pl = a[2].split("/")
            dev = a[4]
            if dev not in self.links:
                raise FakeIpError("Cannot find device")
            if any(x[0] == ip for x in self.links[dev]["addrs"]):
                raise FakeIpError("File exists")
            self.links[dev]["addrs"].append((ip, int(pl)))
            return ""
        if a[:2] == ["addr", "del"]:
            ip = a[2].split("/")[0]
            dev = a[4]
            if dev in self.links:
                self.links[dev]["addrs"] = [x for x in self.links[dev]["addrs"] if x[0] != ip]
            return ""
        if a[:2] == ["route", "replace"]:
            dst = a[2]
            o = self._opts(a[3:])
            t = o.get("table", "main")
            t = t if t == "main" else int(t)
            if o["dev"] not in self.links:
                raise FakeIpError("Cannot find device")
            if o.get("via"):
                devnets = [ipaddress.ip_interface("%s/%d" % x).network for x in self.links[o["dev"]]["addrs"]]
                if not any(ipaddress.ip_address(o["via"]) in n for n in devnets):
                    raise FakeIpError("Nexthop has invalid gateway")
            new = {"dst": dst, "gateway": o.get("via"), "dev": o["dev"], "metric": int(o.get("metric", 0)),
                   "prefsrc": o.get("src"), "protocol": o.get("proto", "boot")}
            tbl = self.routes.setdefault(t, [])
            for i, r in enumerate(tbl):
                if r["dst"] == dst and int(r.get("metric") or 0) == new["metric"]:
                    tbl[i] = new
                    break
            else:
                tbl.append(new)
            if t == "main" and dst == "default" and self.on_default_change:
                self.on_default_change(self)
            return ""
        if a[:3] == ["route", "del", "default"]:
            o = self._opts(a[3:])
            tbl = self.routes["main"]
            for r in tbl:
                if r["dst"] != "default":
                    continue
                if o.get("via") and r.get("gateway") != o["via"]:
                    continue
                if o.get("dev") and r["dev"] != o["dev"]:
                    continue
                if "metric" in o and int(r.get("metric") or 0) != int(o["metric"]):
                    continue
                tbl.remove(r)
                return ""
            raise FakeIpError("No such process")
        if a[:3] == ["route", "flush", "table"]:
            self.routes[int(a[3])] = []
            return ""
        if a[:2] == ["rule", "add"]:
            o = self._opts(a[2:])
            self.rules.append({"priority": int(o["priority"]), "src": o["from"].split("/")[0], "table": int(o["lookup"])})
            return ""
        if a[:2] == ["rule", "del"]:
            o = self._opts(a[2:])
            src = o["from"].split("/")[0]
            for r in self.rules:
                if r["src"] == src and ("lookup" not in o or str(r["table"]) == str(o["lookup"])):
                    self.rules.remove(r)
                    return ""
            raise FakeIpError("No such file or directory")
        raise FakeIpError("unsupported: %s" % a)

    def default_dev(self):
        r = self.lookup("1.1.1.1")
        return r["dev"] if r else None


# ------------------------------------------------------------------------- env
class Env:
    def __init__(self, **cfg_over):
        self.world = World()
        self.httpd = ThreadingHTTP(("127.0.0.1", 0), make_handler(self.world))
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()
        self.base = "http://127.0.0.1:%d" % self.httpd.server_address[1]
        self.dns_auth = DnsMock(self.world, True)
        self.dns_pub = DnsMock(self.world, False)
        self.tmp = tempfile.mkdtemp(prefix="rot-test-")
        os.environ["ARVAN_API_KEY"] = API_KEY
        os.environ["CLOUDFLARE_API_TOKEN"] = CF_TOKEN
        self.cfg = rot.load_config()
        self.cfg.update({
            "ARVAN_API_BASE": self.base + "/ecc/v1", "CDN_API_BASE": self.base + "/cdn/4.0",
            "CLOUDFLARE_API_BASE": self.base + "/cf/client/v4",
            "IDENTITY_URL": self.base + "/v1/me", "CHECKHOST_BASE": self.base + "/checkhost",
            "REGION": "ir-thr-ba1", "SERVER_ID": self.world.server_id,
            "STATE_DIR": self.tmp + "/state", "LOG_DIR": self.tmp + "/log", "LOG_STDOUT": False,
            "LOG_LEVEL": "debug",
            "DNS_AUTHORITATIVE_NS": ["127.0.0.1:%d" % self.dns_auth.port],
            "DNS_PUBLIC_RESOLVERS": ["127.0.0.1:%d" % self.dns_pub.port],
            "DNS_NAMES": ["@", "www"], "DNS_UPDATE_MODE": "arvan_api",
            "HTTP_RETRY_BACKOFF_SEC": 0.01, "HTTP_TIMEOUT_SEC": 5,
        })
        self.cfg.update(cfg_over)
        self.clock = FakeClock()
        self.net = None
        self.alerts = []

    def build(self, dry_run=False, hotplug=True, dhcp_default=False, fresh_net=False):
        log = rot.EventLog(self.cfg)
        if self.net is None or fresh_net:
            self.net = FakeNet(self.world, self.cfg, log, self.clock, self.cfg["STATE_DIR"],
                               hotplug=hotplug, dhcp_default=dhcp_default)
        if dry_run:
            self.net.read_only = True
        else:
            self.net.read_only = False
        r = rot.build(self.cfg, dry_run=dry_run, clock=self.clock, net=self.net,
                      dns_client=rot.DnsClient(timeout=1.0, retries=1))
        orig = r.alerter.send

        def capture(level, title, details=None, force=False):
            self.alerts.append((level, title))
            return orig(level, title, details, force)
        r.alerter.send = capture
        return r

    def mutations(self):
        return [c for c in self.world.calls if c[0] in ("POST", "PATCH", "PUT")]

    def close(self):
        self.httpd.shutdown()
        self.httpd.server_close()
