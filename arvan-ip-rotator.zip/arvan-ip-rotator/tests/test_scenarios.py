"""Fault-injection scenarios for arvan_ip_rotator.py (run: python3 tests/test_scenarios.py)."""
import contextlib
import io
import json
import os
import sys
import traceback

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from harness import Env, rot, ZONE, API_KEY, CF_TOKEN, CF_EDGE_IP  # noqa: E402

OLD = "185.10.20.10"
NEW1 = "185.10.20.50"
NEW2 = "185.10.20.51"
RESULTS = []
SCENARIOS = []   # filled by @scenario, in definition order


class Crash(BaseException):
    """Simulates the process dying at an exact point."""


def scenario(fn):
    def run():
        env = None
        try:
            env = Env()
            fn(env)
            RESULTS.append((fn.__name__, "PASS", ""))
        except Exception as exc:  # noqa: BLE001
            RESULTS.append((fn.__name__, "FAIL", "%s\n%s" % (exc, traceback.format_exc())))
        finally:
            if env:
                env.close()
    run.__name__ = fn.__name__
    SCENARIOS.append(run)
    return run


def posts(env, frag):
    return [c for c in env.mutations() if frag in c[1]]


def assert_completed(env, r, new_ip=NEW1):
    st = r.state
    assert st["rotation"] is None, "rotation still active: %s" % (st["rotation"] or {}).get("phase")
    assert st["halt"] is None, "halted: %s" % st["halt"]
    assert st["current"]["ip"] == new_ip, st["current"]
    assert OLD not in env.world.public_ips(), "old IP still attached"
    assert env.world.dns_auth[ZONE] == [new_ip] and env.world.dns_auth["www." + ZONE] == [new_ip], env.world.dns_auth
    assert env.net.lookup("1.1.1.1")["prefsrc"] == new_ip, env.net.lookup("1.1.1.1")
    assert not any(x["src"] == OLD for x in env.net.rules), env.net.rules
    assert st["history"][-1]["result"] == "completed"


# ---------------------------------------------------------------- happy paths
@scenario
def happy_path_daemon_arvan_api(env):
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=1)
    assert r.state["detector"]["consecutive_bad"] == 1 and r.state["rotation"] is None
    r.run_forever(max_loops=1)
    assert_completed(env, r)
    assert len(posts(env, "add-public-ip")) == 1
    assert len(posts(env, "/detach")) == 1
    assert len(posts(env, "dns-records")) == 2
    ev = [json.loads(l) for l in open(env.cfg["LOG_DIR"] + "/events.jsonl")]
    phases = [e["phase"] for e in ev if e["event"] == "phase"]
    assert phases == ["ALLOCATED", "OS_CONFIGURED", "VERIFIED", "SWITCHING", "SWITCHED", "DNS_UPDATED",
                      "DNS_VERIFIED", "DRAINING", "RELEASING", "DONE"], phases
    assert all(not w["armed"] and not w["fired"] for w in env.net.watchdogs)
    assert any("Rotation complete" in t for _, t in env.alerts)
    r.run_forever(max_loops=1)                     # next cycle checks the NEW ip
    assert r.state["detector"]["last_verdict"] == "REACHABLE"


@scenario
def drain_waits_for_ttl(env):
    env.world.blocked.add(OLD)
    r = env.build()
    marks = {}
    orig_set = r._set_phase

    def spy(rot_, phase):
        marks[phase] = env.clock.time()
        return orig_set(rot_, phase)
    r._set_phase = spy
    r.run_forever(max_loops=2)
    assert_completed(env, r)
    assert marks["RELEASING"] - marks["DNS_VERIFIED"] >= 120 + 300 - 25, marks


@scenario
def verify_only_operator_updates_dns(env):
    env.cfg["DNS_UPDATE_MODE"] = "verify_only"
    env.world.blocked.add(OLD)
    r = env.build()
    orig = r.alerter.send

    def on_alert(level, title, details=None, force=False):
        if title.startswith("ACTION: point"):
            for n in (ZONE, "www." + ZONE):
                env.world.set_auth(n, [NEW1])
        return orig(level, title, details, force)
    r.alerter.send = on_alert
    r.run_forever(max_loops=2)
    assert_completed(env, r)
    assert len(posts(env, "dns-records")) == 0


# ------------------------------------------------------------ DNS failure paths
@scenario
def verify_only_dns_never_updated_halts_then_recovers(env):
    env.cfg["DNS_UPDATE_MODE"] = "verify_only"
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=2)
    h = r.state["halt"]
    assert h and "DNS verification FAILED" in h["reason"] and "will NOT be released" in h["reason"], h
    assert r.state["rotation"]["phase"] == "DNS_UPDATED"
    assert OLD in env.world.public_ips() and NEW1 in env.world.public_ips()
    assert not posts(env, "/detach")
    assert env.world.reachable(OLD, from_iran=False), "old IP must keep working during drain/halt"
    # operator fixes DNS, acknowledges, resumes
    for n in (ZONE, "www." + ZONE):
        env.world.set_auth(n, [NEW1])
    assert r.ack() == "acknowledged"
    assert r.resume() == "done"
    assert_completed(env, r)


@scenario
def dns_precheck_refuses_proxied_record(env):
    env.world.cdn_proxied = True
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=2)
    assert not posts(env, "add-public-ip"), "must not allocate when DNS step cannot succeed"
    assert any("proxied" in t for _, t in env.alerts), env.alerts


@scenario
def dns_put_forbidden_halts_and_discard_reverts(env):
    env.world.faults["dns_put_forbidden"] = True
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=2)
    h = r.state["halt"]
    assert h and "403" in h["reason"] and r.state["rotation"]["phase"] == "SWITCHED", h
    assert env.net.lookup("1.1.1.1")["dev"] != "eth0"            # switched
    r.ack()
    assert r.discard_pending() == "discarded"
    assert env.net.lookup("1.1.1.1")["dev"] == "eth0", "egress must be reverted"
    assert env.world.public_ips() == [OLD]
    assert env.world.dns_auth[ZONE] == [OLD]


# ------------------------------------------------------------ new-IP problems
@scenario
def new_ip_also_blocked_halts_then_discard(env):
    env.world.blocked |= {OLD, NEW1}
    r = env.build()
    r.run_forever(max_loops=2)
    h = r.state["halt"]
    assert h and "ALSO unreachable from Iran" in h["reason"], h
    assert r.state["rotation"]["phase"] == "OS_CONFIGURED"
    assert env.net.lookup("1.1.1.1")["dev"] == "eth0", "must not switch"
    assert sorted(env.world.public_ips()) == [OLD, NEW1]
    r.ack()
    assert r.discard_pending() == "discarded"
    assert env.world.public_ips() == [OLD]
    assert not any(x["src"] == NEW1 for x in env.net.rules)
    ok, why = r.limits()
    assert not ok and "backoff" in why, why


@scenario
def auto_discard_failed_new_ip(env):
    env.cfg["AUTO_DISCARD_FAILED_NEW_IP"] = True
    env.world.blocked |= {OLD, NEW1}
    r = env.build()
    r.run_forever(max_loops=2)
    assert r.state["halt"] is None and r.state["rotation"] is None
    assert env.world.public_ips() == [OLD]
    assert r.state["history"][-1]["result"] == "discarded"


@scenario
def new_ip_cannot_egress_halts_before_switch(env):
    env.world.blocked.add(OLD)
    r = env.build()
    env.net.egress_broken.add(NEW1)
    r.run_forever(max_loops=2)
    h = r.state["halt"]
    assert h and "egress probe bound to new IP" in h["reason"], h
    assert r.state["rotation"]["phase"] == "ALLOCATED"
    assert env.net.lookup("1.1.1.1")["dev"] == "eth0"


@scenario
def nic_never_appears_halts(env):
    env.world.blocked.add(OLD)
    r = env.build(hotplug=False, fresh_net=True)
    r.run_forever(max_loops=2)
    h = r.state["halt"]
    assert h and "no NIC with MAC" in h["reason"], h
    r.ack()
    r.discard_pending()
    assert env.world.public_ips() == [OLD]


@scenario
def dhcp_hotplug_default_route_is_neutralised(env):
    r = env.build(dhcp_default=True, fresh_net=True)
    r.bootstrap()
    assert r.start_rotation("trial", "test", ignore_limits=True) == "paused"
    assert env.net.lookup("1.1.1.1")["dev"] == "eth0", env.net.routes["main"]


# ---------------------------------------------------- allocation ambiguity/crash
@scenario
def lost_add_response_reconciles(env):
    env.world.faults["add_lost_response"] = True
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=2)
    assert_completed(env, r)
    assert len(posts(env, "add-public-ip")) == 1, "must NOT re-send add-public-ip"


@scenario
def dropped_connection_on_add_reconciles(env):
    env.world.faults["add_conn_drop"] = True
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=2)
    assert_completed(env, r)
    assert len(posts(env, "add-public-ip")) == 1


@scenario
def crash_before_add_request_then_restart(env):
    env.world.blocked.add(OLD)
    r = env.build()

    def boom(*a, **k):
        raise Crash()
    r.api.add_public_ip = boom
    try:
        r.run_forever(max_loops=2)
        raise AssertionError("expected crash")
    except Crash:
        pass
    st = json.load(open(env.cfg["STATE_DIR"] + "/state.json"))
    assert st["rotation"]["phase"] == "PRE_ALLOCATE" and st["rotation"]["add_attempts"] == 1
    r2 = env.build()                               # "restart"
    r2.run_forever(max_loops=1)
    assert_completed(env, r2)
    assert len(posts(env, "add-public-ip")) == 1


@scenario
def crash_after_add_request_then_restart(env):
    env.world.blocked.add(OLD)
    r = env.build()
    real = r.api.add_public_ip

    def add_then_die(*a, **k):
        real(*a, **k)
        raise Crash()
    r.api.add_public_ip = add_then_die
    try:
        r.run_forever(max_loops=2)
    except Crash:
        pass
    r2 = env.build()
    r2.run_forever(max_loops=1)
    assert_completed(env, r2)
    assert len(posts(env, "add-public-ip")) == 1, "reconcile must adopt, not re-add"
    assert len(env.world.public_ips()) == 1


@scenario
def add_forbidden_halts_cleanly(env):
    env.world.faults["add_forbidden"] = True
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=2)
    h = r.state["halt"]
    assert h and "add-public-ip refused" in h["reason"] and "403" in h["reason"], h
    assert env.world.public_ips() == [OLD]
    r.ack()
    assert r.discard_pending() == "discarded"


# ---------------------------------------------------------------- switch path
@scenario
def switch_breaks_egress_reverts_and_halts(env):
    env.world.blocked.add(OLD)
    r = env.build()

    def on_change(net):
        if net.lookup("1.1.1.1")["dev"] != "eth0":
            net.egress_broken.add(NEW1)
    env.net.on_default_change = on_change
    r.run_forever(max_loops=2)
    h = r.state["halt"]
    assert h and "switch verification failed" in h["reason"], h
    assert r.state["rotation"]["phase"] == "SWITCHING"
    assert env.net.lookup("1.1.1.1")["dev"] == "eth0", "route must be reverted"
    assert [x for x in env.net.routes["main"] if x["dst"] == "default"] == [
        {"dst": "default", "gateway": "185.10.20.1", "dev": "eth0", "metric": 100, "prefsrc": OLD,
         "protocol": "dhcp"}], env.net.routes["main"]
    assert OLD in env.world.public_ips()
    assert all(not w["armed"] for w in env.net.watchdogs)


@scenario
def watchdog_fired_before_confirm_retries(env):
    env.world.blocked.add(OLD)
    r = env.build()
    real_confirm = env.net.confirm_watchdog
    state = {"n": 0}

    def flaky_confirm(wd):
        state["n"] += 1
        if state["n"] == 1 and wd:
            env.net.fire_watchdog()
        return real_confirm(wd)
    env.net.confirm_watchdog = flaky_confirm
    r.run_forever(max_loops=4)
    assert_completed(env, r)
    assert sum(1 for w in env.net.watchdogs if w["fired"]) == 1


# ---------------------------------------------------------------- release path
@scenario
def crash_during_release_then_restart(env):
    env.world.blocked.add(OLD)
    r = env.build()
    real = r.api.detach_port

    def detach_then_die(pid):
        real(pid)
        raise Crash()
    r.api.detach_port = detach_then_die
    try:
        r.run_forever(max_loops=2)
    except Crash:
        pass
    st = json.load(open(env.cfg["STATE_DIR"] + "/state.json"))
    assert st["rotation"]["phase"] == "RELEASING"
    r2 = env.build()
    r2.run_forever(max_loops=1)
    assert_completed(env, r2)
    assert len(posts(env, "/detach")) == 1


@scenario
def release_refused_halts_with_new_ip_active(env):
    env.world.faults["detach_forbidden"] = {env.world.primary_port}
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=2)
    h = r.state["halt"]
    assert h and "refused to release old IP" in h["reason"], h
    assert r.state["rotation"]["phase"] == "RELEASING"
    assert env.net.lookup("1.1.1.1")["prefsrc"] == NEW1 and env.world.dns_auth[ZONE] == [NEW1]
    try:
        r.discard_pending()
        raise AssertionError("discard must be refused once release started")
    except rot.RotationRefused:
        pass


@scenario
def ambiguous_detach_verified_by_polling(env):
    env.world.faults["detach_conn_drop"] = True
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=2)
    assert_completed(env, r)


@scenario
def old_ip_vanishes_mid_rotation_halts(env):
    env.world.blocked.add(OLD)
    r = env.build()
    real = r._do_os_config

    def sabotage(rot_):
        if env.world.primary_port in env.world.ports:
            env.world.detach(env.world.primary_port)
        return real(rot_)
    r._do_os_config = sabotage
    r._handlers = lambda: dict(rot.Rotator._handlers(r), ALLOCATED=sabotage)
    r.run_forever(max_loops=2)
    h = r.state["halt"]
    assert h and "OLD IP" in h["reason"] and "vanished" in h["reason"], h


# ------------------------------------------------------------- detection logic
@scenario
def consecutive_threshold_respected(env):
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=1)
    env.world.blocked.clear()
    r.run_forever(max_loops=1)
    assert r.state["detector"]["consecutive_bad"] == 0
    env.world.blocked.add(OLD)
    r.run_forever(max_loops=1)
    assert not posts(env, "add-public-ip")


@scenario
def inconclusive_rate_limit_never_rotates(env):
    env.world.limit_exceeded_remaining = 10_000
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=8)
    assert not posts(env, "add-public-ip")
    d = r.state["detector"]
    assert d["consecutive_bad"] == 0 and d["inconclusive_streak"] == 8, d
    assert any("inconclusive" in t for _, t in env.alerts)


@scenario
def too_few_iranian_nodes_inconclusive(env):
    env.world.ir_alive = 2
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=3)
    assert not posts(env, "add-public-ip")
    assert r.state["detector"]["last_verdict"] == "INCONCLUSIVE"


@scenario
def pending_results_count_as_unknown(env):
    env.world.faults["pending_nodes"] = set("ir%d.node.check-host.net" % i for i in range(1, 6))
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=3)
    assert not posts(env, "add-public-ip")
    assert r.state["detector"]["last_verdict"] == "INCONCLUSIVE"


@scenario
def server_down_globally_no_rotation(env):
    env.world.server_down = True
    r = env.build()
    r.run_forever(max_loops=3)
    assert not posts(env, "add-public-ip")
    assert r.state["detector"]["last_verdict"] == "DOWN"
    assert any("outside Iran too" in t for _, t in env.alerts)


@scenario
def iran_probe_outage_is_inconclusive(env):
    env.world.iran_probe_outage = True
    r = env.build()
    r.run_forever(max_loops=3)
    assert not posts(env, "add-public-ip")
    assert r.state["detector"]["last_verdict"] == "INCONCLUSIVE"


# ---------------------------------------------------------- limits/cooldown
@scenario
def cooldown_and_daily_cap(env):
    env.cfg["MAX_CHANGES_PER_DAY"] = 1
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=2)
    assert_completed(env, r)
    env.world.blocked.add(NEW1)
    r.run_forever(max_loops=3)
    assert len(posts(env, "add-public-ip")) == 1
    assert any("cooldown" in t for _, t in env.alerts), env.alerts
    env.clock.t += 3700
    r.run_forever(max_loops=3)
    assert len(posts(env, "add-public-ip")) == 1
    assert any("daily cap" in t for _, t in env.alerts), env.alerts


@scenario
def second_rotation_after_cooldown(env):
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=2)
    assert_completed(env, r)
    env.world.blocked.add(NEW1)
    env.clock.t += 3700
    r.run_forever(max_loops=2)
    st = r.state
    assert st["current"]["ip"] == NEW2 and env.world.public_ips() == [NEW2], (st["current"], env.world.public_ips())
    assert env.net.lookup("1.1.1.1")["prefsrc"] == NEW2
    assert not any(x["src"] == NEW1 for x in env.net.rules)
    assert len(posts(env, "add-public-ip")) == 2


@scenario
def per_server_ip_cap_refuses(env):
    env.cfg["MAX_PUBLIC_IPS_PER_SERVER"] = 2
    env.cfg["ADOPT_CURRENT_IP"] = OLD
    env.world.create_port(ip="185.10.20.99", status="ACTIVE")
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=2)
    assert not posts(env, "add-public-ip")
    assert any("MAX_PUBLIC_IPS_PER_SERVER" in t for _, t in env.alerts), env.alerts


# ------------------------------------------------------------- adoption/state
@scenario
def ambiguous_adoption_halts_and_untracked_untouched(env):
    env.world.create_port(ip="185.10.20.99", status="ACTIVE")
    r = env.build()
    r.run_forever(max_loops=1)
    assert r.state["halt"] and "ADOPT_CURRENT_IP" in r.state["halt"]["reason"]
    env2_cfg = dict(env.cfg, ADOPT_CURRENT_IP=OLD)
    env.cfg.update(env2_cfg)
    r = env.build()
    r.ack()
    env.world.blocked.add(OLD)
    r.run_forever(max_loops=2)
    assert r.state["current"]["ip"] == NEW1
    assert "185.10.20.99" in env.world.public_ips(), "untracked IP must never be touched"
    assert r.state["untracked_public_ips"] == ["185.10.20.99"]


@scenario
def corrupt_state_refuses_to_reset(env):
    os.makedirs(env.cfg["STATE_DIR"], exist_ok=True)
    for f in ("state.json", "state.json.bak"):
        open(os.path.join(env.cfg["STATE_DIR"], f), "w").write("{not json")
    try:
        env.build()
        raise AssertionError("expected HaltError")
    except rot.HaltError as exc:
        assert "Refusing to reset" in str(exc)


@scenario
def corrupt_state_recovers_from_backup(env):
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=1)
    open(os.path.join(env.cfg["STATE_DIR"], "state.json"), "w").write("{torn write")
    r2 = env.build()
    assert r2.state["current"]["ip"] == OLD


@scenario
def wrong_server_state_refuses(env):
    r = env.build()
    r.run_forever(max_loops=1)
    env.cfg["SERVER_ID"] = "srv-other"
    r2 = env.build()
    try:
        r2.bootstrap()
        raise AssertionError("expected HaltError")
    except rot.HaltError as exc:
        assert "belongs to server" in str(exc)


@scenario
def lock_prevents_second_instance(env):
    r1 = env.build()
    r1.store.acquire_lock()
    r2 = env.build()
    try:
        r2.store.acquire_lock()
        raise AssertionError("expected lock error")
    except rot.RotatorError as exc:
        assert "holds" in str(exc)
    finally:
        r1.store.release_lock()


@scenario
def bad_api_key_halts(env):
    os.environ["ARVAN_API_KEY"] = "11111111-2222-3333-4444-555555555555"
    try:
        r = env.build()
        r.run_forever(max_loops=1)
        assert r.state["halt"] and "unauthenticated" in r.state["halt"]["reason"], r.state["halt"]
    finally:
        os.environ["ARVAN_API_KEY"] = API_KEY


# ------------------------------------------------------- dry-run / trial / misc
@scenario
def dry_run_makes_zero_changes(env):
    env.world.blocked.add(OLD)
    r = env.build(dry_run=True)
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = r.dry_run_report()
    out = buf.getvalue()
    assert rc == 0, out
    assert env.mutations() == [], env.mutations()
    assert not os.path.exists(os.path.join(env.cfg["STATE_DIR"], "state.json"))
    assert all(h[0] == "ip" and h[1][0] == "-j" for h in env.net.history), env.net.history
    for needle in ("STEP 1", "STEP 2", "add-public-ip", "STEP 3", "BLOCKED", "STEP 4", "STEP 5",
                   "would PUT", "STEP 7", "/detach", "mutating HTTP requests made during this dry run: 0"):
        assert needle in out, (needle, out)
    try:
        r.api.add_public_ip([])
        raise AssertionError("read-only http must refuse")
    except rot.RotatorError as exc:
        assert "SAFETY" in str(exc)


@scenario
def trial_stops_then_resume(env):
    r = env.build()
    r.bootstrap()
    assert r.start_rotation("trial", "test", ignore_limits=True) == "paused"
    assert r.state["rotation"]["phase"] == "VERIFIED" and r.state["rotation"]["paused"] == "trial"
    assert env.net.lookup("1.1.1.1")["dev"] == "eth0" and env.world.dns_auth[ZONE] == [OLD]
    assert any(x["src"] == NEW1 for x in env.net.rules)
    r.run_forever(max_loops=2)                     # daemon must NOT continue a paused trial
    assert r.state["rotation"]["paused"] == "trial"
    assert r.resume() == "done"
    assert_completed(env, r)


@scenario
def trial_then_discard(env):
    r = env.build()
    r.bootstrap()
    r.start_rotation("trial", "test", ignore_limits=True)
    assert r.discard_pending() == "discarded"
    assert env.world.public_ips() == [OLD]
    assert env.net.lookup("1.1.1.1")["dev"] == "eth0"
    assert env.world.dns_auth[ZONE] == [OLD]
    assert not posts(env, "dns-records")


@scenario
def preflight_with_mocks(env):
    r = env.build()
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = r.preflight(probe_writes=True)
    out = buf.getvalue()
    assert rc == 0, out
    assert "INCONCLUSIVE" in out and "rotate --trial --yes" in out, out
    os.environ["ARVAN_API_KEY"] = "bad"
    try:
        r2 = env.build()
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc2 = r2.preflight()
        assert rc2 == 1 and "unauthenticated" in buf.getvalue()
    finally:
        os.environ["ARVAN_API_KEY"] = API_KEY


@scenario
def status_text_smoke(env):
    env.world.blocked |= {OLD, NEW1}
    r = env.build()
    r.run_forever(max_loops=2)
    txt = r.status_text()
    assert "HALTED" in txt and "discard-pending --yes" in txt and NEW1 in txt, txt


@scenario
def classify_formats(env):
    c = rot.classify_node_result
    assert c("tcp", [{"address": "1.2.3.4", "time": 0.1}])[0] == "ok"
    assert c("tcp", [{"error": "Connection timed out"}])[0] == "fail"
    assert c("tcp", None)[0] == "unknown"
    assert c("ping", [[["OK", 0.1, "1.2.3.4"], ["TIMEOUT", 3.0]]])[0] == "ok"
    assert c("ping", [[["TIMEOUT", 3.0], ["TIMEOUT", 3.0]]])[0] == "fail"
    assert c("ping", [[None]])[0] == "unknown"
    assert c("http", [[0, 0.3, "Not Found", "404", "1.2.3.4"]])[0] == "ok"
    assert c("http", [[0, 3.0, "Connection timed out", None, None]])[0] == "fail"


@scenario
def ping_check_type_end_to_end(env):
    env.cfg["CHECK_TYPE"] = "ping"
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=2)
    assert_completed(env, r)


@scenario
def secrets_never_logged(env):
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=2)
    blob = ""
    for root, _d, files in os.walk(env.tmp):
        for f in files:
            blob += open(os.path.join(root, f), errors="replace").read()
    assert API_KEY not in blob, "API key leaked into logs/state"



def _add_record(env, name, ip):
    w = env.world
    rid = "rec-%s" % name
    w.records[rid] = dict(w.records["rec-www"], id=rid, name=name,
                          value=[{"ip": ip, "port": None, "weight": None, "country": ""}])
    w.dns_auth[w.fqdn(name)] = [ip]
    w.dns_pub[w.fqdn(name)] = [ip]


@scenario
def zone_audit_refuses_uncovered_record_then_covers_it(env):
    _add_record(env, "api", OLD)
    _add_record(env, "mail", "203.0.113.9")          # unrelated record: must not matter
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=2)
    assert r.state["rotation"] is None and env.mutations() == [], env.mutations()
    assert any("DNS zone audit" in t and "api" in t and "mail" not in t for _l, t in env.alerts), env.alerts
    env.cfg["DNS_NAMES"] = ["@", "www", "api"]
    r = env.build()
    r.run_forever(max_loops=1)
    assert_completed(env, r)
    assert env.world.dns_auth["api." + ZONE] == [NEW1], env.world.dns_auth
    assert env.world.dns_auth["mail." + ZONE] == ["203.0.113.9"]


@scenario
def zone_audit_unreadable_in_verify_only_warns_and_proceeds(env):
    env.cfg["DNS_UPDATE_MODE"] = "verify_only"
    env.world.faults["dns_get_forbidden"] = True
    env.world.blocked.add(OLD)
    r = env.build()
    orig = r.alerter.send

    def on_alert(level, title, details=None, force=False):
        if title.startswith("ACTION: point"):
            for n in (ZONE, "www." + ZONE):
                env.world.set_auth(n, [NEW1])
        return orig(level, title, details, force)
    r.alerter.send = on_alert
    r.run_forever(max_loops=2)
    assert_completed(env, r)
    ev = open(os.path.join(env.cfg["LOG_DIR"], "events.jsonl")).read()
    assert "dns_zone_audit_unavailable" in ev


@contextlib.contextmanager
def _env_vars(**kv):
    saved = {k: os.environ.get(k) for k in kv}
    os.environ.update(kv)
    try:
        yield
    finally:
        for k, v in saved.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


@scenario
def config_types_and_typos_detected(env):
    with _env_vars(ROTATOR_DNS_NAMES="www", ROTATOR_EXPECTED_SERVER_NAME="123",
                   ROTATOR_DNS_NAME='["www"]', ROTATOR_MAX_CHANGES_PER_DAY="lots"):
        cfg = rot.load_config()
        assert cfg["EXPECTED_SERVER_NAME"] == "123", cfg["EXPECTED_SERVER_NAME"]
        probs = rot.config_problems(cfg)
        assert any(p.startswith("DNS_NAMES must be a JSON list") for p in probs), probs
        assert any(p.startswith("MAX_CHANGES_PER_DAY must be a number") for p in probs), probs
        assert any("ROTATOR_DNS_NAME " in p for p in probs), probs
    with _env_vars(ROTATOR_DNS_NAMES='["@","www"]', ROTATOR_CHECK_PORT="8443"):
        cfg = rot.load_config()
        assert cfg["DNS_NAMES"] == ["@", "www"] and cfg["CHECK_PORT"] == 8443
        assert rot.config_problems(cfg) == [], rot.config_problems(cfg)


@scenario
def daemon_refuses_bad_config_and_alerts_once(env):
    sd, ld = os.path.join(env.tmp, "sd2"), os.path.join(env.tmp, "ld2")
    sink = os.path.join(env.tmp, "alerts.out")
    hook = os.path.join(env.tmp, "alert.sh")
    with open(hook, "w") as fh:
        fh.write('#!/bin/sh\nprintf "%%s\\n" "$1" >> %s\n' % sink)
    os.chmod(hook, 0o755)
    with _env_vars(ROTATOR_STATE_DIR=sd, ROTATOR_LOG_DIR=ld, ROTATOR_LOG_STDOUT="false",
                   ROTATOR_DNS_UPDATE_MODE="arvan-api", ROTATOR_ALERT_COMMAND=hook):
        out = io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(io.StringIO()):
            codes = [rot.main(["run"]), rot.main(["run"]), rot.main(["resume"]),
                     rot.main(["rotate", "--trial", "--yes"]), rot.main(["config"])]
    assert codes == [3, 3, 3, 3, 1], codes
    assert "REFUSED: invalid configuration" in out.getvalue(), out.getvalue()
    lines = open(sink).read().strip().splitlines()
    assert len(lines) == 1, "expected one throttled alert, got %d" % len(lines)
    alert = json.loads(lines[0])
    assert alert["level"] == "critical" and "DNS_UPDATE_MODE" in alert["title"], alert
    assert not os.path.exists(os.path.join(sd, "state.json")), "refused run must not create state"
    assert env.mutations() == []


@scenario
def halt_alerts_even_if_state_write_fails(env):
    r = env.build()
    r.bootstrap()

    def broken_save(*_a, **_k):
        raise rot.RotatorError("disk full (simulated)")
    r.store.save = broken_save
    try:
        r.halt("simulated failure")
        raise AssertionError("halt() should propagate the save error")
    except rot.RotatorError as exc:
        assert "disk full" in str(exc)
    assert any(t.startswith("HALTED: simulated failure") for _l, t in env.alerts), env.alerts

# ------------------------------------------------- Cloudflare (gt / px / sb records)
CF_NAMES = ["gt", "px", "sb"]
UNRELATED = {"@": "203.0.113.7", "mail": "203.0.113.9", "gtx": "203.0.113.5"}


def _cf_setup(env, proxied=(), **cfg):
    env.cfg.update({"DNS_UPDATE_MODE": "cloudflare_api", "DNS_NAMES": list(CF_NAMES)})
    env.cfg.update(cfg)
    for n in CF_NAMES:
        env.world.cf_add(n, OLD, proxied=n in proxied)
    for n, ip in UNRELATED.items():                  # must never be touched
        env.world.cf_add(n, ip)


def _blob(env):
    out = ""
    for root, _d, files in os.walk(env.tmp):
        for f in files:
            out += open(os.path.join(root, f), errors="replace").read()
    return out


def assert_cf_completed(env, r, new_ip=NEW1):
    st = r.state
    assert st["rotation"] is None, "rotation still active: %s" % (st["rotation"] or {}).get("phase")
    assert st["halt"] is None, "halted: %s" % st["halt"]
    assert st["current"]["ip"] == new_ip, st["current"]
    assert OLD not in env.world.public_ips(), "old IP still attached"
    for n in CF_NAMES:
        assert env.world.cf_named(n) == [new_ip], (n, env.world.cf_named(n))
    for n, ip in UNRELATED.items():
        assert env.world.cf_named(n) == [ip], (n, env.world.cf_named(n))
    assert not [c for c in env.world.calls if c[1].startswith("/cdn/")], "ArvanCloud DNS API must not be used"
    assert env.net.lookup("1.1.1.1")["prefsrc"] == new_ip
    assert st["history"][-1]["result"] == "completed"


@scenario
def cloudflare_happy_path_three_records(env):
    _cf_setup(env)
    env.world.cf_per_page_cap = 2                   # forces paginated listings
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=2)
    assert_cf_completed(env, r)
    patches = env.world.cf_patches
    assert len(patches) == 3, patches
    assert sorted(b["name"] for _rid, b in patches) == ["%s.%s" % (n, ZONE) for n in CF_NAMES], patches
    for _rid, b in patches:
        assert b == {"type": "A", "name": b["name"], "content": NEW1, "ttl": 1, "proxied": False}, b
    for n in CF_NAMES:
        assert env.world.dns_auth["%s.%s" % (n, ZONE)] == [NEW1], env.world.dns_auth
    ev = [json.loads(l) for l in open(env.cfg["LOG_DIR"] + "/events.jsonl")]
    phases = [e["phase"] for e in ev if e["event"] == "phase"]
    assert phases == ["ALLOCATED", "OS_CONFIGURED", "VERIFIED", "SWITCHING", "SWITCHED", "DNS_UPDATED",
                      "DNS_VERIFIED", "DRAINING", "RELEASING", "DONE"], phases
    drain = [e for e in ev if e["event"] == "drain_started"][0]
    assert drain["ttl"] == 300, drain                # Cloudflare 'auto' TTL counts as 300 s
    blob = _blob(env)
    assert CF_TOKEN not in blob and API_KEY not in blob, "secret leaked into logs/state"


@scenario
def cloudflare_patch_forbidden_halts_then_discard_restores(env):
    _cf_setup(env)
    env.world.faults["cf_patch_forbidden_after"] = 1     # first record changes, then 403
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=2)
    h = r.state["halt"]
    assert h and "Cloudflare DNS update failed" in h["reason"] and "forbidden" in h["reason"], h
    assert r.state["rotation"]["phase"] == "SWITCHED"
    assert OLD in env.world.public_ips() and NEW1 in env.world.public_ips()
    changed = [n for n in CF_NAMES if env.world.cf_named(n) == [NEW1]]
    assert len(changed) == 1, [(n, env.world.cf_named(n)) for n in CF_NAMES]
    assert "dns edits : Cloudflare %s.%s" % (changed[0], ZONE) in r.status_text(), r.status_text()
    assert "discard-pending puts back" in r.status_text()
    r.ack()
    try:                                             # token still cannot edit -> must NOT release new IP
        r.discard_pending()
        raise AssertionError("discard must refuse while a changed record cannot be restored")
    except rot.HaltError as exc:
        assert "could not restore Cloudflare DNS record" in str(exc) and "--skip-dns-revert" in str(exc), exc
    assert NEW1 in env.world.public_ips()
    env.world.faults.pop("cf_patch_forbidden_after")
    assert r.discard_pending() == "discarded"
    assert env.world.public_ips() == [OLD]
    for n in CF_NAMES:
        assert env.world.cf_named(n) == [OLD], (n, env.world.cf_named(n))
    assert env.world.dns_auth["%s.%s" % (changed[0], ZONE)] == [OLD]
    assert env.net.lookup("1.1.1.1")["dev"] == "eth0", "egress must be reverted"


@scenario
def cloudflare_proxied_refused_by_default_then_allowed(env):
    _cf_setup(env, proxied=("px",))
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=2)
    assert r.state["rotation"] is None and env.mutations() == [], env.mutations()
    assert any("proxied" in t and "px." + ZONE in t for _l, t in env.alerts), env.alerts
    env.cfg["CLOUDFLARE_ALLOW_PROXIED"] = True
    r = env.build()
    r.run_forever(max_loops=1)
    assert_cf_completed(env, r)
    assert env.world.dns_pub["px." + ZONE] == [CF_EDGE_IP]   # public DNS never shows the origin
    assert [b["proxied"] for _rid, b in env.world.cf_patches if b["name"] == "px." + ZONE] == [True]


@scenario
def cloudflare_zone_audit_refuses_unmanaged_records(env):
    _cf_setup(env)
    www = env.world.cf_add("www", OLD)               # on the old IP but not in DNS_NAMES
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=2)
    assert r.state["rotation"] is None and env.mutations() == [], env.mutations()
    assert any("DNS zone audit" in t and "www (A)" in t and "mail" not in t for _l, t in env.alerts), env.alerts
    del env.world.cf_records[www]
    env.world.ports[env.world.primary_port]["ips"].append("2a01:db8::10")   # old port has IPv6 ...
    env.world.cf_add("sb", "2a01:db8:0:0::10", rtype="AAAA")               # ... and an AAAA uses it
    env.alerts.clear()
    r = env.build()
    r.run_forever(max_loops=1)
    assert r.state["rotation"] is None and env.mutations() == [], env.mutations()
    assert any("DNS zone audit" in t and "sb (AAAA 2a01:db8:0:0::10)" in t for _l, t in env.alerts), env.alerts


@scenario
def cloudflare_lost_patch_response_is_retried(env):
    _cf_setup(env)
    env.world.faults["cf_patch_drop"] = True         # applied, but the reply is lost
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=2)
    assert_cf_completed(env, r)
    assert len(env.world.cf_patches) == 4, env.world.cf_patches     # one idempotent retry


@scenario
def cloudflare_crash_mid_update_resumes_without_repeats(env):
    _cf_setup(env)
    env.world.blocked.add(OLD)
    r = env.build()
    real = r.cf.update_record
    done = []

    def patch_then_die(rid, body):
        res = real(rid, body)
        done.append(rid)
        if len(done) == 2:
            raise Crash()
        return res
    r.cf.update_record = patch_then_die
    try:
        r.run_forever(max_loops=2)
        raise AssertionError("expected the simulated crash")
    except Crash:
        pass
    r2 = env.build()
    assert r2.state["rotation"]["phase"] == "SWITCHED", r2.state["rotation"]["phase"]
    assert len(r2.state["rotation"]["dns"]["cf_originals"]) == 2
    r2.run_forever(max_loops=1)
    assert_cf_completed(env, r2)
    assert len(env.world.cf_patches) == 3, env.world.cf_patches


@scenario
def cloudflare_not_authoritative_halts_keeps_old_ip_then_discard(env):
    _cf_setup(env)
    env.world.faults["cf_not_authoritative"] = True  # API accepts edits, DNS never changes
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=2)
    h = r.state["halt"]
    assert h and "DNS verification FAILED" in h["reason"] and "Cloudflare is authoritative" in h["reason"], h
    assert OLD in env.world.public_ips() and NEW1 in env.world.public_ips()
    assert not posts(env, "/detach")
    r.ack()
    assert r.discard_pending() == "discarded"
    assert env.world.public_ips() == [OLD]
    for n in CF_NAMES:
        assert env.world.cf_named(n) == [OLD], (n, env.world.cf_named(n))
    assert len(env.world.cf_patches) == 6, env.world.cf_patches      # 3 forward + 3 restore


@scenario
def cloudflare_precheck_refusals_change_nothing(env):
    _cf_setup(env)
    env.world.blocked.add(OLD)
    cases = [("zone pending", lambda w: setattr(w, "cf_zone_status", "pending"), "status 'pending'"),
             ("record elsewhere", lambda w: w.cf_records.update(
                 {k: dict(v, content="198.51.100.1") for k, v in w.cf_records.items() if v["name"] == "sb." + ZONE}),
              "not an A record on the current IP"),
             ("auth disagrees", lambda w: w.dns_auth.update({"gt." + ZONE: ["198.51.100.2"]}),
              "authoritative nameservers answer otherwise"),
             ("list forbidden", lambda w: w.faults.update(cf_list_forbidden=True), "403")]
    for label, breakit, needle in cases:
        saved = json.loads(json.dumps({"r": env.world.cf_records, "a": env.world.dns_auth}))
        breakit(env.world)
        r = env.build()
        r.bootstrap()
        try:
            r.start_rotation("force", label, ignore_limits=True)
            raise AssertionError("%s: rotation should have been refused" % label)
        except rot.RotationRefused as exc:
            assert needle in str(exc), (label, str(exc))
        assert env.mutations() == [] and r.state["rotation"] is None, (label, env.mutations())
        env.world.cf_records, env.world.dns_auth = saved["r"], saved["a"]
        env.world.cf_zone_status = "active"
        env.world.faults.clear()


@scenario
def cloudflare_dry_run_and_preflight(env):
    _cf_setup(env)
    env.world.blocked.add(OLD)
    r = env.build(dry_run=True)
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = r.dry_run_report()
    out = buf.getvalue()
    assert rc == 0 and env.mutations() == [], (rc, env.mutations(), out)
    assert out.count("would PATCH") == 3 and "/dns_records/" in out and "precheck      : ok" in out, out
    r = env.build()
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = r.preflight(probe_writes=True)
    out = buf.getvalue()
    assert rc == 0, out
    for needle in ("Cloudflare API token", "Cloudflare token status", "Cloudflare zone",
                   "Cloudflare record gt." + ZONE, "Cloudflare DNS write probe", "DNS zone audit"):
        assert needle in out, (needle, out)
    assert env.world.cf_patches == [], "the write probe must not change any record"
    os.environ["CLOUDFLARE_API_TOKEN"] = "wrong-token-value"
    try:
        r3 = env.build()
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc3 = r3.preflight()
        out3 = buf.getvalue()
        assert rc3 == 1 and "Cloudflare DNS read" in out3 and "forbidden" in out3, out3
    finally:
        os.environ["CLOUDFLARE_API_TOKEN"] = CF_TOKEN


@scenario
def cloudflare_token_required_and_validated(env):
    _cf_setup(env)
    saved = os.environ.pop("CLOUDFLARE_API_TOKEN")
    try:
        assert any("needs a Cloudflare API token" in p for p in rot.config_problems(env.cfg)), \
            rot.config_problems(env.cfg)
        r = env.build()                              # no token: refused before anything is bought
        r.bootstrap()
        try:
            r.start_rotation("force", "test", ignore_limits=True)
            raise AssertionError("must refuse without a token")
        except rot.RotationRefused as exc:
            assert "no Cloudflare API token" in str(exc), exc
        assert env.mutations() == []
        tokfile = os.path.join(env.tmp, "cloudflare_api_token")
        with open(tokfile, "w") as fh:
            fh.write("Bearer %s\n" % CF_TOKEN)
        os.chmod(tokfile, 0o644)
        env.cfg["CLOUDFLARE_API_TOKEN_FILE"] = tokfile
        assert any("too open" in p for p in rot.config_problems(env.cfg)), rot.config_problems(env.cfg)
        os.chmod(tokfile, 0o600)
        assert rot.config_problems(env.cfg) == [], rot.config_problems(env.cfg)
        assert rot.load_cf_token(env.cfg) == (CF_TOKEN, "file:" + tokfile)
        with open(tokfile, "w") as fh:
            fh.write("0123456789abcdef0123456789abcdef01234")     # Global API Key shape
        assert any("Global API Key" in p for p in rot.config_problems(env.cfg)), rot.config_problems(env.cfg)
        env.cfg.update({"CLOUDFLARE_API_TOKEN_FILE": "", "DNS_RECORD_TTL": 30,
                        "CLOUDFLARE_ZONE_ID": "not-a-zone-id"})
        probs = rot.config_problems(env.cfg)
        for needle in ("DNS_RECORD_TTL", "CLOUDFLARE_ZONE_ID", "needs a Cloudflare API token"):
            assert any(needle in p for p in probs), (needle, probs)
    finally:
        os.environ["CLOUDFLARE_API_TOKEN"] = saved


@scenario
def cloudflare_discard_with_manual_dns_restore(env):
    _cf_setup(env)
    env.world.faults["cf_not_authoritative"] = True
    env.world.blocked.add(OLD)
    r = env.build()
    r.run_forever(max_loops=2)
    assert r.state["halt"], "expected a DNS gate halt"
    env.world.cf_token = "rotated-elsewhere"         # token revoked; operator fixes DNS by hand
    for rec in env.world.cf_records.values():
        if rec["content"] == NEW1:
            rec["content"] = OLD
    r.ack()
    try:
        r.discard_pending()
        raise AssertionError("discard must refuse while it cannot check the records")
    except rot.HaltError:
        pass
    assert NEW1 in env.world.public_ips()
    assert r.discard_pending(skip_dns_revert=True) == "discarded"
    assert env.world.public_ips() == [OLD]


if __name__ == "__main__":
    only = sys.argv[1:]
    unknown = [n for n in only if n not in {f.__name__ for f in SCENARIOS}]
    if unknown:
        sys.exit("unknown scenario(s): %s" % ", ".join(unknown))
    for fn in SCENARIOS:
        if only and fn.__name__ not in only:
            continue
        fn()
    w = max(len(n) for n, _, _ in RESULTS)
    for n, s, d in RESULTS:
        print("%-*s %s" % (w, n, s))
    fails = [x for x in RESULTS if x[1] == "FAIL"]
    for n, _, d in fails:
        print("\n==== %s ====\n%s" % (n, d))
    print("\n%d passed, %d failed" % (len(RESULTS) - len(fails), len(fails)))
    sys.exit(1 if fails else 0)
