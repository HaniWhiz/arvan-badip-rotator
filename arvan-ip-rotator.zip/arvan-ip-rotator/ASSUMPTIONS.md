# Assumptions and unconfirmed items: check these before production

Labels: **[CONFIRMED]** means a source was found. **[ASSUMED]** means it was not confirmed. **[CONTRADICTED]** means the docs say otherwise.
Nothing below was tested against a real ArvanCloud or Cloudflare account. Some pages on docs.arvancloud.ir could not be loaded (504) while this was written.

## 1. API key and permissions
- [ASSUMED] **No API key was provided, so none of its permissions were verified.**
  - `preflight` proves the read permissions.
  - Write permissions cannot be proven without a change. `--probe-writes` uses random IDs: a 403 proves a permission is missing, anything else is inconclusive.
  - The conclusive test is `rotate --trial --yes` followed by `discard-pending --yes`. It costs one extra IPv4 for a short time.
- [ASSUMED] The exact IAM policy names that grant "Cloud Server read/write" and "CDN DNS read/write" to a machine user. The IAM and machine-user docs describe access per service only in general terms: https://docs.arvancloud.ir/en/accounts/iam/machine-user
- [CONFIRMED] The auth header is `Authorization: Apikey <key>` (API docs and the official CLI source). If the stored key already starts with "Apikey ", the script strips that prefix.
- [ASSUMED] **No Cloudflare API token was provided either**, so its permissions weren't verified.
  - `preflight` proves the read permissions. `--probe-writes` sends a `PATCH` to a random record ID: a 403 proves DNS Edit is missing, anything else is inconclusive.
  - `rotate --trial` stops before DNS, so the first real Cloudflare write happens in the first full rotation. If that write is refused, the run halts at `SWITCHED` with the old IP still attached, and `ack` + `discard-pending` rolls back (tested against the mock only).
- [CONFIRMED] Cloudflare calls use `Authorization: Bearer <token>`. A stored "Bearer " prefix is stripped.
- [ASSUMED] A 37-character hex value is treated as the Global API Key and rejected. The Global API Key uses different headers and can't be scoped to one zone.
- [ASSUMED] `GET /user/tokens/verify` only works for tokens created under **My Profile**. For an account-owned token, `preflight` shows a WARN on that row and relies on the record reads instead. Its documented `status` values are `active`, `disabled` and `expired`: https://developers.cloudflare.com/api/resources/user/subresources/tokens/methods/verify/

## 2. Endpoints (taken from ArvanCloud's own tooling, not from a published v1 reference)
- [CONFIRMED] The current IaaS reference (v3, `https://ecc.[region].arvanapis.ir/v3`) documents network attach/detach but **no public-IP add or remove**.
- [ASSUMED] Because of that, the script uses the **v1** API at `https://napi.arvancloud.ir/ecc/v1/regions/{region}/…`, which is what ArvanCloud's Terraform provider (`terraform-provider-arvan`) and official CLI (`arvan iaas network add-public-ip`) call:
  - `POST servers/{id}/add-public-ip` with body `{"type":"ipv4","security_groups":[…]}`. The response shape (`port_id`, `mac_addr`, `fixed_ips`) comes from the provider source. Whether the call is synchronous is unknown, so the script polls the port until it is ACTIVE.
  - `PATCH networks/{PORT_ID}/detach` with `{"server_id": …}` is how the old IP is released. The CLI puts the **port ID** where the path expects a network ID. This has not been verified live.
  - Also unconfirmed: whether detaching a port **frees the IPv4 for good** (no more billing) or only unbinds it. Check the panel and billing after the trial.
  - Read calls: `GET servers/{id}`, `servers/{id}/ports`, `ports/{id}`, `networks`, `networks/{id}`, `quotas`.
  - DNS calls: `GET/PUT https://napi.arvancloud.ir/cdn/4.0/domains/{zone}/dns-records[/{id}]`.
- [ASSUMED] v1 may be deprecated at some point. The API docs say a `Sunset` header announces deprecation, and the script logs it (and `Deprecation`) whenever it appears.
- [CONFIRMED] Cloudflare endpoints (base `https://api.cloudflare.com/client/v4`):
  - `GET /zones?name=honeyhost.click` needs Zone Read, allows at most 50 per page, and returns the zone's `status` and `name_servers`: https://developers.cloudflare.com/api/resources/zones/methods/list/
  - `GET /zones/{zone_id}/dns_records` accepts DNS Read or DNS Write, filters with `type` and `name.exact`, and pages via `result_info.total_pages`: https://developers.cloudflare.com/api/resources/dns/subresources/records/methods/list/
  - `PATCH /zones/{zone_id}/dns_records/{dns_record_id}` needs DNS Write. For an A record the body schema lists `name`, `ttl` and `type` as required, and `ttl` 1 means automatic, otherwise 60–86400 (30 on Enterprise): https://developers.cloudflare.com/api/resources/dns/subresources/records/methods/edit/
- [ASSUMED] So the script sends `type`, `name`, `ttl` and `proxied` unchanged along with the new `content`. It assumes PATCH leaves the fields it doesn't send (comment, tags) as they are.
- [ASSUMED] The script refuses a record whose `locked` field is true. That field isn't in the current reference, so the check is only a safeguard.

## 3. How a new IP shows up on the server
- [ASSUMED] add-public-ip creates a **new port, i.e. a new NIC with its own MAC**, hot-plugged into the running VM.
  - The script waits up to 120 s for the NIC to appear, then configures the address and policy routing itself.
  - The ArvanCloud IPv6 page says an IP added to an existing instance needs manual OS network configuration, and shows a second NIC (`eth1`) in netplan: https://docs.arvancloud.ir/en/cloud-server/network/IPv6
  - If your image doesn't hot-plug NICs, the run halts at `ALLOCATED`/`OS_CONFIGURED` and you need `discard-pending`.
- [ASSUMED] The **original port can be detached** on a live server. Also unconfirmed: whether detaching it takes the metadata route (169.254.169.254), the port's IPv6, or anything else with it.
  - The IPv6 on the old port is released together with it (`preflight` warns about this).
  - The server UUID falls back to the saved state if the metadata service disappears.
- [ASSUMED] Copying the old port's security groups (cloud firewall) to the new port is correct and enough. If the old port has none, the server's groups are used, or Arvan's default.
- [ASSUMED] Reboot behaviour after a rotation is untested:
  - The script's iproute2 changes are live-only unless `PERSIST_NETPLAN=true`.
  - cloud-init may re-render `50-cloud-init.yaml` from metadata at boot.
- [CONFIRMED] You can't choose the new IP: allocation is automatic, and requesting a range isn't possible (FAQ: https://www.arvancloud.ir/en/faq). If Iran blocks whole ranges, new IPs may be blocked too. The script then halts at verification, and every attempt costs one allocation against the caps.
- [ASSUMED] A Floating IP (NAT'd; quota 4) could make rotation cleaner: no new NIC, no OS changes. It was **not** used because it needs the server on a private network, which wasn't confirmed for this server.

## 4. DNS (honeyhost.click)
- [ASSUMED] **honeyhost.click is an active Cloudflare zone with a full setup**, so Cloudflare's nameservers answer for it. This follows from the request to update the records with a Cloudflare API token; it wasn't verified.
  - Before buying an IP, the precheck refuses to rotate if the zone isn't `active` or isn't `full`, or if the authoritative nameservers don't return the IP that the Cloudflare records hold.
  - If an edit still doesn't reach clients, the DNS gate halts after 15 min and **keeps the old IP**.
- [ASSUMED] `gt`, `px` and `sb` are plain A records (not CNAMEs) that point at the server's current IP and are **DNS only**. The precheck refuses otherwise. If a name has more than one A record, only the one on the old IP is changed.
- [CONTRADICTED] "The A records follow the VM automatically." No feature that binds an A record to a VM was found. ArvanCloud's help page says the A record must be edited after an IP change: https://www.arvancloud.ir/help/en/hosting-change. That edit is what `cloudflare_api` mode does. `verify_only` (you edit, the script verifies) and `arvan_api` (ArvanCloud CDN DNS) are still available.
- [ASSUMED] Which other names exist in the zone is unknown. The **zone audit** lists every record through the Cloudflare API and refuses to rotate if another A record points at the old IP, or an AAAA record points at the old port's IPv6, because releasing the old port would break it. Add such A names to `DNS_NAMES` so they move too, and repoint or remove such AAAA records. `DNS_AUDIT_ZONE=false` turns the check off.
- [ASSUMED] Proxied (orange-cloud) records answer with Cloudflare edge IPs, so public DNS can't show that they moved. They are refused by default. With `CLOUDFLARE_ALLOW_PROXIED=true`, they are updated too and verified by reading them back from the API. The edge is assumed to use the new origin right after the `PATCH`.
- [ASSUMED] ANAME/CNAME records aren't edited.
- [CONFIRMED] Cloudflare's "Auto" TTL is 300 s, and DNS-only records accept 60 s to 1 day (30 s on Enterprise): https://developers.cloudflare.com/dns/manage-dns-records/reference/ttl/. The script uses 300 s for "Auto" when it computes the drain. It accepts 0 (keep), 1 (Auto) or 60–86400 for `DNS_RECORD_TTL`.
- [ASSUMED] Propagation timing:
  - The drain lasts max(TTL, 120 s) + 300 s after the authoritative servers show the new IP.
  - Resolvers that ignore TTL may still send clients to the old IP after it is released.
  - In `arvan_api` mode, the TTL values the script accepts for `DNS_RECORD_TTL` (120 s and up) weren't checked against the API.

## 5. Detecting blocking from Iran (check-host.net)
- [ASSUMED] check-host.net keeps its public API (`/check-tcp|http|ping`, `/check-result/{id}`, `/nodes/hosts`) and its Iranian nodes.
  - Nodes are picked by country code `ir`, falling back to `ir1`–`ir7`.
  - If fewer than 3 nodes give a clear answer, the cycle is INCONCLUSIVE and nothing happens.
- [ASSUMED] check-host's rate limits aren't documented. The script waits at least 60 s between submissions and backs off on `limit_exceeded`.
  - Probe results are **public** on check-host.net, so your IP appears there.
- [ASSUMED] Third-party Iranian nodes can be filtered, overloaded, or not representative of your users. For better accuracy, consider your own vantage point inside Iran (another small VPS) or RIPE Atlas.
- [ASSUMED] Blocking can be protocol-specific: TCP 443 may connect while HTTP/TLS is filtered by SNI. Pick `CHECK_TYPE` (`tcp`/`http`/`ping`) and `CHECK_PORT` to match how users actually reach you.

## 6. Quotas, billing, rate limits, timing
- [CONFIRMED] Limits:
  - at most **4 IPs per cloud server**
  - **15 public IPs per account** by default (more on request)
  - 4 floating IPs

  Sources: FAQ and https://docs.arvancloud.ir/en/cloud-server/quota/
- [CONFIRMED] Pricing (https://www.arvancloud.ir/en/pricing/cloud-server):
  - first IPv4 **€1.42/month**
  - each additional IPv4 **€2.83/month**
  - IPv6 free
  - servers billed hourly

  During a rotation the server briefly holds two IPv4s.
- [ASSUMED] Whether a short-lived extra IPv4 is billed pro-rata or for a full month.
- [ASSUMED] There is no documented **minimum holding time** for an IP and no **minimum interval between releases or allocations**. The script sets its own:
  - 1 h cooldown
  - 15 min back-off after a failure
  - 1 allocation per hour, 3 per day
- [CONFIRMED] The Cloudflare API allows 1,200 requests per 5 minutes per user: https://developers.cloudflare.com/fundamentals/api/reference/limits/. A rotation makes a few dozen Cloudflare calls at most, and 429/5xx answers are retried with back-off.
- [ASSUMED] ArvanCloud API rate limits have no published numbers. The docs define 429 as "rate limit exceeded", and the provider source treats 420 as quota exceeded.
  - Read calls back off and retry on 429/5xx, honouring `Retry-After` up to 120 s.
  - For the billable POST, a 429/5xx counts as "maybe applied": the script checks the port list before it ever sends a second attempt.
  - A 420 halts with an alert.
- [ASSUMED] Rotating IPs often to get around blocking is allowed by ArvanCloud's Terms of Service and won't trip abuse detection. **Check the ToS.**

## 7. Server environment
- [ASSUMED] Linux with iproute2, systemd and Python ≥ 3.8, run as root.
- [ASSUMED] The new IP can reach `napi.arvancloud.ir`, `api.cloudflare.com`, check-host.net and the echo services. This is verified at switch time, except for `api.cloudflare.com`, which is first used right after the switch.
- [ASSUMED] Services bind to `0.0.0.0`/`::`, and local firewall rules don't reference the old IP. If they do, adapt them with `POST_SWITCH_HOOK`.
- [ASSUMED] `KillMode=process` in the systemd unit keeps the detached route watchdog alive across a crash or restart. Not tested on real systemd.
- [ASSUMED] `rp_filter=2` (loose) is acceptable while the server has two public IPs. The script sets it when `SET_RP_FILTER_LOOSE=true`.

## 8. Interpretation choices
- The spec asks for a dry-run that "performs steps 1–3 without changing anything". Steps 2–3 (allocate, verify) can't happen without a change, so there are two modes:
  - `--dry-run`: step 1 for real, step 2 simulated, step 3 as read-only checks of the current IP. No changes at all.
  - `--trial --yes`: steps 1–3 for real, then it stops. This one is billable.
- "Switch to the new IP" means: default egress moves to the new IP, while the old IP keeps answering inbound traffic through its own routing table until the drain ends.

## 9. What was and wasn't tested
- **Tested:** 61 fault-injection scenarios against a mock ArvanCloud API (IaaS v1, CDN DNS, identity), a mock Cloudflare API (zones, paginated DNS records, `PATCH`, token verify), mock check-host.net, mock authoritative and public DNS, and a fake `ip` interpreter. Scenarios include:
  - lost or dropped responses, 403s, quota errors, crashes at every phase
  - the watchdog firing, the DNS gate failing, proxied records, a corrupt state file, lock contention, bad config
  - Cloudflare: a 403 on the second of three `PATCH`es, a lost `PATCH` response, a crash between `PATCH`es, proxied records, unmanaged records in the zone audit, a zone that Cloudflare doesn't actually serve, and a token revoked before rollback
- **Not tested:** the real ArvanCloud API, the real Cloudflare API, the real check-host.net, a real kernel routing table. The build sandbox had no root and no `ip`. The OS networking layer is the riskiest part, so **run the trial on a non-production server first**, then test a reboot.
